const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import LandingPage from "./screens/LandingPage";
import PhMeter from "./components/PhMeter";
import ToIncreaseSoil from "./components/ToIncreaseSoilAcidity";
import ToDecreaseSoil from "./components/ToDecreaseSoilAcidity";
import LandingPage1 from "./screens/LandingPage1";
import Component from "./screens/Component";
import CropHealth from "./screens/CropHealth";
import CropHealth1 from "./screens/CropHealth1";
import CropHealth2 from "./screens/CropHealth2";
import ConnectionError from "./screens/ConnectionError";
import SetupDuration from "./screens/SetupDuration";
import KnowledgeForSoilMoisture from "./screens/KnowledgeForSoilMoisture";
import KnowledgeForOptimumSoilMoi from "./screens/KnowledgeForOptimumSoilMoi";
import KnowledgeForOptimumSoilPH from "./screens/KnowledgeForOptimumSoilPH";
import Property1Frame from "./components/Property1Frame";
import Sensor2 from "./screens/Sensor2";
import Sensor1 from "./screens/Sensor1";
import Setup from "./screens/Setup";
import Period from "./screens/Period";
import SetupCyclical from "./screens/SetupCyclical";
import SetupCyclical1 from "./screens/SetupCyclical1";
import SetupDuration1 from "./screens/SetupDuration1";
import SetupDuration2 from "./screens/SetupDuration2";
import SetupDuration3 from "./screens/SetupDuration3";
import SetupDuration4 from "./screens/SetupDuration4";
import SetupDuration5 from "./screens/SetupDuration5";
import SetupDuration6 from "./screens/SetupDuration6";
import SetupDuration8 from "./screens/SetupDuration8";
import SetupDuration7 from "./screens/SetupDuration7";
import SetupDuration10 from "./screens/SetupDuration10";
import SetupDuration9 from "./screens/SetupDuration9";
import SetupDuration11 from "./screens/SetupDuration11";
import SetupWeekly from "./screens/SetupWeekly";
import Weather from "./screens/Weather";
import Community from "./screens/Community";
import CultivationTips from "./screens/CultivationTips";
import Soil from "./screens/Soil";
import PestMonitoringResult from "./screens/PestMonitoringResult";
import CropHealth3 from "./screens/CropHealth3";
import FertilizerCalculator from "./screens/FertilizerCalculator";
import PlantSelection from "./screens/PlantSelection";
import CropHealth4 from "./screens/CropHealth4";
import FertilizerCalculator1 from "./screens/FertilizerCalculator1";
import CheckForPest from "./screens/CheckForPest";
import ApplyForPesticide from "./screens/ApplyForPesticide";
import CropHealth5 from "./screens/CropHealth5";
import CropHealth6 from "./screens/CropHealth6";
import CropHealth7 from "./screens/CropHealth7";
import ConnectSensor from "./screens/ConnectSensor";
import Irrigation from "./screens/Irrigation";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "IstokWeb-Regular": require("./assets/fonts/IstokWeb-Regular.ttf"),
    "IstokWeb-Bold": require("./assets/fonts/IstokWeb-Bold.ttf"),
    "IstokWeb-BoldItalic": require("./assets/fonts/IstokWeb-BoldItalic.ttf"),
    "Sanchez-Regular": require("./assets/fonts/Sanchez-Regular.ttf"),
    "Sarabun-SemiBold": require("./assets/fonts/Sarabun-SemiBold.ttf"),
    "Sarabun-ExtraBold": require("./assets/fonts/Sarabun-ExtraBold.ttf"),
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator
            initialRouteName="LandingPage"
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen
              name="LandingPage"
              component={LandingPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PhMeter"
              component={PhMeter}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ToIncreaseSoil"
              component={ToIncreaseSoil}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ToDecreaseSoil"
              component={ToDecreaseSoil}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LandingPage1"
              component={LandingPage1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Component"
              component={Component}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth"
              component={CropHealth}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth1"
              component={CropHealth1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth2"
              component={CropHealth2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ConnectionError"
              component={ConnectionError}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration"
              component={SetupDuration}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KnowledgeForSoilMoisture"
              component={KnowledgeForSoilMoisture}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KnowledgeForOptimumSoilMoi"
              component={KnowledgeForOptimumSoilMoi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="KnowledgeForOptimumSoilPH"
              component={KnowledgeForOptimumSoilPH}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sensor2"
              component={Sensor2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Sensor1"
              component={Sensor1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Setup"
              component={Setup}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Period"
              component={Period}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupCyclical"
              component={SetupCyclical}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupCyclical1"
              component={SetupCyclical1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration1"
              component={SetupDuration1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration2"
              component={SetupDuration2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration3"
              component={SetupDuration3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration4"
              component={SetupDuration4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration5"
              component={SetupDuration5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration6"
              component={SetupDuration6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration8"
              component={SetupDuration8}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration7"
              component={SetupDuration7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration10"
              component={SetupDuration10}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration9"
              component={SetupDuration9}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupDuration11"
              component={SetupDuration11}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetupWeekly"
              component={SetupWeekly}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Weather"
              component={Weather}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Community"
              component={Community}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CultivationTips"
              component={CultivationTips}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Soil"
              component={Soil}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PestMonitoringResult"
              component={PestMonitoringResult}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth3"
              component={CropHealth3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FertilizerCalculator"
              component={FertilizerCalculator}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PlantSelection"
              component={PlantSelection}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth4"
              component={CropHealth4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="FertilizerCalculator1"
              component={FertilizerCalculator1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CheckForPest"
              component={CheckForPest}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ApplyForPesticide"
              component={ApplyForPesticide}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth5"
              component={CropHealth5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth6"
              component={CropHealth6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CropHealth7"
              component={CropHealth7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ConnectSensor"
              component={ConnectSensor}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Irrigation"
              component={Irrigation}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
