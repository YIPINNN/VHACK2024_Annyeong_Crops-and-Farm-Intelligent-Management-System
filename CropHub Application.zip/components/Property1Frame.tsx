import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

export type Property1FrameType = {
  numberValue?: string;

  /** Style props */
  property1Frame1Position?: string;
  property1Frame1Width?: number | string;
  property1Frame1Height?: number | string;
  property1Frame1Top?: number | string;
  property1Frame1Left?: number | string;
  textFontSize?: number;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Property1Frame = ({
  numberValue,
  property1Frame1Position,
  property1Frame1Width,
  property1Frame1Height,
  property1Frame1Top,
  property1Frame1Left,
  textFontSize,
}: Property1FrameType) => {
  const property1Frame1Style = useMemo(() => {
    return {
      ...getStyleValue("position", property1Frame1Position),
      ...getStyleValue("width", property1Frame1Width),
      ...getStyleValue("height", property1Frame1Height),
      ...getStyleValue("top", property1Frame1Top),
      ...getStyleValue("left", property1Frame1Left),
    };
  }, [
    property1Frame1Position,
    property1Frame1Width,
    property1Frame1Height,
    property1Frame1Top,
    property1Frame1Left,
  ]);

  const textStyle = useMemo(() => {
    return {
      ...getStyleValue("fontSize", textFontSize),
    };
  }, [textFontSize]);

  return (
    <View style={[styles.property1frame1, property1Frame1Style]}>
      <Text style={[styles.text, textStyle]}>{numberValue}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "left",
  },
  property1frame1: {
    backgroundColor: Color.colorWhite,
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_3xs,
  },
});

export default Property1Frame;
