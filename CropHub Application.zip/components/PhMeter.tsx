import * as React from "react";
import { ImageBackground, StyleSheet } from "react-native";

const PhMeter = () => {
  return (
    <ImageBackground
      style={styles.phMeterIcon}
      resizeMode="cover"
      source={require("../assets/phmeter.png")}
    />
  );
};

const styles = StyleSheet.create({
  phMeterIcon: {
    flex: 1,
    width: "100%",
    height: 29,
  },
});

export default PhMeter;
