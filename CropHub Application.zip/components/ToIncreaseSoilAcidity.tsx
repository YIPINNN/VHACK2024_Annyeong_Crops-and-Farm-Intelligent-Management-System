import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const ToIncreaseSoil = () => {
  return (
    <Text style={styles.toIncreaseSoil}>{`To increase soil acidity: `}</Text>
  );
};

const styles = StyleSheet.create({
  toIncreaseSoil: {
    fontSize: FontSize.size_2xs,
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorBlack,
    textAlign: "center",
    width: 256,
  },
});

export default ToIncreaseSoil;
