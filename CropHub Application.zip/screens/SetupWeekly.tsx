import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SetupWeekly = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupWeekly}>
      <Image
        style={[styles.component71Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component72Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component73Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component74Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component75Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component76Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <Image
        style={[styles.component77Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/component-71.png")}
      />
      <View style={styles.setupWeeklyChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupWeeklyItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupWeeklyInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupWeeklyChild1, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupWeeklyChild2, styles.setupChildLayout]} />
      <View style={[styles.setupWeeklyChild3, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <Image
        style={[styles.image32Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-32.png")}
      />
      <Text style={[styles.weekly, styles.weeklyTypo]}>Weekly</Text>
      <Text style={[styles.waterOnSpecific, styles.setARegularLayout]}>
        Water on specific days.
      </Text>
      <View style={[styles.setupWeeklyChild4, styles.rectangleViewLayout]} />
      <Image
        style={[styles.image33Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-33.png")}
      />
      <Text style={[styles.cyclical, styles.weeklyTypo]}>Cyclical</Text>
      <Text style={[styles.setARegular, styles.setARegularLayout]}>
        Set a regular watering interval.
      </Text>
      <Text style={[styles.weekly1, styles.weeklyTypo]}>Weekly</Text>
      <Text style={styles.selectWateringDays}>Select watering days.</Text>
      <Text style={[styles.mon, styles.monText]}>Mon</Text>
      <Text style={[styles.tue, styles.monText]}>Tue</Text>
      <Text style={[styles.wed, styles.monText]}>Wed</Text>
      <Text style={[styles.thu, styles.monText]}>Thu</Text>
      <Text style={[styles.fri, styles.monText]}>Fri</Text>
      <Text style={[styles.sat, styles.monText]}>Sat</Text>
      <Text style={[styles.sun, styles.monText]}>Sun</Text>
      <Pressable
        style={[styles.rectanglePressable, styles.setARegularLayout]}
        onPress={() => navigation.navigate("SetupDuration1")}
      />
      <Text style={[styles.next, styles.monText]}>Next</Text>
      <View style={[styles.ellipseParent, styles.groupChildLayout]}>
        <Image
          style={[styles.groupChild, styles.groupChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={styles.image36Icon}
          contentFit="cover"
          source={require("../assets/image-36.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout1: {
    height: 30,
    width: 30,
    top: 451,
    position: "absolute",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    color: Color.colorBlack,
    top: 226,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 234,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    top: 254,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 110,
    width: 110,
    borderWidth: 1,
    top: 295,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  iconLayout: {
    height: 50,
    width: 50,
    top: 303,
    position: "absolute",
  },
  weeklyTypo: {
    width: 71,
    color: Color.colorBlack,
    height: 15,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setARegularLayout: {
    height: 23,
    position: "absolute",
  },
  monText: {
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    textAlign: "center",
    position: "absolute",
  },
  groupChildLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  component71Icon: {
    left: 19,
  },
  component72Icon: {
    left: 62,
  },
  component73Icon: {
    left: 105,
  },
  component74Icon: {
    left: 148,
  },
  component75Icon: {
    left: 191,
  },
  component76Icon: {
    left: 234,
  },
  component77Icon: {
    left: 274,
  },
  setupWeeklyChild: {
    top: 14,
    width: 320,
    height: 39,
    backgroundColor: Color.forest3,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupWeeklyItem: {
    left: 34,
  },
  text: {
    left: 40,
  },
  setupWeeklyInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupWeeklyChild1: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupWeeklyChild2: {
    left: 137,
  },
  setupWeeklyChild3: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    top: 254,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    top: 254,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    top: 254,
  },
  rectangleView: {
    left: 32,
    backgroundColor: Color.colorBeige_100,
  },
  image32Icon: {
    left: 61,
  },
  weekly: {
    left: 52,
    top: 357,
    width: 71,
    fontSize: FontSize.size_2xs,
  },
  waterOnSpecific: {
    left: 46,
    width: 82,
    top: 376,
    height: 23,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  setupWeeklyChild4: {
    left: 175,
    backgroundColor: Color.colorGainsboro_200,
  },
  image33Icon: {
    left: 204,
  },
  cyclical: {
    left: 195,
    top: 357,
    width: 71,
    fontSize: FontSize.size_2xs,
  },
  setARegular: {
    left: 189,
    width: 82,
    top: 376,
    height: 23,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  weekly1: {
    top: 417,
    left: 125,
    fontSize: FontSize.size_sm,
  },
  selectWateringDays: {
    top: 435,
    left: 77,
    width: 168,
    height: 13,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  mon: {
    left: 22,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  tue: {
    left: 65,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  wed: {
    left: 108,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  thu: {
    left: 151,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  fri: {
    left: 194,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  sat: {
    left: 237,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  sun: {
    left: 277,
    width: 24,
    top: 459,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  rectanglePressable: {
    top: 509,
    left: 118,
    borderRadius: Border.br_8xs,
    width: 91,
    backgroundColor: Color.forest3,
  },
  next: {
    top: 513,
    left: 124,
    width: 80,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    height: 14,
    fontSize: FontSize.size_2xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  groupChild: {
    top: 0,
    left: 0,
  },
  image36Icon: {
    top: 19,
    left: 18,
    width: 65,
    height: 67,
    position: "absolute",
  },
  ellipseParent: {
    top: 82,
    left: 111,
  },
  setupWeekly: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupWeekly;
