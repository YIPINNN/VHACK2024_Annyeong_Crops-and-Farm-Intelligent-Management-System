import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const SetupDuration6 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <View style={styles.setupDurationChild} />
      <Image
        style={styles.setupDurationItem}
        contentFit="cover"
        source={require("../assets/ellipse-10.png")}
      />
      <View style={[styles.setupDurationInner, styles.rectangleViewBg]} />
      <Text style={[styles.irrigationSystem, styles.wateringTimeTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={[styles.sensor, styles.sensorLayout]}>Sensor</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupDurationChild1, styles.setupChildPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-31.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.setupDurationChild2, styles.setupChildPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupDurationChild3, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildBorder]} />
      <View style={[styles.setupDurationChild4, styles.setupChildBorder]} />
      <View style={[styles.setupDurationChild5, styles.setupChildBorder]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.rectangleView, styles.rectangleViewBg]} />
      <Text style={[styles.next, styles.nextLayout]}>Next</Text>
      <Image
        style={styles.image35Icon}
        contentFit="cover"
        source={require("../assets/image-35.png")}
      />
      <Text style={[styles.wateringTime, styles.wateringTimeTypo]}>
        Watering Time
      </Text>
      <Text style={[styles.scheduleWateringTimes, styles.nextLayout]}>
        Schedule watering times during the day(s).
      </Text>
      <Text style={[styles.cancel, styles.timeTypo]}>CANCEL</Text>
      <View
        style={[styles.addWateringTimeParent, styles.rectanglePressableLayout]}
      >
        <Text style={styles.addWateringTime}>Add watering time</Text>
        <Image
          style={[styles.image37Icon, styles.sensorLayout]}
          contentFit="cover"
          source={require("../assets/image-37.png")}
        />
      </View>
      <Pressable
        style={[styles.rectanglePressable, styles.rectanglePressableLayout]}
        onPress={() => navigation.navigate("SetupDuration8")}
      />
      <View style={[styles.setupDurationChild6, styles.setupChildBorder]} />
      <Text style={styles.text4}>07:00</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleViewBg: {
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  wateringTimeTypo: {
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  sensorLayout: {
    height: 15,
    position: "absolute",
  },
  ellipseIconLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    top: 226,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildBorder: {
    height: 1,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  nextLayout: {
    height: 14,
    textAlign: "center",
    position: "absolute",
  },
  rectanglePressableLayout: {
    height: 21,
    position: "absolute",
  },
  setupDurationChild: {
    top: 361,
    left: 235,
    borderRadius: Border.br_10xs,
    backgroundColor: Color.colorPink,
    height: 17,
    width: 42,
    position: "absolute",
  },
  setupDurationItem: {
    top: 75,
    left: 101,
    width: 100,
    height: 100,
    position: "absolute",
  },
  setupDurationInner: {
    top: 14,
    width: 320,
    height: 39,
    left: 0,
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    color: Color.colorWhite,
  },
  sensor: {
    top: 59,
    left: 272,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    width: 42,
  },
  ellipseIcon: {
    left: 34,
  },
  text: {
    left: 40,
  },
  setupDurationChild1: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  setupDurationChild2: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild3: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
    width: 48,
    top: 234,
    height: 1,
    borderTopWidth: 1,
  },
  setupDurationChild4: {
    left: 137,
    width: 48,
    top: 234,
    height: 1,
    borderTopWidth: 1,
  },
  setupDurationChild5: {
    left: 212,
    width: 48,
    top: 234,
    height: 1,
    borderTopWidth: 1,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  confirmed: {
    left: 250,
    width: 46,
    fontSize: FontSize.size_4xs,
    top: 254,
    height: 12,
    color: Color.colorBlack,
  },
  rectangleView: {
    top: 505,
    left: 114,
    borderRadius: Border.br_8xs,
    width: 91,
    height: 23,
  },
  next: {
    top: 509,
    left: 120,
    width: 80,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_2xs,
    height: 14,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  image35Icon: {
    top: 91,
    left: 113,
    width: 75,
    height: 75,
    position: "absolute",
  },
  wateringTime: {
    top: 306,
    left: 98,
    fontSize: FontSize.size_sm,
    width: 131,
    color: Color.colorBlack,
  },
  scheduleWateringTimes: {
    top: 327,
    left: 58,
    width: 206,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  cancel: {
    top: 364,
    left: 229,
    fontSize: FontSize.size_5xs,
    color: Color.colorFirebrick,
    width: 55,
  },
  addWateringTime: {
    top: 1,
    left: 7,
    textDecoration: "underline",
    fontStyle: "italic",
    fontFamily: FontFamily.istokWebBoldItalic,
    width: 98,
    height: 20,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontWeight: "700",
    position: "absolute",
  },
  image37Icon: {
    top: 0,
    width: 15,
    left: 0,
  },
  addWateringTimeParent: {
    top: 402,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 105,
    left: 109,
  },
  rectanglePressable: {
    top: 399,
    left: 107,
    backgroundColor: Color.colorGainsboro_200,
    borderWidth: 0.5,
    width: 104,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    height: 21,
  },
  setupDurationChild6: {
    top: 386,
    left: 29,
    width: 262,
    height: 1,
    borderTopWidth: 1,
  },
  text4: {
    top: 358,
    fontSize: FontSize.size_lg,
    width: 65,
    height: 22,
    color: Color.colorBlack,
    left: 34,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration6;
