import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const Sensor2 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.sensor1}>
      <View style={styles.sensor1Child} />
      <Text style={[styles.irrigationSystem, styles.addSensor1Typo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={[styles.sensor, styles.sensorTypo]}>Sensor</Text>
      <Image
        style={styles.image29Icon}
        contentFit="cover"
        source={require("../assets/image-291.png")}
      />
      <View style={[styles.sensor1Item, styles.sensor1Layout]} />
      <Text
        style={[styles.irrigationSensorNicknameContainer, styles.containerTypo]}
      >
        <Text
          style={styles.irrigationSensorNickname}
        >{`Irrigation sensor nickname `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Text style={[styles.text1, styles.text1Typo]}>|</Text>
      <Text
        style={[styles.enterConfirmedPasswordContainer, styles.containerTypo]}
      >
        <Text
          style={styles.irrigationSensorNickname}
        >{`Enter confirmed password `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Text style={[styles.enterPasswordContainer, styles.text1Typo]}>
        <Text style={styles.irrigationSensorNickname}>{`Enter password `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Pressable
        style={[styles.sensor1Inner, styles.sensor1Layout]}
        onPress={() => navigation.navigate("Sensor1")}
      />
      <Text style={[styles.sensorDetected, styles.sensorTypo]}>
        Sensor detected.
      </Text>
      <Text style={[styles.text4, styles.textTypo1]}>___</Text>
      <Text style={[styles.text5, styles.textTypo1]}>___</Text>
      <Text style={[styles.text6, styles.textTypo1]}>___</Text>
      <Text style={[styles.text7, styles.textTypo1]}>___</Text>
      <Text style={[styles.text8, styles.textTypo1]}>___</Text>
      <Text style={[styles.text9, styles.textTypo]}>___</Text>
      <Text style={[styles.text10, styles.textTypo]}>___</Text>
      <Text style={[styles.text11, styles.textTypo]}>___</Text>
      <Text style={[styles.text12, styles.textTypo]}>___</Text>
      <Text style={[styles.text13, styles.textTypo]}>___</Text>
      <Pressable
        style={styles.addSensor}
        onPress={() => navigation.navigate("Sensor1")}
      >
        <Text style={[styles.addSensor1, styles.addSensor1Typo]}>
          Add sensor
        </Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  addSensor1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    color: Color.colorWhite,
  },
  sensorTypo: {
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  sensor1Layout: {
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  containerTypo: {
    height: 16,
    width: 119,
    left: 28,
    fontSize: FontSize.size_4xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  text1Typo: {
    textAlign: "left",
    height: 16,
    fontFamily: FontFamily.istokWebRegular,
    position: "absolute",
  },
  textTypo1: {
    height: 18,
    width: 21,
    top: 338,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo: {
    top: 389,
    height: 18,
    width: 21,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  sensor1Child: {
    top: 14,
    left: 0,
    width: 320,
    height: 39,
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    height: 19,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebRegular,
  },
  image29Icon: {
    top: 86,
    left: 110,
    width: 100,
    height: 100,
    position: "absolute",
  },
  sensor1Item: {
    top: 273,
    left: 35,
    backgroundColor: Color.forest5,
    width: 250,
    height: 25,
  },
  irrigationSensorNickname: {
    color: Color.colorBlack,
  },
  text: {
    color: Color.colorIndianred,
  },
  irrigationSensorNicknameContainer: {
    top: 259,
  },
  text1: {
    top: 278,
    left: 41,
    width: 11,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
  },
  enterConfirmedPasswordContainer: {
    top: 367,
  },
  enterPasswordContainer: {
    top: 313,
    left: 31,
    width: 110,
    fontSize: FontSize.size_4xs,
  },
  sensor1Inner: {
    top: 505,
    left: 114,
    width: 91,
    height: 23,
    backgroundColor: Color.forest3,
  },
  sensorDetected: {
    top: 214,
    left: 71,
    width: 165,
    height: 17,
    color: Color.colorBlack,
    fontSize: FontSize.size_4xs,
  },
  text4: {
    left: 72,
  },
  text5: {
    left: 150,
  },
  text6: {
    left: 189,
  },
  text7: {
    left: 228,
  },
  text8: {
    left: 111,
  },
  text9: {
    left: 72,
  },
  text10: {
    left: 150,
  },
  text11: {
    left: 189,
  },
  text12: {
    left: 228,
  },
  text13: {
    left: 111,
  },
  addSensor1: {
    width: 80,
    height: 14,
    fontSize: FontSize.size_2xs,
  },
  addSensor: {
    left: 120,
    top: 509,
    position: "absolute",
  },
  sensor1: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default Sensor2;
