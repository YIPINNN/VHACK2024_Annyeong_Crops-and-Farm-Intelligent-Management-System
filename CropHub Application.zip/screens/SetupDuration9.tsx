import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SetupDuration9 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <View style={[styles.setupDurationChild, styles.setupDurationChildBg]} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupDurationItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupDurationInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-41.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupDurationChild1, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout1]} />
      <View style={[styles.setupDurationChild2, styles.setupChildLayout1]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout1]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <Text style={[styles.wateringPeriod, styles.wateringTypo1]}>
        Watering Period
      </Text>
      <Text style={[styles.weekly, styles.weeklyTypo]}>Weekly</Text>
      <View style={[styles.setupDurationChild4, styles.setupChildLayout]} />
      <Text style={[styles.wateringDuration, styles.wateringTypo]}>
        Watering Duration
      </Text>
      <Text style={[styles.hours30Minutes, styles.text4Typo]}>
        0 hours 30 minutes
      </Text>
      <View style={[styles.setupDurationChild5, styles.setupChildLayout]} />
      <Text style={[styles.wateringTime, styles.wateringTypo]}>
        Watering Time
      </Text>
      <Text style={[styles.text4, styles.text4Typo]}>07:00, 13:00, 19:00</Text>
      <View style={[styles.setupDurationChild6, styles.setupChildLayout]} />
      <Text style={[styles.wateringDays, styles.wateringTypo1]}>
        Watering Day(s)
      </Text>
      <Text style={[styles.monWedFri, styles.weeklyTypo]}>
        Mon, Wed, Fri, Sun
      </Text>
      <View style={[styles.setupDurationChild7, styles.setupChildLayout]} />
      <Pressable
        style={[styles.rectanglePressable, styles.setupDurationChildBg]}
        onPress={() => navigation.navigate("SetupDuration11")}
      />
      <Text style={styles.confirm}>Confirm</Text>
      <Image
        style={styles.image40Icon}
        contentFit="cover"
        source={require("../assets/image-40.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  setupDurationChildBg: {
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    color: Color.colorBlack,
    top: 226,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout1: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 234,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  wateringTypo1: {
    height: 17,
    width: 81,
    textAlign: "left",
    color: Color.colorGray_100,
    fontFamily: FontFamily.istokWebItalic,
    fontStyle: "italic",
    left: 34,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  weeklyTypo: {
    height: 21,
    textAlign: "left",
    color: Color.colorBlack,
    left: 34,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  setupChildLayout: {
    width: 251,
    height: 1,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    left: 34,
    position: "absolute",
  },
  wateringTypo: {
    width: 98,
    height: 17,
    textAlign: "left",
    color: Color.colorGray_100,
    fontFamily: FontFamily.istokWebItalic,
    fontStyle: "italic",
    left: 34,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  text4Typo: {
    width: 110,
    height: 21,
    textAlign: "left",
    color: Color.colorBlack,
    left: 34,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  setupDurationChild: {
    top: 14,
    left: 0,
    width: 320,
    height: 39,
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupDurationItem: {
    left: 34,
    height: 28,
    width: 28,
    top: 219,
  },
  text: {
    left: 40,
  },
  setupDurationInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild1: {
    left: 109,
    height: 28,
    width: 28,
    top: 219,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild2: {
    left: 137,
  },
  setupDurationChild3: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    color: Color.colorGray_200,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    color: Color.colorGray_200,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  time: {
    left: 178,
    width: 40,
    color: Color.colorGray_200,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  wateringPeriod: {
    top: 292,
  },
  weekly: {
    top: 310,
    width: 54,
  },
  setupDurationChild4: {
    top: 330,
  },
  wateringDuration: {
    top: 381,
  },
  hours30Minutes: {
    top: 399,
  },
  setupDurationChild5: {
    top: 419,
  },
  wateringTime: {
    top: 426,
  },
  text4: {
    top: 444,
  },
  setupDurationChild6: {
    top: 464,
  },
  wateringDays: {
    top: 336,
  },
  monWedFri: {
    top: 354,
    width: 127,
  },
  setupDurationChild7: {
    top: 374,
  },
  rectanglePressable: {
    top: 517,
    left: 113,
    borderRadius: Border.br_8xs,
    width: 91,
    height: 23,
  },
  confirm: {
    top: 521,
    left: 119,
    width: 80,
    height: 14,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_2xs,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  image40Icon: {
    top: 83,
    left: 111,
    width: 100,
    height: 100,
    position: "absolute",
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration9;
