import * as React from "react";
import { StyleSheet, View, Text, Pressable, Linking } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const KnowledgeForOptimumSoilMoi = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.knowledgeForOptimumSoilMoi}>
      <View style={styles.knowledgeForOptimumSoilMoiChild} />
      <Text style={styles.thingsToKnow}>THINGS TO KNOW</Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth4")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <View
        style={[styles.knowledgeForOptimumSoilMoiItem, styles.soilPosition]}
      />
      <Text
        style={[styles.theOptimalRangeContainer, styles.plantsIconPosition]}
      >
        <Text style={styles.theOptimalRangeOfSoilMois}>
          The optimal range of soil moisture content for crops depends on the 
        </Text>
        <Text style={styles.theOptimalRangeOfSoilMois}>
          <Text style={styles.specificPlantSpecies1}>
            specific plant species
          </Text>
        </Text>
        <Text
          style={styles.theOptimalRangeOfSoilMois}
        >{`, but the range for most crops is between 20% and 60%.
`}</Text>
        <Text
          style={styles.volumetricWaterContent}
        >{`***Volumetric water content (VWC) equals the volume of water divided by the total soil volume
`}</Text>
        <Text style={styles.theOptimalRangeOfSoilMois}>{`
Example of common crops’ soil moisture:`}</Text>
      </Text>
      <Image
        style={[styles.plantsIcon, styles.plantsIconPosition]}
        contentFit="cover"
        source={require("../assets/4-plants.png")}
      />
      <Text style={[styles.impactOfSoil, styles.impactOfSoilTypo]}>
        Impact Of Soil Moisture On Plant Growth
      </Text>
      <Image
        style={styles.differentialSeasonalSoilMoiIcon}
        contentFit="cover"
        source={require("../assets/differentialseasonalsoilmoisture-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  soilPosition: {
    left: 31,
    position: "absolute",
  },
  plantsIconPosition: {
    width: 224,
    left: 48,
    position: "absolute",
  },
  impactOfSoilTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
  },
  knowledgeForOptimumSoilMoiChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.colorDarkolivegreen_100,
    width: 320,
    height: 39,
    position: "absolute",
  },
  thingsToKnow: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  knowledgeForOptimumSoilMoiItem: {
    top: 117,
    backgroundColor: Color.colorTan,
    width: 258,
    height: 548,
    borderRadius: Border.br_8xs,
  },
  theOptimalRangeOfSoilMois: {
    fontSize: FontSize.size_2xs,
  },
  specificPlantSpecies1: {
    textDecoration: "underline",
  },
  volumetricWaterContent: {
    fontSize: FontSize.size_4xs,
  },
  theOptimalRangeContainer: {
    top: 246,
    height: 153,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
  },
  plantsIcon: {
    top: 136,
    height: 98,
    borderRadius: Border.br_8xs,
  },
  impactOfSoil: {
    top: 72,
    fontSize: FontSize.size_mini,
    width: 219,
    height: 45,
    left: 31,
    position: "absolute",
  },
  differentialSeasonalSoilMoiIcon: {
    top: 393,
    left: 64,
    width: 194,
    height: 259,
    position: "absolute",
  },
  knowledgeForOptimumSoilMoi: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default KnowledgeForOptimumSoilMoi;
