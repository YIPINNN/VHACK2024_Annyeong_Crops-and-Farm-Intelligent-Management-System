import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const ConnectionError = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.connectionError}>
      <View style={styles.connectionErrorChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={styles.image29Icon}
        contentFit="cover"
        source={require("../assets/image-291.png")}
      />
      <Text style={[styles.errorInDetecting, styles.pleaseMakeSureTypo]}>
        Error in detecting sensor...
      </Text>
      <Text style={[styles.pleaseMakeSure, styles.pleaseMakeSureTypo]}>
        Please make sure Bluetooth is turned on.
      </Text>
      <Pressable
        style={styles.image30}
        onPress={() => navigation.navigate("ConnectSensor")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/image-30.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  pleaseMakeSureTypo: {
    height: 17,
    color: Color.colorBlack,
    fontSize: FontSize.size_4xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  connectionErrorChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    fontWeight: "700",
    fontFamily: FontFamily.istokWebBold,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  image29Icon: {
    top: 86,
    left: 110,
    width: 100,
    height: 100,
    position: "absolute",
  },
  errorInDetecting: {
    top: 239,
    left: 77,
    width: 165,
  },
  pleaseMakeSure: {
    top: 341,
    left: 69,
    width: 181,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  image30: {
    left: 135,
    top: 268,
    width: 40,
    height: 40,
    position: "absolute",
  },
  connectionError: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
    width: "100%",
  },
});

export default ConnectionError;
