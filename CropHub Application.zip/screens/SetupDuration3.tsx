import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const SetupDuration3 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <Image
        style={styles.setupDurationChild}
        contentFit="cover"
        source={require("../assets/ellipse-10.png")}
      />
      <View style={styles.setupDurationItem} />
      <Text style={[styles.irrigationSystem, styles.wateringTimeTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={[styles.sensor, styles.sensorLayout]}>Sensor</Text>
      <Image
        style={[styles.setupDurationInner, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-31.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.setupDurationChild1, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupDurationChild2, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild4, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <Image
        style={styles.image35Icon}
        contentFit="cover"
        source={require("../assets/image-35.png")}
      />
      <Text style={[styles.wateringTime, styles.wateringTimeTypo]}>
        Watering Time
      </Text>
      <Text style={[styles.scheduleWateringTimes, styles.sensorTypo]}>
        Schedule watering times during the day(s).
      </Text>
      <View
        style={[styles.addWateringTimeParent, styles.rectanglePressableLayout]}
      >
        <Text style={styles.addWateringTime}>Add watering time</Text>
        <Image
          style={[styles.image37Icon, styles.sensorLayout]}
          contentFit="cover"
          source={require("../assets/image-37.png")}
        />
      </View>
      <Pressable
        style={[styles.rectanglePressable, styles.rectanglePressableLayout]}
        onPress={() => navigation.navigate("SetupDuration4")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  wateringTimeTypo: {
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  sensorLayout: {
    height: 15,
    position: "absolute",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    fontSize: FontSize.size_2xs,
    top: 226,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    top: 234,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  sensorTypo: {
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
  },
  rectanglePressableLayout: {
    height: 21,
    position: "absolute",
  },
  setupDurationChild: {
    top: 75,
    left: 101,
    width: 100,
    height: 100,
    position: "absolute",
  },
  setupDurationItem: {
    top: 14,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    color: Color.colorWhite,
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
  },
  setupDurationInner: {
    left: 34,
  },
  text: {
    left: 40,
  },
  ellipseIcon: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  setupDurationChild1: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild2: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild3: {
    left: 137,
  },
  setupDurationChild4: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  image35Icon: {
    top: 91,
    left: 113,
    width: 75,
    height: 75,
    position: "absolute",
  },
  wateringTime: {
    top: 306,
    left: 98,
    fontSize: FontSize.size_sm,
    width: 131,
    color: Color.colorBlack,
  },
  scheduleWateringTimes: {
    top: 327,
    left: 58,
    width: 206,
    height: 14,
    color: Color.colorBlack,
    position: "absolute",
  },
  addWateringTime: {
    top: 1,
    left: 7,
    textDecoration: "underline",
    fontStyle: "italic",
    fontFamily: FontFamily.istokWebBoldItalic,
    width: 98,
    height: 20,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontWeight: "700",
    position: "absolute",
  },
  image37Icon: {
    top: 0,
    width: 15,
    left: 0,
  },
  addWateringTimeParent: {
    top: 352,
    left: 107,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 105,
  },
  rectanglePressable: {
    top: 349,
    left: 105,
    backgroundColor: Color.colorGainsboro_200,
    borderWidth: 0.5,
    width: 104,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    height: 21,
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration3;
