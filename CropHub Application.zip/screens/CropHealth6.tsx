import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const CropHealth6 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.cropHealth7}>
      <View style={[styles.cropHealth7Child, styles.childBg]} />
      <Text style={[styles.diagnosis, styles.diagnosisTypo]}>Diagnosis</Text>
      <View style={styles.cropHealth7Item} />
      <Text style={[styles.panamaDisease, styles.seeTreatmentTypo]}>
        Panama Disease
      </Text>
      <Text
        style={[styles.symptomsYellowingAnd, styles.diagnosisTypo]}
      >{`Symptoms
Yellowing and wilting of old leaves.
Leaves turn brown and collapse.
Splitting stem.
Yellowish to reddish streaks on stems.
Discoloration of internal tissues.

Symptoms can vary slightly depending on the banana variety, the strength of the pathogen and the environmental conditions. The disease affects older leaves first and moves gradually upwards to the younger ones. The disease is characterized by yellow and wilted leaves and petioles and the splitting of the base of the stem. Diseased leaves turn brown, dry and eventually collapse at the petiole, forming a "skirt" around the stem. Yellowish to reddish streaks are visible on the stems, becoming more intense at the base. Cross sections show a reddish to dark-brown discoloration of the internal tissues, an indication of fungal growth and rotting of tissue. Eventually, all parts above and below ground rot and die.`}</Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth5")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow1.png")}
        />
      </Pressable>
      <Image
        style={styles.panamaDisease3InitialExt}
        contentFit="cover"
        source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-2.png")}
      />
      <Pressable
        style={[styles.button, styles.buttonLayout]}
        onPress={() => navigation.navigate("CropHealth7")}
      >
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={[styles.seeTreatment, styles.seeTreatmentTypo]}>
          See Treatment
        </Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  childBg: {
    backgroundColor: Color.forest2,
    left: 0,
  },
  diagnosisTypo: {
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  seeTreatmentTypo: {
    textAlign: "left",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 180,
    position: "absolute",
  },
  cropHealth7Child: {
    top: 14,
    width: 320,
    height: 39,
    position: "absolute",
  },
  diagnosis: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    textAlign: "center",
    width: 228,
    height: 19,
    color: Color.colorWhite,
  },
  cropHealth7Item: {
    top: 79,
    left: 23,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorTan,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 273,
    height: 617,
    position: "absolute",
  },
  panamaDisease: {
    top: 89,
    left: 36,
    fontSize: FontSize.size_lg,
    width: 232,
    height: 24,
    color: Color.colorBlack,
  },
  symptomsYellowingAnd: {
    top: 259,
    left: 35,
    fontSize: FontSize.size_xs,
    textAlign: "justify",
    width: 253,
    height: 478,
    color: Color.colorBlack,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  panamaDisease3InitialExt: {
    top: 115,
    left: 34,
    width: 254,
    height: 138,
    position: "absolute",
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest2,
    left: 0,
  },
  seeTreatment: {
    top: 5,
    left: 48,
    fontSize: FontSize.size_smi,
    width: 97,
    color: Color.colorWhite,
  },
  button: {
    top: 657,
    left: 70,
  },
  cropHealth7: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default CropHealth6;
