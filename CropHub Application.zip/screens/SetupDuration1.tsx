import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const SetupDuration1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <View style={styles.setupDurationChild} />
      <Text style={[styles.irrigationSystem, styles.irrigationSystemTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupDurationItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo2]}>1</Text>
      <Image
        style={[styles.setupDurationInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo1]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo1]}>4</Text>
      <Image
        style={[styles.setupDurationChild1, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Text style={[styles.text3, styles.textTypo2]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild2, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.ellipseParent, styles.groupChildLayout]}>
        <Image
          style={[styles.groupChild, styles.groupChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-8.png")}
        />
        <Image
          style={styles.image34Icon}
          contentFit="cover"
          source={require("../assets/image-34.png")}
        />
      </View>
      <Text style={[styles.wateringDuration, styles.irrigationSystemTypo]}>
        Watering Duration
      </Text>
      <Text style={styles.decideHowLong}>
        Decide how long each watering should last.
      </Text>
      <Pressable
        style={[styles.rectanglePressable, styles.rectangleLayout]}
        onPress={() => navigation.navigate("SetupDuration2")}
      />
      <View style={[styles.rectangleView, styles.rectangleLayout]} />
      <Text style={[styles.hours, styles.hoursTypo]}>hours</Text>
      <Text style={[styles.minutes, styles.hoursTypo]}>minutes</Text>
      <Text style={[styles.text4, styles.textTypo]}>|</Text>
      <Text style={[styles.text5, styles.textTypo]}>|</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  irrigationSystemTypo: {
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo2: {
    width: 16,
    fontSize: FontSize.size_2xs,
    top: 226,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo1: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 234,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  groupChildLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  rectangleLayout: {
    height: 21,
    width: 26,
    borderWidth: 0.5,
    backgroundColor: Color.colorGainsboro_200,
    top: 358,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  hoursTypo: {
    height: 17,
    width: 43,
    top: 362,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo: {
    height: 13,
    width: 12,
    textAlign: "left",
    top: 360,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  setupDurationChild: {
    top: 14,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    width: 228,
    color: Color.colorWhite,
    fontSize: FontSize.size_xs,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupDurationItem: {
    left: 34,
  },
  text: {
    left: 40,
  },
  setupDurationInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild1: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild2: {
    left: 137,
  },
  setupDurationChild3: {
    left: 212,
  },
  period: {
    left: 28,
    color: Color.colorGray_200,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  groupChild: {
    top: 0,
    left: 0,
  },
  image34Icon: {
    top: 28,
    left: 25,
    width: 50,
    height: 50,
    position: "absolute",
  },
  ellipseParent: {
    top: 82,
    left: 111,
  },
  wateringDuration: {
    top: 308,
    left: 97,
    fontSize: FontSize.size_sm,
    width: 131,
    color: Color.colorBlack,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  decideHowLong: {
    top: 329,
    left: 65,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    position: "absolute",
  },
  rectanglePressable: {
    left: 94,
  },
  rectangleView: {
    left: 159,
  },
  hours: {
    left: 116,
  },
  minutes: {
    left: 188,
  },
  text4: {
    left: 99,
  },
  text5: {
    left: 164,
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration1;
