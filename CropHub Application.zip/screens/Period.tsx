import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily } from "../GlobalStyles";

const Period = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.period}>
      <View style={styles.periodChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.periodItem, styles.periodLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.periodInner, styles.periodInnerPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.periodInnerPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.periodChild1, styles.periodLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.periodChildLayout]} />
      <View style={[styles.periodChild2, styles.periodChildLayout]} />
      <View style={[styles.periodChild3, styles.periodChildLayout]} />
      <Text style={[styles.period1, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.rectangleView, styles.periodChild4Layout]} />
      <Pressable
        style={[styles.image32, styles.imageLayout]}
        onPress={() => navigation.navigate("SetupWeekly")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/image-32.png")}
        />
      </Pressable>
      <Text style={[styles.weekly, styles.weeklyTypo]}>Weekly</Text>
      <Text style={[styles.waterOnSpecific, styles.setARegularTypo]}>
        Water on specific days and times.
      </Text>
      <View style={[styles.periodChild4, styles.periodChild4Layout]} />
      <Pressable
        style={[styles.image33, styles.imageLayout]}
        onPress={() => navigation.navigate("SetupCyclical")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/image-33.png")}
        />
      </Pressable>
      <Text style={[styles.cyclical, styles.weeklyTypo]}>Cyclical</Text>
      <Text style={[styles.setARegular, styles.setARegularTypo]}>
        Set a regular watering interval.
      </Text>
      <View style={[styles.ellipseParent, styles.groupChildLayout]}>
        <Image
          style={[styles.groupChild, styles.groupChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={styles.image36Icon}
          contentFit="cover"
          source={require("../assets/image-36.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  periodLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    top: 226,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  periodInnerPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  periodChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 234,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  periodChild4Layout: {
    height: 110,
    width: 110,
    borderWidth: 1,
    backgroundColor: Color.colorGainsboro_200,
    top: 295,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  imageLayout: {
    height: 50,
    width: 50,
    top: 303,
    position: "absolute",
  },
  weeklyTypo: {
    width: 71,
    top: 357,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setARegularTypo: {
    height: 23,
    width: 82,
    top: 376,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  groupChildLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  periodChild: {
    top: 14,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  periodItem: {
    left: 34,
  },
  text: {
    left: 40,
  },
  periodInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  periodChild1: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  periodChild2: {
    left: 137,
  },
  periodChild3: {
    left: 212,
  },
  period1: {
    left: 28,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  rectangleView: {
    left: 32,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  image32: {
    left: 61,
  },
  weekly: {
    left: 52,
  },
  waterOnSpecific: {
    left: 46,
  },
  periodChild4: {
    left: 175,
  },
  image33: {
    left: 204,
  },
  cyclical: {
    left: 195,
  },
  setARegular: {
    left: 189,
  },
  groupChild: {
    top: 0,
    left: 0,
  },
  image36Icon: {
    top: 19,
    left: 18,
    width: 65,
    height: 67,
    position: "absolute",
  },
  ellipseParent: {
    top: 82,
    left: 111,
  },
  period: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
    width: "100%",
  },
});

export default Period;
