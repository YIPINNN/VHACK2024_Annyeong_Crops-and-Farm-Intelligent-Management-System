import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const CheckForPest = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={styles.checkForPest}
      onPress={() => navigation.navigate("PestMonitoringResult")}
    >
      <View style={styles.checkForPestChild} />
      <Text style={styles.soil}>SOIL</Text>
      <Image
        style={styles.image6Icon}
        contentFit="cover"
        source={require("../assets/image-61.png")}
      />
      <View style={styles.checkForPestItem} />
      <Text
        style={[styles.soilMoistureTemperature, styles.areaCodeA005Typo]}
      >{`Soil moisture
Temperature
Soil pH
Nitrogen
Phosphorus
Potassium`}</Text>
      <Text style={styles.c5514}>{`52 %
23 °C
5.5
14 ppm
26 ppm
167 ppm`}</Text>
      <Image
        style={[styles.latemperatureHighIcon, styles.areaCodeA005Position]}
        contentFit="cover"
        source={require("../assets/latemperaturehigh1.png")}
      />
      <Image
        style={[styles.letsIconswater, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/letsiconswater1.png")}
      />
      <Image
        style={styles.mdiphIcon}
        contentFit="cover"
        source={require("../assets/mdiph1.png")}
      />
      <Image
        style={[styles.mdialphaNCircleIcon, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/mdialphancircle1.png")}
      />
      <Image
        style={styles.emojioneMonotoneletterPIcon}
        contentFit="cover"
        source={require("../assets/emojionemonotoneletterp1.png")}
      />
      <Image
        style={[styles.mdialphaKCircleIcon, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/mdialphakcircle1.png")}
      />
      <Text
        style={[styles.areaCodeA005, styles.areaCodeA005Position]}
      >{`Area code: A-005
Sensor code: S-112`}</Text>
      <View
        style={[styles.checkForPestInner, styles.checkForPestInnerPosition]}
      />
      <Text style={[styles.checkForPest1, styles.areaCodeA005Typo]}>
        Check for pest
      </Text>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector3.png")}
      />
      <Image
        style={styles.loadingIcon}
        contentFit="cover"
        source={require("../assets/loading.png")}
      />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  areaCodeA005Typo: {
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  areaCodeA005Position: {
    left: 48,
    position: "absolute",
  },
  mdialphaIconPosition: {
    left: 49,
    position: "absolute",
    overflow: "hidden",
  },
  checkForPestInnerPosition: {
    left: 79,
    position: "absolute",
  },
  checkForPestChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.olive3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  soil: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    width: 228,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorWhite,
    position: "absolute",
  },
  image6Icon: {
    top: 82,
    left: 113,
    width: 94,
    height: 95,
    position: "absolute",
  },
  checkForPestItem: {
    top: 252,
    left: 31,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorDarkkhaki_100,
    width: 258,
    height: 218,
    position: "absolute",
  },
  soilMoistureTemperature: {
    width: 114,
    color: Color.colorBlack,
    left: 79,
    position: "absolute",
    top: 272,
    textAlign: "left",
  },
  c5514: {
    left: 223,
    width: 48,
    height: 178,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    top: 272,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  latemperatureHighIcon: {
    top: 298,
    width: 23,
    height: 22,
    overflow: "hidden",
  },
  letsIconswater: {
    top: 269,
    width: 18,
    height: 17,
  },
  mdiphIcon: {
    top: 327,
    left: 46,
    width: 24,
    height: 24,
    position: "absolute",
    overflow: "hidden",
  },
  mdialphaNCircleIcon: {
    top: 360,
    width: 22,
    height: 22,
  },
  emojioneMonotoneletterPIcon: {
    top: 393,
    left: 50,
    width: 20,
    height: 20,
    position: "absolute",
    overflow: "hidden",
  },
  mdialphaKCircleIcon: {
    top: 422,
    width: 21,
    height: 22,
  },
  areaCodeA005: {
    top: 210,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorBlack,
  },
  checkForPestInner: {
    top: 496,
    borderRadius: Border.br_xs,
    backgroundColor: Color.olive4,
    width: 162,
    height: 27,
  },
  checkForPest1: {
    top: 503,
    left: 117,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.48%",
    width: "4.34%",
    top: "88.38%",
    right: "34.41%",
    bottom: "9.14%",
    left: "61.25%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  loadingIcon: {
    top: 280,
    left: 119,
    width: 82,
    height: 86,
    position: "absolute",
  },
  checkForPest: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default CheckForPest;
