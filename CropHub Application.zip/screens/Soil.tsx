import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Soil = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.soil, styles.soilLayout]}>
      <View style={styles.soilChild} />
      <Text style={styles.soil1}>SOIL</Text>
      <Image
        style={styles.image6Icon}
        contentFit="cover"
        source={require("../assets/image-6.png")}
      />
      <View style={styles.soilItem} />
      <Text
        style={[styles.soilMoistureTemperature, styles.areaCodeA005Typo]}
      >{`Soil moisture
Temperature
Soil pH
Nitrogen
Phosphorus
Potassium`}</Text>
      <Text style={styles.c5514}>{`52 %
23 °C
5.5
14 ppm
26 ppm
167 ppm`}</Text>
      <Image
        style={[styles.latemperatureHighIcon, styles.areaCodeA005Position]}
        contentFit="cover"
        source={require("../assets/latemperaturehigh.png")}
      />
      <Image
        style={[styles.letsIconswater, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/letsiconswater.png")}
      />
      <Image
        style={styles.mdiphIcon}
        contentFit="cover"
        source={require("../assets/mdiph.png")}
      />
      <Image
        style={[styles.mdialphaNCircleIcon, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/mdialphancircle.png")}
      />
      <Image
        style={styles.emojioneMonotoneletterPIcon}
        contentFit="cover"
        source={require("../assets/emojionemonotoneletterp.png")}
      />
      <Image
        style={[styles.mdialphaKCircleIcon, styles.mdialphaIconPosition]}
        contentFit="cover"
        source={require("../assets/mdialphakcircle.png")}
      />
      <Text
        style={[styles.areaCodeA005, styles.areaCodeA005Position]}
      >{`Area code: A-005
Sensor code: S-112`}</Text>
      <Pressable
        style={[styles.soilInner, styles.soilPosition]}
        onPress={() => navigation.navigate("CheckForPest")}
      />
      <Text style={[styles.checkForPest, styles.areaCodeA005Typo]}>
        Check for pest
      </Text>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.soilLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  soilLayout: {
    width: "100%",
    overflow: "hidden",
  },
  areaCodeA005Typo: {
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  areaCodeA005Position: {
    left: 48,
    position: "absolute",
  },
  mdialphaIconPosition: {
    left: 49,
    position: "absolute",
    overflow: "hidden",
  },
  soilPosition: {
    left: 79,
    position: "absolute",
  },
  soilChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.olive3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  soil1: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    width: 228,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorWhite,
    position: "absolute",
  },
  image6Icon: {
    top: 82,
    left: 113,
    width: 94,
    height: 95,
    position: "absolute",
  },
  soilItem: {
    top: 252,
    left: 31,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorDarkkhaki_100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 258,
    height: 218,
    position: "absolute",
  },
  soilMoistureTemperature: {
    width: 114,
    color: Color.colorBlack,
    left: 79,
    position: "absolute",
    top: 272,
    textAlign: "left",
  },
  c5514: {
    left: 223,
    width: 48,
    height: 178,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    top: 272,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  latemperatureHighIcon: {
    top: 298,
    width: 23,
    height: 22,
    overflow: "hidden",
  },
  letsIconswater: {
    top: 269,
    width: 18,
    height: 17,
  },
  mdiphIcon: {
    top: 327,
    left: 46,
    width: 24,
    height: 24,
    position: "absolute",
    overflow: "hidden",
  },
  mdialphaNCircleIcon: {
    top: 360,
    width: 22,
    height: 22,
  },
  emojioneMonotoneletterPIcon: {
    top: 393,
    left: 50,
    width: 20,
    height: 20,
    position: "absolute",
    overflow: "hidden",
  },
  mdialphaKCircleIcon: {
    top: 422,
    width: 21,
    height: 22,
  },
  areaCodeA005: {
    top: 210,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorBlack,
  },
  soilInner: {
    top: 496,
    borderRadius: Border.br_xs,
    backgroundColor: Color.olive4,
    width: 162,
    height: 27,
  },
  checkForPest: {
    top: 503,
    left: 117,
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  vectorIcon: {
    height: "2.48%",
    width: "4.34%",
    top: "88.38%",
    right: "34.41%",
    bottom: "9.14%",
    left: "61.25%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  soil: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
  },
});

export default Soil;
