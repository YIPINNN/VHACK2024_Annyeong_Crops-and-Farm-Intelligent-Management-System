import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CropHealth5 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.cropHealth6}>
      <View style={[styles.cropHealth6Child, styles.childBg]} />
      <Text style={styles.results}>Results</Text>
      <View style={[styles.cropHealth6Item, styles.cropShadowBox]} />
      <Pressable
        style={[styles.button, styles.buttonLayout]}
        onPress={() => navigation.navigate("CropHealth6")}
      >
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.seeDiagnosis}>See Diagnosis</Text>
      </Pressable>
      <Text
        style={[
          styles.panamaDiseaseSymptomsContainer,
          styles.symptomsContainerPosition,
        ]}
      >
        <Text style={styles.panamaDisease}>{`Panama Disease
`}</Text>
        <Text style={styles.symptomsYellowingAndWilting}>{`Symptoms
Yellowing and wilting of old leaves.
Leaves turn brown and collapse.
Splitting stem.
Yellowish to reddish streaks on stems.
Discoloration of internal tissues.`}</Text>
      </Text>
      <View style={[styles.cropHealth6Inner, styles.cropShadowBox]} />
      <View style={[styles.button1, styles.buttonLayout]}>
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.seeDiagnosis}>See Diagnosis</Text>
      </View>
      <Text
        style={[
          styles.potassiumDeficiencySymptomsContainer,
          styles.symptomsContainerPosition,
        ]}
      >
        <Text style={styles.panamaDisease}>{`Potassium Deficiency
`}</Text>
        <Text style={styles.symptomsYellowingAndWilting}>{`Symptoms
Yellowing of leaves starts from margins.
Main veins remain dark green.
Curled leaves.
Stunted growth`}</Text>
      </Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth4")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <Image
        style={[styles.panamaDisease3InitialExt, styles.panamaPosition]}
        contentFit="cover"
        source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-1.png")}
      />
      <Image
        style={[styles.panamaDisease2InternalBr, styles.panamaPosition]}
        contentFit="cover"
        source={require("../assets/panama-disease-2--internal-browning-of-stems-and-corms-is-the-key-diagnostic-symptom-of-panama-disease-daf-qld-1.png")}
      />
      <Image
        style={styles.bPota11Icon}
        contentFit="cover"
        source={require("../assets/b-pota1-1.png")}
      />
      <Image
        style={styles.unnamed1Icon}
        contentFit="cover"
        source={require("../assets/unnamed-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  childBg: {
    backgroundColor: Color.forest2,
    left: 0,
  },
  cropShadowBox: {
    width: 274,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 23,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 180,
    position: "absolute",
  },
  symptomsContainerPosition: {
    color: Color.colorBlack,
    left: 36,
    textAlign: "left",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  panamaPosition: {
    height: 135,
    top: 220,
    position: "absolute",
  },
  cropHealth6Child: {
    top: 14,
    width: 320,
    height: 39,
    position: "absolute",
  },
  results: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    textAlign: "center",
    width: 228,
    height: 19,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cropHealth6Item: {
    top: 79,
    height: 329,
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest2,
    left: 0,
  },
  seeDiagnosis: {
    top: 5,
    fontSize: FontSize.size_smi,
    width: 97,
    textAlign: "left",
    left: 48,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  button: {
    top: 368,
    left: 64,
  },
  panamaDisease: {
    fontSize: FontSize.size_lg,
  },
  symptomsYellowingAndWilting: {
    fontSize: FontSize.size_xs,
  },
  panamaDiseaseSymptomsContainer: {
    top: 89,
    width: 235,
    height: 127,
  },
  cropHealth6Inner: {
    top: 470,
    height: 287,
  },
  button1: {
    top: 720,
    left: 70,
  },
  potassiumDeficiencySymptomsContainer: {
    top: 480,
    width: 222,
    height: 305,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  panamaDisease3InitialExt: {
    width: 109,
    left: 48,
  },
  panamaDisease2InternalBr: {
    left: 159,
    width: 116,
  },
  bPota11Icon: {
    top: 705,
    width: 162,
    height: 104,
    left: 48,
    position: "absolute",
  },
  unnamed1Icon: {
    top: 601,
    left: 213,
    width: 65,
    height: 105,
    position: "absolute",
  },
  cropHealth6: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default CropHealth5;
