import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const SetupDuration7 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <View style={[styles.setupDurationChild, styles.setupChildLayout2]} />
      <Image
        style={styles.setupDurationItem}
        contentFit="cover"
        source={require("../assets/ellipse-10.png")}
      />
      <View style={[styles.setupDurationInner, styles.rectangleViewBg]} />
      <Text style={[styles.irrigationSystem, styles.wateringTimeTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={[styles.sensor, styles.sensorLayout]}>Sensor</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo2]}>1</Text>
      <Image
        style={[styles.setupDurationChild1, styles.setupChildPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-31.png")}
      />
      <Text style={[styles.text1, styles.textTypo1]}>3</Text>
      <Image
        style={[styles.setupDurationChild2, styles.setupChildPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo1]}>4</Text>
      <Image
        style={[styles.setupDurationChild3, styles.ellipseIconLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text3, styles.textTypo2]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout1]} />
      <View style={[styles.setupDurationChild4, styles.setupChildLayout1]} />
      <View style={[styles.setupDurationChild5, styles.setupChildLayout1]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.rectangleView, styles.rectangleViewBg]} />
      <Text style={[styles.next, styles.nextLayout]}>Next</Text>
      <Image
        style={styles.image35Icon}
        contentFit="cover"
        source={require("../assets/image-35.png")}
      />
      <Text style={[styles.wateringTime, styles.wateringTimeTypo]}>
        Watering Time
      </Text>
      <Text style={[styles.scheduleWateringTimes, styles.nextLayout]}>
        Schedule watering times during the day(s).
      </Text>
      <Text style={[styles.cancel, styles.cancelTypo]}>CANCEL</Text>
      <View
        style={[styles.addWateringTimeParent, styles.rectanglePressableLayout]}
      >
        <Text style={styles.addWateringTime}>Add watering time</Text>
        <Image
          style={[styles.image37Icon, styles.sensorLayout]}
          contentFit="cover"
          source={require("../assets/image-37.png")}
        />
      </View>
      <Pressable
        style={[styles.rectanglePressable, styles.rectanglePressableLayout]}
        onPress={() => navigation.navigate("SetupDuration10")}
      />
      <View style={[styles.setupDurationChild6, styles.setupChildLayout]} />
      <Text style={[styles.text4, styles.textTypo]}>07:00</Text>
      <View style={[styles.setupDurationChild7, styles.setupChildLayout2]} />
      <Text style={[styles.cancel1, styles.cancelTypo]}>CANCEL</Text>
      <View style={[styles.setupDurationChild8, styles.setupChildLayout]} />
      <Text style={[styles.text5, styles.textTypo]}>13:00</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  setupChildLayout2: {
    height: 17,
    width: 42,
    backgroundColor: Color.colorPink,
    borderRadius: Border.br_10xs,
    left: 235,
    position: "absolute",
  },
  rectangleViewBg: {
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  wateringTimeTypo: {
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    textAlign: "center",
    position: "absolute",
  },
  sensorLayout: {
    height: 15,
    position: "absolute",
  },
  ellipseIconLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo2: {
    width: 16,
    top: 226,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo1: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout1: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    top: 234,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  nextLayout: {
    height: 14,
    textAlign: "center",
    position: "absolute",
  },
  cancelTypo: {
    width: 55,
    color: Color.colorFirebrick,
    fontSize: FontSize.size_5xs,
    left: 229,
    height: 12,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  rectanglePressableLayout: {
    height: 21,
    position: "absolute",
  },
  setupChildLayout: {
    width: 262,
    left: 29,
    height: 1,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  textTypo: {
    height: 22,
    width: 65,
    fontSize: FontSize.size_lg,
    color: Color.colorBlack,
    left: 34,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setupDurationChild: {
    top: 361,
  },
  setupDurationItem: {
    top: 75,
    left: 101,
    width: 100,
    height: 100,
    position: "absolute",
  },
  setupDurationInner: {
    top: 14,
    width: 320,
    height: 39,
    left: 0,
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    color: Color.colorWhite,
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  sensor: {
    top: 59,
    left: 272,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    height: 15,
    color: Color.colorWhite,
    width: 42,
  },
  ellipseIcon: {
    left: 34,
    height: 28,
    width: 28,
    top: 219,
  },
  text: {
    left: 40,
  },
  setupDurationChild1: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  setupDurationChild2: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild3: {
    left: 109,
    height: 28,
    width: 28,
    top: 219,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild4: {
    left: 137,
  },
  setupDurationChild5: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorGray_200,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
  },
  rectangleView: {
    top: 505,
    left: 114,
    borderRadius: Border.br_8xs,
    width: 91,
    height: 23,
  },
  next: {
    top: 509,
    left: 120,
    width: 80,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_2xs,
    height: 14,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  image35Icon: {
    top: 91,
    left: 113,
    width: 75,
    height: 75,
    position: "absolute",
  },
  wateringTime: {
    top: 306,
    left: 98,
    fontSize: FontSize.size_sm,
    width: 131,
    color: Color.colorBlack,
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  scheduleWateringTimes: {
    top: 327,
    left: 58,
    width: 206,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  cancel: {
    top: 364,
  },
  addWateringTime: {
    top: 1,
    left: 7,
    textDecoration: "underline",
    fontStyle: "italic",
    fontFamily: FontFamily.istokWebBoldItalic,
    width: 98,
    height: 20,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontWeight: "700",
    position: "absolute",
  },
  image37Icon: {
    top: 0,
    width: 15,
    left: 0,
  },
  addWateringTimeParent: {
    top: 435,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 105,
    left: 109,
  },
  rectanglePressable: {
    top: 432,
    left: 107,
    backgroundColor: Color.colorGainsboro_200,
    borderWidth: 0.5,
    width: 104,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    height: 21,
  },
  setupDurationChild6: {
    top: 386,
  },
  text4: {
    top: 358,
  },
  setupDurationChild7: {
    top: 396,
  },
  cancel1: {
    top: 399,
  },
  setupDurationChild8: {
    top: 421,
  },
  text5: {
    top: 393,
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration7;
