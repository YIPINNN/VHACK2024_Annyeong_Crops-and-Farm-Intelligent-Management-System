import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const CropHealth1 = () => {
  return (
    <View style={styles.cropHealth4}>
      <View style={[styles.cropHealth4Child, styles.childBg]} />
      <Text style={[styles.diagnosis, styles.diagnosisLayout]}>Diagnosis</Text>
      <View style={styles.cropHealth4Item} />
      <View style={[styles.button, styles.buttonLayout]}>
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.seeTreatment}>See Treatment</Text>
      </View>
      <Text style={[styles.nameOfDisease, styles.nameOfDiseasePosition]}>
        Name of Disease
      </Text>
      <Text
        style={[styles.symptomsListOf, styles.nameOfDiseasePosition]}
      >{`Symptoms
List of symptoms
List of symptoms
List of symptoms
List of symptoms

Explanation of the disease in details`}</Text>
      <Image
        style={[styles.pictureIcon, styles.diagnosisLayout]}
        contentFit="cover"
        source={require("../assets/picture2.png")}
      />
      <Image
        style={styles.makiarrowIcon}
        contentFit="cover"
        source={require("../assets/makiarrow1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  childBg: {
    backgroundColor: Color.forest2,
    left: 0,
  },
  diagnosisLayout: {
    width: 228,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 180,
    position: "absolute",
  },
  nameOfDiseasePosition: {
    color: Color.colorBlack,
    left: 36,
    textAlign: "left",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cropHealth4Child: {
    top: 14,
    width: 320,
    height: 39,
    position: "absolute",
  },
  diagnosis: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    textAlign: "center",
    height: 19,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    width: 228,
  },
  cropHealth4Item: {
    top: 79,
    left: 23,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorTan,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 277,
    height: 408,
    position: "absolute",
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest2,
    left: 0,
  },
  seeTreatment: {
    top: 5,
    left: 48,
    fontSize: FontSize.size_smi,
    width: 97,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  button: {
    top: 532,
    left: 70,
  },
  nameOfDisease: {
    top: 89,
    fontSize: FontSize.size_lg,
    width: 232,
    height: 24,
  },
  symptomsListOf: {
    top: 284,
    fontSize: FontSize.size_xs,
    width: 230,
    height: 108,
  },
  pictureIcon: {
    top: 128,
    left: 46,
    height: 143,
  },
  makiarrowIcon: {
    top: 23,
    left: 12,
    width: 24,
    height: 21,
    overflow: "hidden",
    position: "absolute",
  },
  cropHealth4: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
  },
});

export default CropHealth1;
