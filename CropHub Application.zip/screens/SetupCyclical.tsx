import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SetupCyclical = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupCyclical}>
      <View style={styles.setupCyclicalChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupCyclicalItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupCyclicalInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupCyclicalChild1, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupCyclicalChild2, styles.setupChildLayout]} />
      <View style={[styles.setupCyclicalChild3, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <Image
        style={[styles.image32Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-32.png")}
      />
      <Text style={[styles.weekly, styles.cyclicalTypo]}>Weekly</Text>
      <Text style={[styles.waterOnSpecific, styles.setARegularLayout]}>
        Water on specific days.
      </Text>
      <View style={[styles.setupCyclicalChild4, styles.rectangleViewLayout]} />
      <Image
        style={[styles.image33Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-33.png")}
      />
      <Text style={[styles.cyclical, styles.cyclicalTypo]}>Cyclical</Text>
      <Text style={[styles.cyclical1, styles.cyclicalTypo]}>Cyclical</Text>
      <Text style={[styles.setARegular, styles.setARegularLayout]}>
        Set a regular watering interval.
      </Text>
      <Text style={styles.irrigateEvery}>Irrigate every</Text>
      <Text style={[styles.text4, styles.daysTypo]}>|</Text>
      <Text style={[styles.days, styles.daysTypo]}>days.</Text>
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("SetupCyclical1")}
      />
      <View style={[styles.setupCyclicalChild5, styles.setARegularLayout]} />
      <Text style={styles.next}>Next</Text>
      <View style={[styles.ellipseParent, styles.groupChildLayout]}>
        <Image
          style={[styles.groupChild, styles.groupChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-9.png")}
        />
        <Image
          style={styles.image36Icon}
          contentFit="cover"
          source={require("../assets/image-36.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    color: Color.colorBlack,
    top: 226,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    top: 234,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 110,
    width: 110,
    borderWidth: 1,
    top: 295,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  iconLayout: {
    height: 50,
    width: 50,
    top: 303,
    position: "absolute",
  },
  cyclicalTypo: {
    width: 71,
    color: Color.colorBlack,
    height: 15,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setARegularLayout: {
    height: 23,
    position: "absolute",
  },
  daysTypo: {
    textAlign: "left",
    height: 13,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  groupChildLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  setupCyclicalChild: {
    top: 14,
    width: 320,
    height: 39,
    backgroundColor: Color.forest3,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupCyclicalItem: {
    left: 34,
  },
  text: {
    left: 40,
  },
  setupCyclicalInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupCyclicalChild1: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupCyclicalChild2: {
    left: 137,
  },
  setupCyclicalChild3: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    fontSize: FontSize.size_4xs,
    top: 254,
  },
  rectangleView: {
    left: 32,
    backgroundColor: Color.colorGainsboro_200,
  },
  image32Icon: {
    left: 61,
  },
  weekly: {
    left: 52,
    top: 357,
    width: 71,
    fontSize: FontSize.size_2xs,
  },
  waterOnSpecific: {
    left: 46,
    width: 82,
    top: 376,
    height: 23,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  setupCyclicalChild4: {
    left: 175,
    backgroundColor: Color.colorBeige_100,
  },
  image33Icon: {
    left: 204,
  },
  cyclical: {
    left: 195,
    top: 357,
    width: 71,
    fontSize: FontSize.size_2xs,
  },
  cyclical1: {
    top: 426,
    left: 124,
    fontSize: FontSize.size_sm,
  },
  setARegular: {
    left: 189,
    width: 82,
    top: 376,
    height: 23,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  irrigateEvery: {
    left: 82,
    width: 77,
    height: 13,
    top: 455,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  text4: {
    top: 454,
    left: 169,
    width: 12,
  },
  days: {
    left: 197,
    width: 41,
    top: 455,
    textAlign: "left",
  },
  rectanglePressable: {
    top: 452,
    left: 164,
    borderWidth: 0.5,
    width: 26,
    height: 21,
    backgroundColor: Color.colorGainsboro_200,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  setupCyclicalChild5: {
    top: 505,
    left: 114,
    borderRadius: Border.br_8xs,
    width: 91,
    backgroundColor: Color.forest3,
  },
  next: {
    top: 509,
    left: 120,
    width: 80,
    height: 14,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_2xs,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
  },
  image36Icon: {
    top: 19,
    left: 18,
    width: 65,
    height: 67,
    position: "absolute",
  },
  ellipseParent: {
    top: 82,
    left: 111,
  },
  setupCyclical: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupCyclical;
