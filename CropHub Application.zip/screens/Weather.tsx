import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const Weather = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.weather, styles.iconLayout5]}>
      <LinearGradient
        style={[styles.weatherChild, styles.weatherChildShadowBox]}
        locations={[0, 1]}
        colors={["#fdedbc", "#fff"]}
      />
      <View style={[styles.weatherItem, styles.weatherPosition]} />
      <View style={styles.weatherInner} />
      <Text style={styles.weather1}>WEATHER</Text>
      <Image
        style={styles.image1Icon}
        contentFit="cover"
        source={require("../assets/image-1.png")}
      />
      <LinearGradient
        style={[styles.rectangleLineargradient, styles.weatherChildShadowBox]}
        locations={[0, 1]}
        colors={["rgba(144, 224, 239, 0.57)", "rgba(251, 248, 240, 0.57)"]}
      />
      <Text style={[styles.text, styles.textTypo2]}>93%</Text>
      <Text style={[styles.c, styles.textTypo2]}>27°C</Text>
      <Text style={[styles.thu, styles.thuTypo]}>Thu</Text>
      <Text style={[styles.upcomingDays, styles.upcomingDaysLayout]}>
        Upcoming Days
      </Text>
      <Text style={styles.mon}>Mon</Text>
      <Text style={[styles.tue, styles.thuTypo]}>Tue</Text>
      <Text style={[styles.wed, styles.thuTypo]}>Wed</Text>
      <Text style={[styles.mac2024Sunday, styles.upcomingDaysLayout]}>
        10 Mac 2024, Sunday
      </Text>
      <Image
        style={styles.phwindFillIcon}
        contentFit="cover"
        source={require("../assets/phwindfill.png")}
      />
      <Image
        style={[styles.carbontemperatureHotIcon, styles.iconLayout4]}
        contentFit="cover"
        source={require("../assets/carbontemperaturehot.png")}
      />
      <Image
        style={[styles.mdihumidityOutlineIcon, styles.iconLayout4]}
        contentFit="cover"
        source={require("../assets/mdihumidityoutline.png")}
      />
      <Image
        style={styles.image3Icon}
        contentFit="cover"
        source={require("../assets/image-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo1]}>12:00</Text>
      <Text style={[styles.text2, styles.textTypo1]}>16:00</Text>
      <Text style={[styles.text3, styles.textTypo1]}>15:00</Text>
      <Text style={[styles.text4, styles.textTypo1]}>14:00</Text>
      <Text style={[styles.text5, styles.textTypo1]}>13:00</Text>
      <Image
        style={[styles.image4Icon, styles.iconLayout3]}
        contentFit="cover"
        source={require("../assets/image-4.png")}
      />
      <Image
        style={[styles.image18Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/image-18.png")}
      />
      <Image
        style={[styles.image19Icon, styles.iconLayout2]}
        contentFit="cover"
        source={require("../assets/image-18.png")}
      />
      <Image
        style={styles.image5Icon}
        contentFit="cover"
        source={require("../assets/image-5.png")}
      />
      <Image
        style={[styles.image10Icon, styles.iconPosition1]}
        contentFit="cover"
        source={require("../assets/image-10.png")}
      />
      <Text style={[styles.ms, styles.msTypo]}>4.0 m/s</Text>
      <Text style={[styles.ms1, styles.msTypo]}>4.5 m/s</Text>
      <Image
        style={styles.image22Icon}
        contentFit="cover"
        source={require("../assets/image-22.png")}
      />
      <Text style={styles.ms2}>4.5 m/s</Text>
      <Image
        style={[styles.image23Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/image-23.png")}
      />
      <Text style={[styles.ms3, styles.ms3Typo]}>3.7 m/s</Text>
      <Image
        style={[styles.image24Icon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/image-24.png")}
      />
      <Text style={[styles.ms4, styles.ms3Typo]}>5.6 m/s</Text>
      <Image
        style={[styles.image25Icon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/image-24.png")}
      />
      <Text style={[styles.ms5, styles.ms3Typo]}>2.8 m/s</Text>
      <Image
        style={[styles.image12Icon, styles.iconPosition1]}
        contentFit="cover"
        source={require("../assets/image-12.png")}
      />
      <Text style={[styles.ms6, styles.msTypo]}>5.0 m/s</Text>
      <Image
        style={[styles.image13Icon, styles.iconPosition1]}
        contentFit="cover"
        source={require("../assets/image-13.png")}
      />
      <Text style={[styles.ms7, styles.msTypo]}>5.8 m/s</Text>
      <Image
        style={[styles.image14Icon, styles.iconPosition1]}
        contentFit="cover"
        source={require("../assets/image-14.png")}
      />
      <Text style={[styles.ms8, styles.c8Position]}>5.0 m/s</Text>
      <Text style={[styles.c1, styles.c1Position]}>28°C</Text>
      <Text style={[styles.c2, styles.c2Typo]}>28°C</Text>
      <Text style={[styles.text6, styles.c2Typo]}>82%</Text>
      <Text style={[styles.text7, styles.textTypo2]}>80%</Text>
      <Text style={[styles.text8, styles.c4Typo]}>79%</Text>
      <Text style={[styles.c3, styles.textTypo2]}>29°C</Text>
      <Text style={[styles.c4, styles.c4Typo]}>27°C</Text>
      <Text style={[styles.c5, styles.c5Position]}>27°C</Text>
      <Text style={[styles.c6, styles.c6Position]}>27°C</Text>
      <Text style={[styles.c7, styles.c1Typo]}>26°C</Text>
      <Text style={[styles.c8, styles.c1Typo]}>27°C</Text>
      <Text style={[styles.text9, styles.textTypo]}>70%</Text>
      <Text style={[styles.text10, styles.textTypo]}>77%</Text>
      <Text style={[styles.text11, styles.textTypo]}>80%</Text>
      <Text style={[styles.text12, styles.textTypo]}>95%</Text>
      <Text style={[styles.text13, styles.textTypo]}>88%</Text>
      <Text style={[styles.mm, styles.mmTypo]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm1, styles.mmTypo]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm2, styles.mmTypo]}>{`0.1
mm`}</Text>
      <Text style={[styles.mm3, styles.mm3Position]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm4, styles.mmTypo]}>{`0.0
mm`}</Text>
      <Image
        style={[styles.image9Icon, styles.iconLayout3]}
        contentFit="cover"
        source={require("../assets/image-9.png")}
      />
      <Image
        style={[styles.image11Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-11.png")}
      />
      <Image
        style={[styles.image16Icon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/image-9.png")}
      />
      <Image
        style={[styles.image15Icon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/image-15.png")}
      />
      <Image
        style={[styles.image21Icon, styles.mm6Position]}
        contentFit="cover"
        source={require("../assets/image-21.png")}
      />
      <Image
        style={styles.image17Icon}
        contentFit="cover"
        source={require("../assets/image-17.png")}
      />
      <Image
        style={[styles.image26Icon, styles.mm3Position]}
        contentFit="cover"
        source={require("../assets/image-26.png")}
      />
      <Text style={[styles.mm5, styles.textTypo1]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm6, styles.mm6Position]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm7, styles.textTypo1]}>{`0.0
mm`}</Text>
      <Text style={[styles.mm8, styles.textTypo1]}>{`0.0
mm`}</Text>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout5]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
      <Image
        style={styles.image2Icon}
        contentFit="cover"
        source={require("../assets/image-2.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout5: {
    overflow: "hidden",
    width: "100%",
  },
  weatherChildShadowBox: {
    backgroundColor: "transparent",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  weatherPosition: {
    height: 82,
    left: 36,
    top: 217,
  },
  textTypo2: {
    height: 12,
    width: 22,
    color: Color.colorBlack,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  thuTypo: {
    width: 26,
    fontSize: FontSize.size_4xs,
    top: 337,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  upcomingDaysLayout: {
    height: 13,
    color: Color.colorBlack,
    textAlign: "center",
    position: "absolute",
  },
  iconLayout4: {
    height: 20,
    width: 20,
    position: "absolute",
    overflow: "hidden",
  },
  textTypo1: {
    height: 14,
    fontSize: FontSize.size_6xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  iconLayout3: {
    width: 12,
    top: 221,
    height: 12,
  },
  iconLayout2: {
    height: 16,
    width: 16,
    top: 362,
  },
  iconPosition1: {
    top: 237,
    height: 9,
    width: 9,
    position: "absolute",
  },
  msTypo: {
    height: 6,
    fontSize: FontSize.size_9xs,
    top: 245,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  iconLayout1: {
    width: 14,
    top: 393,
    height: 14,
  },
  ms3Typo: {
    width: 24,
    height: 7,
    fontSize: FontSize.size_8xs,
    top: 406,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  iconPosition: {
    left: 246,
    position: "absolute",
  },
  c8Position: {
    left: 244,
    width: 18,
  },
  c1Position: {
    left: 41,
    width: 17,
  },
  c2Typo: {
    left: 89,
    height: 12,
    width: 22,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_5xs,
    textAlign: "center",
    position: "absolute",
  },
  c4Typo: {
    left: 193,
    height: 12,
    width: 22,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_5xs,
    textAlign: "center",
    position: "absolute",
  },
  c5Position: {
    left: 94,
    width: 18,
  },
  c6Position: {
    left: 145,
    width: 18,
  },
  c1Typo: {
    top: 258,
    fontSize: FontSize.size_8xs,
    height: 6,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo: {
    top: 269,
    height: 7,
    fontSize: FontSize.size_8xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  mmTypo: {
    top: 281,
    fontSize: FontSize.size_8xs,
    height: 15,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
  },
  mm3Position: {
    left: 194,
    position: "absolute",
  },
  iconLayout: {
    width: 13,
    top: 221,
    height: 12,
    position: "absolute",
  },
  mm6Position: {
    left: 245,
    position: "absolute",
  },
  weatherChild: {
    width: 237,
    height: 82,
    left: 36,
    top: 217,
    backgroundColor: "transparent",
  },
  weatherItem: {
    backgroundColor: "#f9e4a4",
    width: 29,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    height: 82,
    left: 36,
    top: 217,
    position: "absolute",
  },
  weatherInner: {
    top: 14,
    left: 0,
    backgroundColor: Color.colorGold,
    width: 320,
    height: 39,
    position: "absolute",
  },
  weather1: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    color: Color.colorWhite,
    width: 228,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  image1Icon: {
    top: 72,
    left: 110,
    width: 97,
    height: 96,
    position: "absolute",
  },
  rectangleLineargradient: {
    top: 329,
    left: 35,
    width: 248,
    height: 196,
  },
  text: {
    left: 243,
    width: 22,
    color: Color.colorBlack,
    fontSize: FontSize.size_5xs,
    top: 465,
  },
  c: {
    top: 430,
    left: 243,
    width: 22,
    color: Color.colorBlack,
    fontSize: FontSize.size_5xs,
  },
  thu: {
    left: 240,
  },
  upcomingDays: {
    top: 315,
    left: 34,
    fontSize: FontSize.size_3xs,
    width: 81,
    fontFamily: FontFamily.istokWebRegular,
    height: 13,
  },
  mon: {
    left: 87,
    width: 26,
    fontSize: FontSize.size_4xs,
    top: 337,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  tue: {
    left: 138,
  },
  wed: {
    left: 189,
  },
  mac2024Sunday: {
    top: 176,
    fontSize: FontSize.size_smi,
    width: 146,
    left: 85,
    height: 13,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  phwindFillIcon: {
    height: 22,
    width: 20,
    top: 392,
    left: 46,
    position: "absolute",
    overflow: "hidden",
  },
  carbontemperatureHotIcon: {
    top: 426,
    left: 47,
    height: 20,
  },
  mdihumidityOutlineIcon: {
    top: 460,
    height: 20,
    left: 46,
  },
  image3Icon: {
    height: 18,
    width: 18,
    top: 494,
    left: 47,
    position: "absolute",
  },
  text1: {
    left: 31,
    width: 37,
    top: 206,
    height: 14,
    fontSize: FontSize.size_6xs,
    position: "absolute",
  },
  text2: {
    left: 234,
    width: 37,
    top: 206,
    height: 14,
    fontSize: FontSize.size_6xs,
    position: "absolute",
  },
  text3: {
    left: 183,
    width: 37,
    top: 206,
    height: 14,
    fontSize: FontSize.size_6xs,
    position: "absolute",
  },
  text4: {
    left: 135,
    width: 37,
    top: 206,
    height: 14,
    fontSize: FontSize.size_6xs,
    position: "absolute",
  },
  text5: {
    width: 37,
    top: 206,
    height: 14,
    fontSize: FontSize.size_6xs,
    position: "absolute",
    left: 85,
  },
  image4Icon: {
    left: 44,
    position: "absolute",
  },
  image18Icon: {
    left: 92,
    position: "absolute",
  },
  image19Icon: {
    left: 143,
    position: "absolute",
  },
  image5Icon: {
    top: 238,
    height: 9,
    width: 9,
    left: 45,
    position: "absolute",
  },
  image10Icon: {
    left: 99,
  },
  ms: {
    left: 42,
    width: 18,
  },
  ms1: {
    left: 95,
    width: 18,
  },
  image22Icon: {
    left: 91,
    width: 15,
    height: 15,
    top: 392,
    position: "absolute",
  },
  ms2: {
    height: 7,
    fontSize: FontSize.size_8xs,
    top: 406,
    left: 87,
    width: 26,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  image23Icon: {
    left: 144,
    position: "absolute",
  },
  ms3: {
    left: 140,
  },
  image24Icon: {
    left: 196,
    position: "absolute",
  },
  ms4: {
    left: 192,
  },
  image25Icon: {
    width: 14,
    top: 393,
    height: 14,
  },
  ms5: {
    left: 242,
  },
  image12Icon: {
    left: 149,
  },
  ms6: {
    left: 146,
    width: 18,
  },
  image13Icon: {
    left: 198,
  },
  ms7: {
    left: 195,
    width: 18,
  },
  image14Icon: {
    left: 248,
  },
  ms8: {
    height: 6,
    fontSize: FontSize.size_9xs,
    top: 245,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  c1: {
    width: 17,
    top: 258,
    fontSize: FontSize.size_8xs,
    height: 6,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  c2: {
    top: 430,
  },
  text6: {
    top: 465,
  },
  text7: {
    left: 140,
    top: 465,
  },
  text8: {
    top: 465,
  },
  c3: {
    left: 140,
    top: 430,
  },
  c4: {
    top: 430,
  },
  c5: {
    top: 258,
    fontSize: FontSize.size_8xs,
    height: 6,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  c6: {
    top: 258,
    fontSize: FontSize.size_8xs,
    height: 6,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  c7: {
    left: 195,
    width: 18,
  },
  c8: {
    left: 244,
    width: 18,
  },
  text9: {
    width: 17,
    left: 41,
  },
  text10: {
    left: 94,
    width: 18,
  },
  text11: {
    left: 145,
    width: 18,
  },
  text12: {
    left: 195,
    width: 18,
  },
  text13: {
    left: 244,
    width: 18,
  },
  mm: {
    width: 17,
    left: 41,
    position: "absolute",
  },
  mm1: {
    left: 93,
    width: 18,
    position: "absolute",
  },
  mm2: {
    left: 144,
    position: "absolute",
    width: 18,
  },
  mm3: {
    top: 281,
    fontSize: FontSize.size_8xs,
    height: 15,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    width: 18,
  },
  mm4: {
    left: 244,
    width: 18,
    position: "absolute",
  },
  image9Icon: {
    left: 98,
    position: "absolute",
  },
  image11Icon: {
    left: 147,
  },
  image16Icon: {
    width: 12,
    top: 221,
    height: 12,
  },
  image15Icon: {
    left: 197,
  },
  image21Icon: {
    height: 16,
    width: 16,
    top: 362,
  },
  image17Icon: {
    top: 255,
    left: 275,
    width: 11,
    height: 10,
    position: "absolute",
  },
  image26Icon: {
    height: 16,
    width: 16,
    top: 362,
  },
  mm5: {
    left: 90,
    width: 17,
    height: 14,
    fontSize: FontSize.size_6xs,
    top: 494,
    position: "absolute",
  },
  mm6: {
    width: 17,
    height: 14,
    fontSize: FontSize.size_6xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    top: 494,
  },
  mm7: {
    width: 17,
    left: 195,
    height: 14,
    fontSize: FontSize.size_6xs,
    top: 494,
    position: "absolute",
  },
  mm8: {
    left: 141,
    width: 17,
    height: 14,
    fontSize: FontSize.size_6xs,
    top: 494,
    position: "absolute",
  },
  icon: {
    height: "100%",
  },
  tablerhomeFilled: {
    left: 6,
    top: 20,
    width: 25,
    height: 25,
    position: "absolute",
  },
  image2Icon: {
    top: 359,
    left: 45,
    height: 20,
    width: 20,
    position: "absolute",
  },
  weather: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
  },
});

export default Weather;
