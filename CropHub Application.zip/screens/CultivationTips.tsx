import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CultivationTips = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.cultivationTips}>
      <View
        style={[styles.cultivationTipsChild, styles.chooseTheCropPosition]}
      />
      <Text style={styles.cultivationTips1}>CULTIVATION TIPS</Text>
      <View style={[styles.cultivationTipsItem, styles.cultivationShadowBox]} />
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <Text style={[styles.plantSelection, styles.plantTypo]}>
        Plant Selection
      </Text>
      <View style={[styles.button, styles.buttonLayout]}>
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={[styles.chooseTheCrop, styles.plantTypo]}>
          Choose the crop:
        </Text>
      </View>
      <Image
        style={styles.arrowRightIcon}
        contentFit="cover"
        source={require("../assets/arrow-right.png")}
      />
      <Pressable
        style={[styles.arrowDownSignToNavigate, styles.arrowLayout]}
        onPress={() => navigation.navigate("PlantSelection")}
      >
        <Image
          style={styles.iconLayout1}
          contentFit="cover"
          source={require("../assets/arrow-down-sign-to-navigate1.png")}
        />
      </Pressable>
      <Image
        style={[styles.smartFarmIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/smart-farm.png")}
      />
      <View
        style={[styles.cultivationTipsInner, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.planting, styles.chemicalTypo]}>Planting</Text>
      <Image
        style={[styles.arrowDownSignToNavigate1, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View style={[styles.rectangleView, styles.cultivationShadowBox]} />
      <Text style={[styles.plantTraining, styles.plantTypo]}>
        Plant Training
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate2, styles.arrowLayout]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild1, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.monitoring, styles.chemicalTypo]}>Monitoring</Text>
      <Image
        style={[styles.arrowDownSignToNavigate3, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild2, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.siteSelection, styles.chemicalTypo]}>
        Site Selection
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate4, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild3, styles.cultivationShadowBox]}
      />
      <Text style={[styles.fieldPreparation, styles.plantTypo]}>
        Field Preparation
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate5, styles.arrowLayout]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild4, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.weeding, styles.chemicalTypo]}>Weeding</Text>
      <Image
        style={[styles.arrowDownSignToNavigate6, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild5, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.fertilizationOrganic, styles.preventiveMeasureTypo]}>
        Fertilization Organic
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate7, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild6, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.fertilizationChemical, styles.chemicalTypo]}>
        Fertilization Chemical
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate8, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild7, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.preventiveMeasure, styles.preventiveMeasureTypo]}>
        Preventive Measure
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate9, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild8, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.plantProtectionChemical, styles.chemicalTypo]}>
        Plant Protection Chemical
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate10, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[styles.cultivationTipsChild9, styles.cultivationChildShadowBox]}
      />
      <Text style={[styles.plantProtectionOrganic, styles.harvestingTypo]}>
        Plant Protection Organic
      </Text>
      <Image
        style={[styles.arrowDownSignToNavigate11, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <View
        style={[
          styles.cultivationTipsChild10,
          styles.cultivationChildShadowBox,
        ]}
      />
      <View
        style={[
          styles.cultivationTipsChild11,
          styles.cultivationChildShadowBox,
        ]}
      />
      <Image
        style={[styles.arrowDownSignToNavigate12, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <Text style={[styles.postHarvest, styles.harvestingTypo]}>
        Post Harvest
      </Text>
      <Text style={[styles.harvesting, styles.harvestingTypo]}>Harvesting</Text>
      <Image
        style={[styles.arrowDownSignToNavigate13, styles.arrowPosition]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <Image
        style={[styles.plantingIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/planting.png")}
      />
      <Image
        style={[styles.climateIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/climate.png")}
      />
      <Image
        style={[styles.bambooIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/bamboo.png")}
      />
      <Image
        style={[styles.fieldIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/field2.png")}
      />
      <Image
        style={[styles.preparationIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/preparation.png")}
      />
      <Image
        style={[styles.grassIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/grass.png")}
      />
      <Image
        style={[styles.fertilizerIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/fertilizer.png")}
      />
      <Image
        style={[styles.pesticideIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/pesticide1.png")}
      />
      <Image
        style={[styles.speedometerIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/speedometer.png")}
      />
      <Image
        style={[styles.environmentalProtectionIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/environmental-protection.png")}
      />
      <Image
        style={[styles.pepperSprayIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/pepper-spray.png")}
      />
      <Image
        style={[styles.harvestIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/harvest.png")}
      />
      <Image
        style={[styles.harvestIcon1, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/harvest1.png")}
      />
      <Text style={[styles.capsicum, styles.capsicumPosition]}>Capsicum</Text>
      <Image
        style={[styles.capsicumIcon, styles.capsicumPosition]}
        contentFit="cover"
        source={require("../assets/capsicum.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  chooseTheCropPosition: {
    left: 0,
    position: "absolute",
  },
  cultivationShadowBox: {
    height: 31,
    width: 304,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    left: 7,
    position: "absolute",
  },
  iconLayout1: {
    height: "100%",
    width: "100%",
  },
  plantTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  buttonLayout: {
    height: 22,
    position: "absolute",
  },
  arrowLayout: {
    height: 18,
    left: 289,
    width: 17,
    position: "absolute",
  },
  iconLayout: {
    height: 20,
    width: 20,
    position: "absolute",
  },
  cultivationChildShadowBox: {
    left: 8,
    height: 31,
    width: 304,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  chemicalTypo: {
    left: 36,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  arrowPosition: {
    left: 290,
    height: 18,
    width: 17,
    position: "absolute",
  },
  preventiveMeasureTypo: {
    width: 128,
    left: 36,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  harvestingTypo: {
    width: 163,
    left: 36,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  capsicumPosition: {
    top: 73,
    position: "absolute",
  },
  cultivationTipsChild: {
    top: 14,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
  },
  cultivationTips1: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cultivationTipsItem: {
    top: 114,
  },
  icon: {
    overflow: "hidden",
  },
  makiarrow: {
    top: 23,
    width: 24,
    height: 21,
    left: 12,
    position: "absolute",
  },
  plantSelection: {
    top: 122,
    width: 97,
    left: 35,
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  buttonChild: {
    top: 0,
    left: 100,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest4,
    width: 104,
  },
  chooseTheCrop: {
    top: 3,
    display: "flex",
    alignItems: "center",
    width: 116,
    height: 15,
    left: 0,
    position: "absolute",
  },
  button: {
    top: 70,
    left: 21,
    width: 204,
  },
  arrowRightIcon: {
    top: 72,
    left: 202,
    height: 17,
    width: 17,
    position: "absolute",
  },
  arrowDownSignToNavigate: {
    top: 121,
  },
  smartFarmIcon: {
    top: 120,
    left: 11,
    width: 20,
  },
  cultivationTipsInner: {
    top: 153,
  },
  planting: {
    top: 161,
    width: 97,
  },
  arrowDownSignToNavigate1: {
    top: 160,
  },
  rectangleView: {
    top: 192,
  },
  plantTraining: {
    top: 200,
    width: 97,
    left: 35,
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  arrowDownSignToNavigate2: {
    top: 199,
  },
  cultivationTipsChild1: {
    top: 231,
  },
  monitoring: {
    top: 239,
    width: 97,
  },
  arrowDownSignToNavigate3: {
    top: 238,
  },
  cultivationTipsChild2: {
    top: 270,
  },
  siteSelection: {
    top: 278,
    width: 97,
  },
  arrowDownSignToNavigate4: {
    top: 277,
  },
  cultivationTipsChild3: {
    top: 309,
  },
  fieldPreparation: {
    top: 317,
    width: 124,
    height: 14,
    left: 35,
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  arrowDownSignToNavigate5: {
    top: 316,
  },
  cultivationTipsChild4: {
    top: 348,
  },
  weeding: {
    top: 356,
    width: 97,
  },
  arrowDownSignToNavigate6: {
    top: 355,
  },
  cultivationTipsChild5: {
    top: 387,
  },
  fertilizationOrganic: {
    top: 395,
    height: 23,
  },
  arrowDownSignToNavigate7: {
    top: 394,
  },
  cultivationTipsChild6: {
    top: 426,
  },
  fertilizationChemical: {
    top: 434,
    width: 142,
  },
  arrowDownSignToNavigate8: {
    top: 433,
  },
  cultivationTipsChild7: {
    top: 465,
  },
  preventiveMeasure: {
    top: 473,
    height: 17,
  },
  arrowDownSignToNavigate9: {
    top: 472,
  },
  cultivationTipsChild8: {
    top: 504,
  },
  plantProtectionChemical: {
    top: 512,
    width: 171,
  },
  arrowDownSignToNavigate10: {
    top: 511,
  },
  cultivationTipsChild9: {
    top: 543,
  },
  plantProtectionOrganic: {
    top: 551,
  },
  arrowDownSignToNavigate11: {
    top: 550,
  },
  cultivationTipsChild10: {
    top: 621,
  },
  cultivationTipsChild11: {
    top: 582,
  },
  arrowDownSignToNavigate12: {
    top: 628,
  },
  postHarvest: {
    top: 629,
  },
  harvesting: {
    top: 590,
  },
  arrowDownSignToNavigate13: {
    top: 589,
  },
  plantingIcon: {
    top: 159,
    left: 11,
    width: 20,
  },
  climateIcon: {
    top: 237,
    left: 12,
  },
  bambooIcon: {
    top: 198,
    left: 12,
  },
  fieldIcon: {
    top: 276,
    left: 12,
  },
  preparationIcon: {
    top: 315,
    left: 12,
  },
  grassIcon: {
    top: 354,
    left: 12,
  },
  fertilizerIcon: {
    top: 393,
    left: 12,
  },
  pesticideIcon: {
    top: 432,
    left: 12,
  },
  speedometerIcon: {
    top: 471,
    left: 12,
  },
  environmentalProtectionIcon: {
    top: 549,
    left: 12,
  },
  pepperSprayIcon: {
    top: 510,
    left: 12,
  },
  harvestIcon: {
    top: 588,
    left: 12,
  },
  harvestIcon1: {
    top: 627,
    left: 12,
  },
  capsicum: {
    left: 139,
    width: 97,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  capsicumIcon: {
    left: 124,
    width: 15,
    height: 15,
  },
  cultivationTips: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default CultivationTips;
