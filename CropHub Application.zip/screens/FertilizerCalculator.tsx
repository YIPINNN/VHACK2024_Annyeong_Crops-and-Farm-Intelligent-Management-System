import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const FertilizerCalculator = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.fertilizerCalculator, styles.iconLayout]}>
      <Image
        style={styles.simpleLineIconsplus}
        contentFit="cover"
        source={require("../assets/simplelineiconsplus.png")}
      />
      <Image
        style={[styles.carboncircleFilledIcon, styles.carboncircleIconLayout]}
        contentFit="cover"
        source={require("../assets/carboncirclefilled.png")}
      />
      <View style={styles.fertilizerCalculatorChild} />
      <Text style={styles.fertilizerCalculator1}>Fertilizer Calculator</Text>
      <View
        style={[styles.fertilizerCalculatorItem, styles.fertilizerShadowBox]}
      />
      <View style={styles.fertilizerCalculatorInner} />
      <Text style={styles.nutrientQuantities}>Nutrient Quantities</Text>
      <Text style={[styles.unit, styles.unitTypo]}>Unit</Text>
      <Text style={[styles.areaSize, styles.unitTypo]}>Area Size</Text>
      <Text style={[styles.n, styles.nTypo]}>N:</Text>
      <Text style={styles.number}>Number</Text>
      <Text style={[styles.acre, styles.acreFlexBox]}>Acre</Text>
      <Text style={[styles.hectare, styles.acreFlexBox]}>Hectare</Text>
      <Text style={[styles.edit, styles.acreFlexBox]}>Edit</Text>
      <View style={[styles.rectangleView, styles.fertilizerShadowBox]} />
      <Text style={[styles.p, styles.nTypo]}>P:</Text>
      <View
        style={[styles.fertilizerCalculatorChild1, styles.fertilizerShadowBox]}
      />
      <Text style={[styles.k, styles.nTypo]}>K:</Text>
      <View style={[styles.button, styles.buttonLayout1]}>
        <View style={[styles.buttonChild, styles.buttonBg]} />
        <Text style={styles.chooseTheCrop}>Choose the crop:</Text>
      </View>
      <View style={[styles.field, styles.fieldPosition]} />
      <Image
        style={[styles.npkIcon, styles.fieldPosition]}
        contentFit="cover"
        source={require("../assets/npk1.png")}
      />
      <Image
        style={styles.arrowRightIcon}
        contentFit="cover"
        source={require("../assets/arrow-right.png")}
      />
      <Image
        style={[styles.carboncircleFilledIcon1, styles.carboncircleIconLayout]}
        contentFit="cover"
        source={require("../assets/carboncirclefilled1.png")}
      />
      <Image
        style={styles.icons8minus}
        contentFit="cover"
        source={require("../assets/icons8minus.png")}
      />
      <Pressable
        style={[styles.button1, styles.buttonLayout]}
        onPress={() => navigation.navigate("FertilizerCalculator1")}
      >
        <View style={[styles.buttonItem, styles.buttonLayout]} />
        <Pressable
          style={styles.calculate}
          onPress={() => navigation.navigate("FertilizerCalculator1")}
        >
          <Text style={styles.calculate1}>Calculate</Text>
        </Pressable>
      </Pressable>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  carboncircleIconLayout: {
    height: 15,
    width: 15,
    top: 344,
    position: "absolute",
    overflow: "hidden",
  },
  fertilizerShadowBox: {
    height: 23,
    width: 46,
    top: 284,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkseagreen_100,
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  unitTypo: {
    width: 71,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
    height: 15,
    left: 29,
    position: "absolute",
  },
  nTypo: {
    height: 14,
    width: 19,
    fontSize: FontSize.size_3xs,
    top: 289,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  acreFlexBox: {
    width: 43,
    height: 14,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  buttonLayout1: {
    height: 22,
    position: "absolute",
  },
  buttonBg: {
    backgroundColor: Color.forest4,
    borderRadius: Border.br_xs,
    top: 0,
  },
  fieldPosition: {
    top: 66,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 180,
    position: "absolute",
  },
  simpleLineIconsplus: {
    top: 406,
    left: 237,
    width: 40,
    height: 40,
    position: "absolute",
    overflow: "hidden",
  },
  carboncircleFilledIcon: {
    left: 29,
  },
  fertilizerCalculatorChild: {
    top: 14,
    backgroundColor: Color.olive4,
    width: 320,
    height: 39,
    left: 0,
    position: "absolute",
  },
  fertilizerCalculator1: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    width: 228,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  fertilizerCalculatorItem: {
    left: 29,
  },
  fertilizerCalculatorInner: {
    top: 401,
    left: 101,
    width: 119,
    height: 49,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorDarkseagreen_100,
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  nutrientQuantities: {
    top: 263,
    width: 143,
    height: 12,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    left: 29,
    position: "absolute",
  },
  unit: {
    top: 327,
  },
  areaSize: {
    top: 379,
  },
  n: {
    left: 33,
  },
  number: {
    top: 417,
    left: 122,
    fontSize: FontSize.size_mini,
    color: "rgba(255, 255, 255, 0.72)",
    width: 76,
    height: 18,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  acre: {
    left: 39,
    top: 345,
    width: 43,
    fontSize: FontSize.size_3xs,
  },
  hectare: {
    left: 107,
    top: 345,
    width: 43,
    fontSize: FontSize.size_3xs,
  },
  edit: {
    top: 297,
    left: 265,
    fontSize: FontSize.size_5xs,
    textDecoration: "underline",
  },
  rectangleView: {
    left: 100,
  },
  p: {
    left: 104,
  },
  fertilizerCalculatorChild1: {
    left: 171,
  },
  k: {
    left: 175,
  },
  buttonChild: {
    width: 104,
    height: 22,
    position: "absolute",
    left: 100,
  },
  chooseTheCrop: {
    top: 3,
    width: 116,
    alignItems: "center",
    display: "flex",
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.sanchezRegular,
    left: 0,
    height: 15,
    position: "absolute",
  },
  button: {
    top: 221,
    width: 204,
    left: 29,
  },
  field: {
    width: 112,
    height: 111,
    left: 104,
  },
  npkIcon: {
    left: 98,
    width: 125,
    height: 125,
  },
  arrowRightIcon: {
    top: 223,
    left: 210,
    width: 17,
    height: 17,
    position: "absolute",
  },
  carboncircleFilledIcon1: {
    left: 93,
  },
  icons8minus: {
    top: 403,
    left: 36,
    width: 50,
    height: 50,
    position: "absolute",
    overflow: "hidden",
  },
  buttonItem: {
    backgroundColor: Color.forest4,
    borderRadius: Border.br_xs,
    top: 0,
    left: 0,
  },
  calculate1: {
    fontSize: FontSize.size_smi,
    width: 97,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
  },
  calculate: {
    left: 42,
    top: 5,
    position: "absolute",
  },
  button1: {
    top: 465,
    left: 70,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  fertilizerCalculator: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
  },
});

export default FertilizerCalculator;
