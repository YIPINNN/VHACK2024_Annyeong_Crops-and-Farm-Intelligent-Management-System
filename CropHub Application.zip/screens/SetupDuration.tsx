import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, Color, FontFamily } from "../GlobalStyles";

const SetupDuration = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.setupDuration, styles.iconLayout]}>
      <View style={styles.setupDurationChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupDurationItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupDurationInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupDurationChild1, styles.image42IconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild2, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <Image
        style={[styles.image42Icon, styles.image42IconPosition]}
        contentFit="cover"
        source={require("../assets/image-42.png")}
      />
      <Pressable
        style={styles.greatYouveCompletedContainer}
        onPress={() => navigation.navigate("Irrigation")}
      >
        <Text style={styles.greatYouveCompletedAllSe}>
          Great! You’ve completed all setup.
        </Text>
      </Pressable>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: "100%",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 272,
  },
  textTypo1: {
    width: 16,
    fontSize: FontSize.size_2xs,
    top: 279,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 273,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 280,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  image42IconPosition: {
    left: 109,
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 287,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    color: Color.colorGray_200,
    fontSize: FontSize.size_4xs,
    top: 307,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupDurationChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontWeight: "700",
    fontFamily: FontFamily.istokWebBold,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupDurationItem: {
    left: 34,
    position: "absolute",
  },
  text: {
    left: 40,
  },
  setupDurationInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild1: {
    height: 28,
    width: 28,
    top: 272,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild2: {
    left: 137,
  },
  setupDurationChild3: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    height: 12,
    color: Color.colorGray_200,
    fontSize: FontSize.size_4xs,
    top: 307,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    color: Color.colorGray_200,
    fontSize: FontSize.size_4xs,
    top: 307,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    color: Color.colorGray_200,
    fontSize: FontSize.size_4xs,
    top: 307,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    color: Color.colorGray_200,
    fontSize: FontSize.size_4xs,
    top: 307,
  },
  image42Icon: {
    top: 142,
    width: 100,
    height: 100,
  },
  greatYouveCompletedAllSe: {
    textDecoration: "underline",
    width: 195,
    height: 13,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    fontSize: FontSize.size_xs,
  },
  greatYouveCompletedContainer: {
    top: 364,
    left: 62,
    position: "absolute",
  },
  icon: {
    height: "100%",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
  },
});

export default SetupDuration;
