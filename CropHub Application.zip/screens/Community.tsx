import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Community = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.community, styles.iconLayout]}>
      <View style={styles.communityChild} />
      <Text style={[styles.community1, styles.community1Layout]}>
        COMMUNITY
      </Text>
      <View style={styles.communityItem} />
      <Text style={styles.searchInCommunity}>Search in Community</Text>
      <View style={[styles.communityInner, styles.communityShadowBox]} />
      <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      <View style={[styles.communityChild1, styles.communityChildLayout]} />
      <Image
        style={[styles.pictureIcon, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture3.png")}
      />
      <Text style={[styles.yongPeiYi, styles.yongPeiYiTypo]}>Yong Pei Yi</Text>
      <Text style={[styles.posted3daysAgo, styles.detailsTypo]}>
        Posted 3days ago
      </Text>
      <Text style={[styles.details, styles.detailsTypo]}>Details</Text>
      <Text style={[styles.writeAComment, styles.writeTypo]}>
        Write a comment
      </Text>
      <Pressable
        style={[styles.makiarrow, styles.makiarrowLayout]}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <Image
        style={[styles.icoutlineSearchIcon, styles.makiarrowLayout]}
        contentFit="cover"
        source={require("../assets/icoutlinesearch.png")}
      />
      <Image
        style={[styles.iconamoonnotificationFill, styles.makiarrowLayout]}
        contentFit="cover"
        source={require("../assets/iconamoonnotificationfill.png")}
      />
      <Image
        style={[styles.ggmoreOIcon, styles.community1Layout]}
        contentFit="cover"
        source={require("../assets/ggmoreo.png")}
      />
      <Image
        style={[styles.mingcuteuser4FillIcon, styles.mingcuteuser4IconLayout1]}
        contentFit="cover"
        source={require("../assets/mingcuteuser4fill.png")}
      />
      <Image
        style={[styles.mingcuteuser4FillIcon1, styles.mingcuteuser4IconLayout]}
        contentFit="cover"
        source={require("../assets/mingcuteuser4fill1.png")}
      />
      <Image
        style={[styles.iconamoonlikeFill, styles.fillLayout]}
        contentFit="cover"
        source={require("../assets/iconamoonlikefill.png")}
      />
      <Image
        style={[styles.iconamoondislikeFill, styles.fillLayout]}
        contentFit="cover"
        source={require("../assets/iconamoondislikefill.png")}
      />
      <Image
        style={[styles.materialSymbolsshareIcon, styles.fillLayout]}
        contentFit="cover"
        source={require("../assets/materialsymbolsshare.png")}
      />
      <View style={[styles.communityChild2, styles.communityShadowBox]} />
      <View style={[styles.communityChild3, styles.rectangleViewShadowBox]} />
      <View style={[styles.communityChild4, styles.communityChildLayout]} />
      <Image
        style={[styles.pictureIcon1, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture3.png")}
      />
      <Text style={[styles.tanYinXuan, styles.yongPeiYiTypo]}>
        Tan Yin Xuan
      </Text>
      <Text style={[styles.posted3daysAgo1, styles.detailsTypo]}>
        Posted 3days ago
      </Text>
      <Text style={[styles.details1, styles.detailsTypo]}>Details</Text>
      <Text style={[styles.writeAComment1, styles.writeTypo]}>
        Write a comment
      </Text>
      <Image
        style={[styles.mingcuteuser4FillIcon2, styles.mingcuteuser4IconLayout1]}
        contentFit="cover"
        source={require("../assets/mingcuteuser4fill.png")}
      />
      <Image
        style={[styles.mingcuteuser4FillIcon3, styles.mingcuteuser4IconLayout]}
        contentFit="cover"
        source={require("../assets/mingcuteuser4fill1.png")}
      />
      <Image
        style={[styles.iconamoonlikeFill1, styles.fillPosition]}
        contentFit="cover"
        source={require("../assets/iconamoonlikefill.png")}
      />
      <Image
        style={[styles.iconamoondislikeFill1, styles.fillPosition]}
        contentFit="cover"
        source={require("../assets/iconamoondislikefill.png")}
      />
      <Image
        style={[styles.materialSymbolsshareIcon1, styles.fillPosition]}
        contentFit="cover"
        source={require("../assets/materialsymbolsshare.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  community1Layout: {
    height: 19,
    position: "absolute",
  },
  communityShadowBox: {
    height: 180,
    width: 285,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    left: 21,
    position: "absolute",
  },
  rectangleViewShadowBox: {
    width: 285,
    height: 21,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    left: 21,
    position: "absolute",
  },
  communityChildLayout: {
    height: 14,
    width: 188,
    backgroundColor: Color.colorWhitesmoke,
    left: 51,
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  pictureIconLayout: {
    height: 103,
    width: 145,
    borderRadius: Border.br_xl,
    left: 31,
    position: "absolute",
  },
  yongPeiYiTypo: {
    width: 97,
    fontSize: FontSize.size_xs,
    left: 56,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  detailsTypo: {
    height: 7,
    width: 53,
    fontSize: FontSize.size_7xs,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  writeTypo: {
    left: 55,
    height: 7,
    width: 53,
    fontSize: FontSize.size_7xs,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  makiarrowLayout: {
    width: 24,
    position: "absolute",
  },
  mingcuteuser4IconLayout1: {
    height: 26,
    width: 26,
    left: 29,
    position: "absolute",
    overflow: "hidden",
  },
  mingcuteuser4IconLayout: {
    height: 20,
    width: 20,
    left: 29,
    position: "absolute",
    overflow: "hidden",
  },
  fillLayout: {
    height: 12,
    width: 12,
    top: 284,
    position: "absolute",
    overflow: "hidden",
  },
  fillPosition: {
    top: 507,
    height: 12,
    width: 12,
    position: "absolute",
    overflow: "hidden",
  },
  communityChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  community1: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    fontFamily: FontFamily.sanchezRegular,
    fontSize: FontSize.size_sm,
    height: 19,
  },
  communityItem: {
    top: 66,
    width: 229,
    height: 29,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_8xs,
    left: 21,
    position: "absolute",
  },
  searchInCommunity: {
    top: 74,
    width: 232,
    height: 24,
    textAlign: "left",
    color: Color.colorBlack,
    left: 57,
    fontFamily: FontFamily.sanchezRegular,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  communityInner: {
    top: 118,
  },
  rectangleView: {
    top: 304,
    height: 21,
  },
  communityChild1: {
    top: 309,
  },
  pictureIcon: {
    top: 150,
  },
  yongPeiYi: {
    top: 124,
  },
  posted3daysAgo: {
    top: 139,
    width: 53,
    fontSize: FontSize.size_7xs,
    left: 57,
  },
  details: {
    top: 259,
    left: 31,
    width: 53,
    fontSize: FontSize.size_7xs,
  },
  writeAComment: {
    top: 312,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  makiarrow: {
    left: 12,
    top: 23,
    height: 21,
  },
  icoutlineSearchIcon: {
    top: 68,
    left: 24,
    height: 24,
    overflow: "hidden",
  },
  iconamoonnotificationFill: {
    top: 71,
    left: 256,
    height: 24,
    overflow: "hidden",
  },
  ggmoreOIcon: {
    top: 73,
    left: 287,
    width: 19,
    overflow: "hidden",
  },
  mingcuteuser4FillIcon: {
    top: 122,
  },
  mingcuteuser4FillIcon1: {
    top: 305,
  },
  iconamoonlikeFill: {
    left: 258,
  },
  iconamoondislikeFill: {
    left: 274,
  },
  materialSymbolsshareIcon: {
    left: 289,
  },
  communityChild2: {
    top: 341,
  },
  communityChild3: {
    top: 527,
    height: 21,
  },
  communityChild4: {
    top: 532,
  },
  pictureIcon1: {
    top: 373,
  },
  tanYinXuan: {
    top: 347,
  },
  posted3daysAgo1: {
    top: 362,
    width: 53,
    fontSize: FontSize.size_7xs,
    left: 57,
  },
  details1: {
    top: 482,
    left: 31,
    width: 53,
    fontSize: FontSize.size_7xs,
  },
  writeAComment1: {
    top: 535,
  },
  mingcuteuser4FillIcon2: {
    top: 345,
  },
  mingcuteuser4FillIcon3: {
    top: 528,
  },
  iconamoonlikeFill1: {
    left: 258,
  },
  iconamoondislikeFill1: {
    left: 274,
  },
  materialSymbolsshareIcon1: {
    left: 289,
  },
  community: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
  },
});

export default Community;
