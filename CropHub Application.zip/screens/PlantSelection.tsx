import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const PlantSelection = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.plantSelection}>
      <View style={styles.plantSelectionChild} />
      <Text style={[styles.plantSelection1, styles.pictureIconLayout]}>
        plant selection
      </Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CultivationTips")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <Text style={[styles.weeksBeforeSeedling, styles.pestAndDiseaseLayout]}>
        3 weeks before seedling
      </Text>
      <Image
        style={[styles.pictureIcon, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture4.png")}
      />
      <Text
        style={[styles.pestAndDisease, styles.pestAndDiseaseLayout]}
      >{`Pest and disease resistant varieties
Pusa Jwala: resistant to thrips, mites.

Phule Jyoti: resistant to thrips, mites, Fusarium wilt.

Arka Harita: resistant to powdery mildew, viral diseases and leaf curl complex.

Hisar Shakti: resistant to fruit rot, powdery mildew, viral diseases and leaf curl complex.`}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  pictureIconLayout: {
    width: 228,
    position: "absolute",
  },
  pestAndDiseaseLayout: {
    width: 238,
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  plantSelectionChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  plantSelection1: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    width: 228,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  weeksBeforeSeedling: {
    top: 64,
    left: 36,
    fontSize: FontSize.size_lg,
    textAlign: "left",
    height: 28,
  },
  pictureIcon: {
    top: 97,
    left: 46,
    borderRadius: Border.br_xl,
    height: 143,
  },
  pestAndDisease: {
    top: 246,
    left: 41,
    fontSize: FontSize.size_xs,
    textAlign: "justify",
    height: 170,
  },
  plantSelection: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default PlantSelection;
