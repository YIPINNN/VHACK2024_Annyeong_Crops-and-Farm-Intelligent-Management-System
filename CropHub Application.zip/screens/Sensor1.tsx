import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Sensor1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.sensor2}>
      <View style={styles.sensor2Child} />
      <Text style={[styles.irrigationSystem, styles.addSensorTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={styles.image29Icon}
        contentFit="cover"
        source={require("../assets/image-291.png")}
      />
      <View style={[styles.sensor2Item, styles.sensor2Layout]} />
      <Text
        style={[styles.irrigationSensorNicknameContainer, styles.containerTypo]}
      >
        <Text
          style={styles.irrigationSensorNickname}
        >{`Irrigation sensor nickname `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Text style={[styles.sensor01, styles.sensor01Typo]}>Sensor_01</Text>
      <Text
        style={[styles.enterConfirmedPasswordContainer, styles.containerTypo]}
      >
        <Text
          style={styles.irrigationSensorNickname}
        >{`Enter confirmed password `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Text style={[styles.enterPasswordContainer, styles.sensor01Typo]}>
        <Text style={styles.irrigationSensorNickname}>{`Enter password `}</Text>
        <Text style={styles.text}>*</Text>
      </Text>
      <Pressable
        style={[styles.sensor2Inner, styles.sensor2Layout]}
        onPress={() => navigation.navigate("Setup")}
      />
      <Text style={styles.sensorDetected}>Sensor detected.</Text>
      <Text style={[styles.text3, styles.textTypo3]}>___</Text>
      <Text style={[styles.text4, styles.textTypo3]}>___</Text>
      <Text style={[styles.text5, styles.textTypo3]}>___</Text>
      <Text style={[styles.text6, styles.textTypo3]}>___</Text>
      <Text style={[styles.text7, styles.textTypo3]}>___</Text>
      <Text style={[styles.addSensor, styles.addSensorTypo]}>Add sensor</Text>
      <Text style={[styles.text8, styles.textTypo2]}>*</Text>
      <Text style={[styles.text9, styles.textTypo2]}>*</Text>
      <Text style={[styles.text10, styles.textTypo2]}>*</Text>
      <Text style={[styles.text11, styles.textTypo2]}>*</Text>
      <Text style={[styles.text12, styles.textTypo2]}>*</Text>
      <Text style={[styles.text13, styles.textTypo1]}>___</Text>
      <Text style={[styles.text14, styles.textTypo1]}>___</Text>
      <Text style={[styles.text15, styles.textTypo1]}>___</Text>
      <Text style={[styles.text16, styles.textTypo1]}>___</Text>
      <Text style={[styles.text17, styles.textTypo1]}>___</Text>
      <Text style={[styles.text18, styles.textTypo]}>*</Text>
      <Text style={[styles.text19, styles.textTypo]}>*</Text>
      <Text style={[styles.text20, styles.textTypo]}>*</Text>
      <Text style={[styles.text21, styles.textTypo]}>*</Text>
      <Text style={[styles.text22, styles.textTypo]}>*</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  addSensorTypo: {
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  sensor2Layout: {
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  containerTypo: {
    height: 16,
    width: 119,
    left: 28,
    fontSize: FontSize.size_4xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  sensor01Typo: {
    textAlign: "left",
    height: 16,
    fontFamily: FontFamily.istokWebRegular,
    position: "absolute",
  },
  textTypo3: {
    height: 18,
    width: 21,
    top: 338,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo2: {
    width: 13,
    top: 332,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo1: {
    top: 391,
    height: 18,
    width: 21,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textTypo: {
    top: 385,
    width: 13,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  sensor2Child: {
    top: 14,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 320,
    height: 39,
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    height: 19,
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textShadowRadius: 4,
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  image29Icon: {
    top: 86,
    left: 110,
    width: 100,
    height: 100,
    position: "absolute",
  },
  sensor2Item: {
    top: 273,
    left: 35,
    backgroundColor: Color.forest5,
    width: 250,
    height: 25,
  },
  irrigationSensorNickname: {
    color: Color.colorBlack,
  },
  text: {
    color: Color.colorIndianred,
  },
  irrigationSensorNicknameContainer: {
    top: 259,
  },
  sensor01: {
    top: 278,
    left: 41,
    width: 81,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
  },
  enterConfirmedPasswordContainer: {
    top: 367,
  },
  enterPasswordContainer: {
    top: 313,
    left: 31,
    width: 110,
    fontSize: FontSize.size_4xs,
  },
  sensor2Inner: {
    top: 505,
    left: 114,
    width: 91,
    height: 23,
    backgroundColor: Color.forest3,
  },
  sensorDetected: {
    top: 214,
    left: 71,
    width: 165,
    height: 17,
    color: Color.colorBlack,
    fontSize: FontSize.size_4xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  text3: {
    left: 72,
  },
  text4: {
    left: 150,
  },
  text5: {
    left: 189,
  },
  text6: {
    left: 228,
  },
  text7: {
    left: 111,
  },
  addSensor: {
    top: 509,
    left: 120,
    width: 80,
    height: 14,
    fontSize: FontSize.size_2xs,
  },
  text8: {
    left: 76,
  },
  text9: {
    left: 115,
  },
  text10: {
    left: 154,
  },
  text11: {
    left: 193,
  },
  text12: {
    left: 232,
  },
  text13: {
    left: 72,
  },
  text14: {
    left: 150,
  },
  text15: {
    left: 189,
  },
  text16: {
    left: 228,
  },
  text17: {
    left: 111,
  },
  text18: {
    left: 76,
  },
  text19: {
    left: 115,
  },
  text20: {
    left: 154,
  },
  text21: {
    left: 193,
  },
  text22: {
    left: 232,
  },
  sensor2: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default Sensor1;
