import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const FertilizerCalculator1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.fertilizerCalculator2, styles.iconLayout]}>
      <View style={styles.fertilizerCalculator2Child} />
      <Text style={styles.fertilizerCalculator}>Fertilizer Calculator</Text>
      <View
        style={[styles.fertilizerCalculator2Item, styles.fertilizerShadowBox1]}
      />
      <View
        style={[styles.fertilizerCalculator2Inner, styles.fertilizerShadowBox]}
      />
      <Text style={[styles.dap, styles.dapFlexBox]}>DAP</Text>
      <Text style={[styles.kg, styles.kgFlexBox]}>kg</Text>
      <View style={[styles.rectangleView, styles.fertilizerShadowBox]} />
      <Text style={[styles.mop, styles.dapFlexBox]}>MOP</Text>
      <Text style={[styles.kg1, styles.kgFlexBox]}>kg</Text>
      <View
        style={[styles.fertilizerCalculator2Child1, styles.fertilizerShadowBox]}
      />
      <Text style={[styles.urea, styles.dapFlexBox]}>Urea</Text>
      <Text style={[styles.kg2, styles.kgFlexBox]}>kg</Text>
      <Text style={styles.chooseYourPreferredContainer}>
        <Text
          style={styles.chooseYourPreferred}
        >{`Choose your preferred fertilizer combination!
`}</Text>
        <Text style={styles.belowAreRecommended}>
          (Below are recommended amount for one season)
        </Text>
      </Text>
      <Text style={[styles.dapmopurea, styles.mopureaTypo]}>DAP/MOP/Urea</Text>
      <View
        style={[
          styles.fertilizerCalculator2Child2,
          styles.fertilizerShadowBox1,
        ]}
      />
      <View
        style={[
          styles.fertilizerCalculator2Child3,
          styles.fertilizerChildShadowBox,
        ]}
      />
      <Text style={styles.text}>10-26-26</Text>
      <Text style={[styles.kg3, styles.kg3FlexBox]}>kg</Text>
      <View
        style={[
          styles.fertilizerCalculator2Child4,
          styles.fertilizerChildShadowBox,
        ]}
      />
      <Text style={[styles.mop1, styles.mop1FlexBox]}>MOP</Text>
      <Text style={[styles.kg4, styles.kg3FlexBox]}>kg</Text>
      <View
        style={[
          styles.fertilizerCalculator2Child5,
          styles.fertilizerChildShadowBox,
        ]}
      />
      <Text style={[styles.urea1, styles.mop1FlexBox]}>Urea</Text>
      <Text style={[styles.kg5, styles.kg3FlexBox]}>kg</Text>
      <Text style={[styles.mopurea, styles.mopureaTypo]}>
        10-26-26/MOP/Urea
      </Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("FertilizerCalculator")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: "100%",
  },
  fertilizerShadowBox1: {
    height: 97,
    width: 271,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorLightgray_100,
    borderRadius: Border.br_8xs,
    left: 25,
    position: "absolute",
  },
  fertilizerShadowBox: {
    height: 23,
    width: 46,
    backgroundColor: Color.colorDarkseagreen_100,
    top: 184,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  dapFlexBox: {
    height: 11,
    width: 27,
    top: 173,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  kgFlexBox: {
    top: 190,
    height: 11,
    width: 27,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  mopureaTypo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
    color: Color.colorBlack,
    left: 39,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  fertilizerChildShadowBox: {
    top: 309,
    height: 23,
    width: 46,
    backgroundColor: Color.colorDarkseagreen_100,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  kg3FlexBox: {
    top: 315,
    height: 11,
    width: 27,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  mop1FlexBox: {
    top: 298,
    height: 11,
    width: 27,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  fertilizerCalculator2Child: {
    top: 14,
    left: 0,
    backgroundColor: Color.olive4,
    width: 320,
    height: 39,
    position: "absolute",
  },
  fertilizerCalculator: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    width: 228,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  fertilizerCalculator2Item: {
    top: 135,
  },
  fertilizerCalculator2Inner: {
    left: 39,
  },
  dap: {
    left: 49,
  },
  kg: {
    left: 62,
  },
  rectangleView: {
    left: 124,
  },
  mop: {
    left: 134,
  },
  kg1: {
    left: 147,
  },
  fertilizerCalculator2Child1: {
    left: 213,
  },
  urea: {
    left: 223,
  },
  kg2: {
    left: 236,
  },
  chooseYourPreferred: {
    fontSize: 16,
  },
  belowAreRecommended: {
    fontSize: FontSize.size_3xs,
  },
  chooseYourPreferredContainer: {
    top: 60,
    height: 68,
    textAlign: "left",
    color: Color.colorBlack,
    width: 271,
    left: 25,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  dapmopurea: {
    top: 145,
    width: 97,
    height: 17,
  },
  fertilizerCalculator2Child2: {
    top: 260,
  },
  fertilizerCalculator2Child3: {
    left: 39,
  },
  text: {
    top: 300,
    left: 37,
    width: 51,
    height: 6,
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  kg3: {
    left: 62,
  },
  fertilizerCalculator2Child4: {
    left: 124,
  },
  mop1: {
    left: 134,
  },
  kg4: {
    left: 147,
  },
  fertilizerCalculator2Child5: {
    left: 213,
  },
  urea1: {
    left: 223,
  },
  kg5: {
    left: 236,
  },
  mopurea: {
    top: 270,
    width: 127,
    height: 16,
  },
  icon: {
    height: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  fertilizerCalculator2: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
  },
});

export default FertilizerCalculator1;
