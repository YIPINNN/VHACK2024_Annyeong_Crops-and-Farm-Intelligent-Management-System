import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import ToIncreaseSoil from "../components/ToIncreaseSoilAcidity";
import ToDecreaseSoil from "../components/ToDecreaseSoilAcidity";
import PhMeter from "../components/PhMeter";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const KnowledgeForOptimumSoilPH = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.knowledgeForOptimumSoilPh}>
      <View style={styles.knowledgeForOptimumSoilPhChild} />
      <Text style={styles.thingsToKnow}>THINGS TO KNOW</Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth4")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <View
        style={[styles.knowledgeForOptimumSoilPhItem, styles.soilPosition1]}
      />
      <Text
        style={[styles.itDecreasesThe, styles.soilPosition]}
      >{`It decreases the availability of plant nutrients, such as phosphorus and molybdenum, and increases the availability of some elements to toxic levels, particularly aluminium and manganese
Essential plant nutrients can also be leached below the rooting zone
Acidity can degrade the favorable environment for bacteria, earthworms and other soil organisms
Highly acidic soils can inhibit the survival of useful bacteria, such as the rhizobia bacteria that fix nitrogen for legumes`}</Text>
      <Image
        style={[styles.plantsIcon, styles.soilPosition]}
        contentFit="cover"
        source={require("../assets/4-plants1.png")}
      />
      <Text style={[styles.impactOfSoil, styles.impactOfSoilTypo]}>
        Impact Of Soil pH On Plant Growth
      </Text>
      <Text style={[styles.soilPhLevelsContainer, styles.soilPosition]}>
        <Text style={styles.soilPhLevelsAPhcaRangeBe}>
          <Text style={styles.soilPhLevels}>{`Soil pH levels
`}</Text>
          <Text style={styles.aPhcaRangeBetween5And6I}>
            <Text
              style={styles.aPhcaRange}
            >{`A pHCa range between 5 and 6 is considered ideal for most plants.
`}</Text>
          </Text>
        </Text>
        <Text style={styles.ph65CloseToNeutralOp}>
          <Text style={styles.soilPhLevelsAPhcaRangeBe}>
            <Text style={styles.aPhcaRangeBetween5And6I}>pH 6.5 — </Text>
          </Text>
          <Text style={[styles.closeToNeutral, styles.slightlyAcid1Typo]}>
            close to neutral
          </Text>
          <Text
            style={styles.optimumForMany}
          >{` — Optimum for many acid-sensitive plants. Some trace elements may become unavailable.
pH 5.5 — `}</Text>
          <Text style={styles.slightlyAcid}>
            <Text style={styles.slightlyAcid1Typo}>slightly acid</Text>
          </Text>
          <Text style={styles.aPhcaRangeBetween5And6I}>
            <Text style={styles.slightlyAcid}> </Text>
            <Text
              style={styles.soilPhLevelsAPhcaRangeBe}
            >{`— Optimal balance of major nutrients and trace elements available for plant uptake.
pH 5.0 — `}</Text>
          </Text>
          <Text style={styles.slightlyAcid}>
            <Text style={styles.slightlyAcid1Typo}>moderately acid</Text>
          </Text>
          <Text style={styles.aPhcaRangeBetween5And6I}>
            <Text style={styles.slightlyAcid}> </Text>
            <Text
              style={styles.soilPhLevelsAPhcaRangeBe}
            >{`— Below pH 4.8 aluminium (Al) can become toxic to plants, depending on soil type. Phosphorus combines with Al and may be less available to plants.
pH 4.5 — `}</Text>
          </Text>
          <Text style={[styles.closeToNeutral, styles.slightlyAcid1Typo]}>
            strongly acid
          </Text>
          <Text
            style={styles.optimumForMany}
          >{` — Aluminium becomes soluble in toxic quantities. Manganese (Mn) becomes soluble and toxic to plants in some soils, depending on temperature and moisture conditions. Molybdenum (Mo) is less available. Soil bacterial activity is slowed down.
pH 4.0 — `}</Text>
          <Text style={[styles.closeToNeutral, styles.slightlyAcid1Typo]}>
            extremely acid
          </Text>
          <Text style={styles.optimumForMany}>
             — Irreversible soil structural breakdown can occur.
          </Text>
        </Text>
      </Text>
      <Image
        style={[styles.methodsToIncreaseSoilAcidi, styles.soilPosition]}
        contentFit="cover"
        source={require("../assets/methods-to-increase-soil-acidity.png")}
      />
      <Image
        style={[styles.methodsToDecreseSoilAcidit, styles.soilPosition]}
        contentFit="cover"
        source={require("../assets/methods-to-decrese-soil-acidity.png")}
      />
      <ToIncreaseSoil />
      <ToDecreaseSoil />
      <PhMeter />
    </View>
  );
};

const styles = StyleSheet.create({
  soilPosition1: {
    width: 258,
    left: 31,
    position: "absolute",
  },
  soilPosition: {
    width: 224,
    left: 48,
    position: "absolute",
  },
  impactOfSoilTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
  },
  slightlyAcid1Typo: {
    fontFamily: FontFamily.sarabunExtraBold,
    fontWeight: "800",
  },
  knowledgeForOptimumSoilPhChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.colorDarkolivegreen_100,
    width: 320,
    height: 39,
    position: "absolute",
  },
  thingsToKnow: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  knowledgeForOptimumSoilPhItem: {
    top: 97,
    backgroundColor: Color.colorTan,
    height: 1287,
    borderRadius: Border.br_8xs,
  },
  itDecreasesThe: {
    top: 324,
    height: 230,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    fontSize: FontSize.size_2xs,
  },
  plantsIcon: {
    top: 116,
    height: 193,
    borderRadius: Border.br_8xs,
  },
  impactOfSoil: {
    top: 72,
    fontSize: FontSize.size_mini,
    height: 29,
    width: 258,
    left: 31,
    position: "absolute",
  },
  soilPhLevels: {
    fontSize: FontSize.size_xs,
    fontWeight: "600",
    fontFamily: FontFamily.sarabunSemiBold,
  },
  aPhcaRange: {
    fontSize: FontSize.size_3xs,
  },
  aPhcaRangeBetween5And6I: {
    fontFamily: FontFamily.sanchezRegular,
  },
  soilPhLevelsAPhcaRangeBe: {
    color: Color.colorBlack,
  },
  closeToNeutral: {
    color: Color.colorDarkolivegreen_100,
  },
  optimumForMany: {
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
  },
  slightlyAcid: {
    color: Color.colorDarkolivegreen_100,
  },
  ph65CloseToNeutralOp: {
    fontSize: FontSize.size_2xs,
  },
  soilPhLevelsContainer: {
    top: 577,
    textAlign: "justify",
  },
  methodsToIncreaseSoilAcidi: {
    top: 1008,
    height: 149,
    borderRadius: Border.br_8xs,
  },
  methodsToDecreseSoilAcidit: {
    top: 1196,
    height: 168,
    borderRadius: Border.br_8xs,
  },
  knowledgeForOptimumSoilPh: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default KnowledgeForOptimumSoilPH;
