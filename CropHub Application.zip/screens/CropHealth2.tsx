import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CropHealth2 = () => {
  return (
    <View style={styles.cropHealth5}>
      <View style={styles.cropHealth5Child} />
      <Text style={styles.treament}>Treament</Text>
      <Image
        style={[styles.makiarrowIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/makiarrow1.png")}
      />
      <View style={[styles.cropHealth5Item, styles.cropShadowBox]} />
      <View style={[styles.cropHealth5Inner, styles.cropShadowBox]} />
      <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      <Text style={[styles.nameOfDisease, styles.nameOfDiseaseTypo]}>
        Name of Disease
      </Text>
      <Image
        style={styles.arrowDownSignToNavigate}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <Image
        style={styles.pictureIcon}
        contentFit="cover"
        source={require("../assets/picture1.png")}
      />
      <Image
        style={[styles.mdinumeric1CircleIcon, styles.circleIconLayout]}
        contentFit="cover"
        source={require("../assets/mdinumeric1circle.png")}
      />
      <Image
        style={[styles.mdinumeric2CircleIcon, styles.circleIconLayout]}
        contentFit="cover"
        source={require("../assets/mdinumeric2circle.png")}
      />
      <Text style={[styles.diagnosisResult, styles.diagnosisResultTypo]}>
        Diagnosis Result
      </Text>
      <Text style={[styles.recommendations, styles.diagnosisResultTypo]}>
        Recommendations
      </Text>
      <Text style={[styles.overallExplanationOf, styles.iconPosition]}>
        Overall explanation of the treatment for different stage of disease.
      </Text>
      <Text style={[styles.organicControl, styles.controlTypo]}>
        Organic Control
      </Text>
      <Text style={[styles.detailsOfTreatment, styles.detailsTypo]}>
        Details of treatment
      </Text>
      <Image
        style={[styles.mdiorganicIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/mdiorganic.png")}
      />
      <View style={[styles.cropHealth5Child1, styles.rectangleViewShadowBox]} />
      <Text style={[styles.chemicalControl, styles.controlTypo]}>
        Chemical Control
      </Text>
      <Text style={[styles.detailsOfTreatment1, styles.detailsTypo]}>
        Details of treatment
      </Text>
      <Image
        style={[styles.flaskIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/flask.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: 24,
  },
  cropShadowBox: {
    width: 271,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 24,
    position: "absolute",
  },
  rectangleViewShadowBox: {
    height: 95,
    width: 271,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 24,
    position: "absolute",
  },
  nameOfDiseaseTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  circleIconLayout: {
    height: 30,
    width: 30,
    overflow: "hidden",
    position: "absolute",
  },
  diagnosisResultTypo: {
    width: 232,
    fontSize: FontSize.size_lg,
    left: 57,
    height: 24,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  iconPosition: {
    left: 30,
    position: "absolute",
  },
  controlTypo: {
    width: 220,
    fontSize: FontSize.size_mini,
    left: 54,
    textAlign: "left",
    color: Color.colorBlack,
    height: 21,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  detailsTypo: {
    height: 36,
    width: 216,
    left: 32,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cropHealth5Child: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest2,
    width: 320,
    height: 39,
    position: "absolute",
  },
  treament: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  makiarrowIcon: {
    top: 23,
    left: 12,
    height: 21,
    overflow: "hidden",
    position: "absolute",
  },
  cropHealth5Item: {
    top: 91,
    height: 61,
  },
  cropHealth5Inner: {
    top: 222,
    height: 73,
  },
  rectangleView: {
    top: 312,
  },
  nameOfDisease: {
    top: 108,
    left: 93,
    width: 157,
    height: 28,
    position: "absolute",
  },
  arrowDownSignToNavigate: {
    top: 113,
    left: 270,
    width: 17,
    height: 18,
    position: "absolute",
  },
  pictureIcon: {
    top: 101,
    width: 54,
    height: 41,
    left: 27,
    position: "absolute",
  },
  mdinumeric1CircleIcon: {
    top: 61,
    left: 24,
    height: 30,
    width: 30,
  },
  mdinumeric2CircleIcon: {
    top: 186,
    left: 27,
  },
  diagnosisResult: {
    top: 65,
    height: 24,
  },
  recommendations: {
    top: 190,
    height: 24,
  },
  overallExplanationOf: {
    top: 226,
    width: 265,
    height: 47,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  organicControl: {
    top: 319,
  },
  detailsOfTreatment: {
    top: 345,
  },
  mdiorganicIcon: {
    top: 316,
    height: 24,
    overflow: "hidden",
    width: 24,
  },
  cropHealth5Child1: {
    top: 424,
  },
  chemicalControl: {
    top: 433,
  },
  detailsOfTreatment1: {
    top: 457,
  },
  flaskIcon: {
    top: 430,
    height: 24,
    width: 24,
    left: 30,
  },
  cropHealth5: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
  },
});

export default CropHealth2;
