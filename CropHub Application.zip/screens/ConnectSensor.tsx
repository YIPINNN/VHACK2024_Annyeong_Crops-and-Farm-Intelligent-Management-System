import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const ConnectSensor = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.connectSensor}>
      <View style={styles.connectSensorChild} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={styles.image29Icon}
        contentFit="cover"
        source={require("../assets/image-291.png")}
      />
      <Text style={styles.activateBluetoothTo}>
        Activate Bluetooth to connect sensor.
      </Text>
      <Image
        style={styles.image30Icon}
        contentFit="cover"
        source={require("../assets/image-30.png")}
      />
      <View style={styles.connectSensorItem} />
      <Pressable
        style={[styles.sensor1, styles.sensorPosition]}
        onPress={() => navigation.navigate("Sensor2")}
      >
        <Text style={styles.sensorTypo}>Sensor1</Text>
      </Pressable>
      <Text style={[styles.sensor2, styles.sensorTypo]}>Sensor2</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  sensorPosition: {
    left: 53,
    position: "absolute",
  },
  sensorTypo: {
    height: 18,
    width: 214,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
  },
  connectSensorChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    fontWeight: "700",
    fontFamily: FontFamily.istokWebBold,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  image29Icon: {
    top: 86,
    left: 110,
    width: 100,
    height: 100,
    position: "absolute",
  },
  activateBluetoothTo: {
    top: 239,
    left: 77,
    fontSize: FontSize.size_4xs,
    width: 165,
    height: 17,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  image30Icon: {
    top: 268,
    left: 135,
    width: 40,
    height: 40,
    position: "absolute",
  },
  connectSensorItem: {
    top: 335,
    left: 46,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.forest5,
    width: 227,
    height: 107,
    position: "absolute",
  },
  sensor1: {
    top: 348,
  },
  sensor2: {
    top: 366,
    left: 53,
    position: "absolute",
  },
  connectSensor: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default ConnectSensor;
