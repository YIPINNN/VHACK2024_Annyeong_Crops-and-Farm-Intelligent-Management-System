import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const ApplyForPesticide = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.applyForPesticide, styles.iconLayout]}>
      <View style={styles.applyForPesticideChild} />
      <Text style={styles.pesticide}>PESTICIDE</Text>
      <Image
        style={styles.applyForPesticideItem}
        contentFit="cover"
        source={require("../assets/rectangle-4.png")}
      />
      <Text style={[styles.recommendation, styles.recommendationTypo]}>
        Recommendation
      </Text>
      <Text
        style={[styles.areaCodeA005, styles.areaCodeA005Typo]}
      >{`Area code: A-005
Sensor code: S-112`}</Text>
      <Image
        style={styles.pesticideIcon}
        contentFit="cover"
        source={require("../assets/pesticide.png")}
      />
      <Text
        style={[styles.typeOfInsecticide, styles.areaCodeA005Typo]}
      >{`Type of insecticide: Beauveria
Amount required to apply: 
For Prevention: Spraying: 3-5 Kg/ha
For Control: Spraying: 5 Kg/ha`}</Text>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
      <Pressable
        style={styles.applyForPesticideInner}
        onPress={() => navigation.navigate("ApplyForPesticide")}
      />
      <Text style={[styles.applyPesticide, styles.recommendationTypo]}>
        Apply pesticide
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: "100%",
  },
  recommendationTypo: {
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  areaCodeA005Typo: {
    left: 48,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  applyForPesticideChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.olive3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  pesticide: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textAlign: "center",
    width: 228,
    height: 19,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  applyForPesticideItem: {
    top: 279,
    left: 31,
    borderRadius: Border.br_8xs,
    width: 258,
    height: 109,
    position: "absolute",
  },
  recommendation: {
    top: 261,
    left: 196,
    fontWeight: "600",
    fontFamily: FontFamily.sarabunSemiBold,
    width: 114,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
  },
  areaCodeA005: {
    top: 210,
  },
  pesticideIcon: {
    top: 73,
    left: 118,
    width: 89,
    height: 94,
    position: "absolute",
  },
  typeOfInsecticide: {
    top: 297,
    width: 222,
  },
  icon: {
    height: "100%",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  applyForPesticideInner: {
    top: 431,
    left: 79,
    borderRadius: Border.br_xs,
    backgroundColor: Color.olive4,
    width: 162,
    height: 27,
    position: "absolute",
  },
  applyPesticide: {
    top: 438,
    left: 122,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
  },
  applyForPesticide: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
  },
});

export default ApplyForPesticide;
