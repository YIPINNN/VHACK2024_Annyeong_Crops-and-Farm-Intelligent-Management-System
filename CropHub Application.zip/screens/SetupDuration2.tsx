import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const SetupDuration2 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <View style={[styles.setupDurationChild, styles.setupDurationChildBg]} />
      <Text style={[styles.irrigationSystem, styles.irrigationSystemTypo]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupDurationItem, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.setupDurationInner, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>3</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-3.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Image
        style={[styles.setupDurationChild1, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild2, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <Pressable
        style={[styles.rectanglePressable, styles.setupDurationChildBg]}
        onPress={() => navigation.navigate("SetupDuration3")}
      />
      <Text style={styles.next}>Next</Text>
      <View style={[styles.ellipseParent, styles.groupChildLayout]}>
        <Image
          style={[styles.groupChild, styles.groupChildLayout]}
          contentFit="cover"
          source={require("../assets/ellipse-8.png")}
        />
        <Image
          style={styles.image34Icon}
          contentFit="cover"
          source={require("../assets/image-34.png")}
        />
      </View>
      <Text style={[styles.wateringDuration, styles.irrigationSystemTypo]}>
        Watering Duration
      </Text>
      <Text style={styles.decideHowLong}>
        Decide how long each watering should last.
      </Text>
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <View style={[styles.setupDurationChild4, styles.rectangleViewLayout]} />
      <Text style={[styles.hours, styles.hoursTypo]}>hours</Text>
      <Text style={[styles.minutes, styles.hoursTypo]}>minutes</Text>
      <Text style={[styles.text4, styles.textPosition]}>0</Text>
      <Text style={[styles.text5, styles.textPosition]}>30</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  setupDurationChildBg: {
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  irrigationSystemTypo: {
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    textAlign: "center",
    position: "absolute",
  },
  setupLayout: {
    height: 28,
    width: 28,
    top: 219,
    position: "absolute",
  },
  textTypo1: {
    width: 16,
    top: 226,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  textTypo: {
    top: 227,
    width: 16,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    top: 234,
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    top: 254,
    fontSize: FontSize.size_4xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  groupChildLayout: {
    height: 100,
    width: 100,
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 21,
    width: 26,
    borderWidth: 0.5,
    backgroundColor: Color.colorGainsboro_200,
    top: 358,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  hoursTypo: {
    height: 17,
    width: 43,
    top: 362,
    color: Color.colorBlack,
    fontSize: FontSize.size_2xs,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  textPosition: {
    height: 13,
    top: 361,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  setupDurationChild: {
    top: 14,
    width: 320,
    height: 39,
    left: 0,
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    width: 228,
    color: Color.colorWhite,
    fontSize: FontSize.size_xs,
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  sensor: {
    top: 59,
    left: 272,
    fontSize: FontSize.size_3xs,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupDurationItem: {
    left: 34,
  },
  text: {
    left: 40,
  },
  setupDurationInner: {
    left: 184,
  },
  text1: {
    left: 190,
  },
  ellipseIcon: {
    left: 259,
  },
  text2: {
    left: 265,
  },
  setupDurationChild1: {
    left: 109,
  },
  text3: {
    left: 115,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild2: {
    left: 137,
  },
  setupDurationChild3: {
    left: 212,
  },
  period: {
    left: 28,
    color: Color.colorGray_200,
    width: 40,
    height: 12,
    top: 254,
  },
  duration: {
    left: 103,
    width: 40,
    height: 12,
    top: 254,
    color: Color.colorBlack,
  },
  time: {
    left: 178,
    width: 40,
    height: 12,
    top: 254,
    color: Color.colorBlack,
  },
  confirmed: {
    left: 250,
    width: 46,
    height: 12,
    top: 254,
    color: Color.colorBlack,
  },
  rectanglePressable: {
    top: 505,
    left: 114,
    borderRadius: Border.br_8xs,
    width: 91,
    height: 23,
  },
  next: {
    top: 509,
    left: 120,
    width: 80,
    height: 14,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_2xs,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
  },
  image34Icon: {
    top: 28,
    left: 25,
    width: 50,
    height: 50,
    position: "absolute",
  },
  ellipseParent: {
    top: 82,
    left: 113,
  },
  wateringDuration: {
    top: 308,
    left: 97,
    fontSize: FontSize.size_sm,
    width: 131,
    color: Color.colorBlack,
    height: 19,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  decideHowLong: {
    top: 329,
    left: 75,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  rectangleView: {
    left: 94,
  },
  setupDurationChild4: {
    left: 159,
  },
  hours: {
    left: 116,
  },
  minutes: {
    left: 188,
  },
  text4: {
    left: 101,
    width: 12,
    textAlign: "center",
    height: 13,
    top: 361,
  },
  text5: {
    left: 166,
    textAlign: "left",
    width: 14,
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration2;
