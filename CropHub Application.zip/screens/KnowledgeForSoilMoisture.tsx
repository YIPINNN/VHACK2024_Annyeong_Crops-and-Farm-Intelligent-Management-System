import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const KnowledgeForSoilMoisture = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.knowledgeForSoilMoisture}>
      <View style={styles.knowledgeForSoilMoistureChild} />
      <Text style={styles.thingsToKnow}>THINGS TO KNOW</Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth4")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <View style={[styles.tensiomeeter, styles.tensiomeeterLayout]}>
        <View style={[styles.tensiomeeterChild, styles.gypsumChildPosition]} />
        <Text
          style={[
            styles.tensiometersMeasureTheContainer,
            styles.measureContainerPosition,
          ]}
        >
          <Text style={styles.tensiometers}>{`Tensiometers
`}</Text>
          <Text
            style={styles.measureTheTension}
          >{`Measure the tension or suction exerted by soil water on a porous ceramic tip inserted into the soil
Typically measure soil moisture tension in the range of 0 to -85 centibars (cb) or kilopascals (kPa)
Installation:
Installed in the root zone of plants at various depths, depending on the crop's root system and irrigation requirements
The ceramic tip should be in good contact with the soil to accurately measure tension`}</Text>
        </Text>
        <Image
          style={[styles.panamaDisease3InitialExt, styles.panamaLayout]}
          contentFit="cover"
          source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-11.png")}
        />
      </View>
      <Text style={styles.soilMoistureMonitoring}>
        Soil Moisture Monitoring Tools
      </Text>
      <View style={[styles.gypsumBlock, styles.gypsumLayout1]}>
        <View style={[styles.gypsumBlockChild, styles.gypsumLayout1]} />
        <Text
          style={[
            styles.gypsumBlocksMeasureContainer,
            styles.measureContainerPosition,
          ]}
        >
          <Text style={styles.tensiometers}>{`Gypsum blocks
`}</Text>
          <Text
            style={styles.measureTheTension}
          >{`Measure soil moisture by detecting changes in electrical resistance as moisture content in the soil changes
It contains a porous ceramic block impregnated with gypsum, which expands or contracts with changes in soil moisture
Typically have a measurement range of 0% to 100% soil moisture content
Installation:
Buried at desired depths in the soil, typically in the root zone of plants`}</Text>
        </Text>
        <Image
          style={[styles.panamaDisease3InitialExt1, styles.panamaLayout]}
          contentFit="cover"
          source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-21.png")}
        />
      </View>
      <View style={[styles.gypsumBlock1, styles.gypsumLayout]}>
        <View style={[styles.gypsumBlockItem, styles.gypsumLayout]} />
        <Text
          style={[
            styles.timeDomainReflectometryTdrContainer,
            styles.measureContainerPosition,
          ]}
        >
          <Text style={styles.tensiometers}>{`Time Domain Reflectometry (TDR)
`}</Text>
          <Text
            style={styles.measureTheTension}
          >{`Measures soil moisture by sending an electromagnetic pulse along a waveguide inserted into the soil
The pulse travels through the soil and is reflected back to the instrument at interfaces where there are changes in dielectric permittivity, such as the soil-water interface
Provide soil moisture readings in terms of volumetric water content (VWC) or soil water tension
Installation:
TDR probes are inserted into the soil at desired depths and locations
Maintenance involves periodic calibration checks and ensuring the integrity of the waveguide`}</Text>
        </Text>
        <Image
          style={[styles.panamaDisease3InitialExt2, styles.panamaLayout]}
          contentFit="cover"
          source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-22.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  tensiomeeterLayout: {
    height: 409,
    width: 258,
    position: "absolute",
  },
  gypsumChildPosition: {
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    top: 0,
    left: 0,
  },
  measureContainerPosition: {
    width: 224,
    left: 17,
    top: 19,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  panamaLayout: {
    height: 135,
    width: 224,
    left: 17,
    position: "absolute",
  },
  gypsumLayout1: {
    height: 397,
    width: 258,
    position: "absolute",
  },
  gypsumLayout: {
    height: 467,
    width: 258,
    position: "absolute",
  },
  knowledgeForSoilMoistureChild: {
    top: 14,
    backgroundColor: Color.colorDarkolivegreen_100,
    width: 320,
    height: 39,
    left: 0,
    position: "absolute",
  },
  thingsToKnow: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  makiarrow: {
    left: 12,
    top: 23,
    width: 24,
    height: 21,
    position: "absolute",
  },
  tensiomeeterChild: {
    height: 409,
    width: 258,
    position: "absolute",
  },
  tensiometers: {
    fontSize: FontSize.size_xs,
  },
  measureTheTension: {
    fontSize: FontSize.size_2xs,
  },
  tensiometersMeasureTheContainer: {
    height: 246,
  },
  panamaDisease3InitialExt: {
    top: 260,
  },
  tensiomeeter: {
    top: 96,
    left: 31,
  },
  soilMoistureMonitoring: {
    top: 72,
    fontSize: FontSize.size_mini,
    width: 235,
    height: 24,
    textAlign: "left",
    color: Color.colorBlack,
    left: 31,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  gypsumBlockChild: {
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    top: 0,
    left: 0,
  },
  gypsumBlocksMeasureContainer: {
    height: 222,
  },
  panamaDisease3InitialExt1: {
    top: 241,
  },
  gypsumBlock: {
    top: 523,
    left: 31,
  },
  gypsumBlockItem: {
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    top: 0,
    left: 0,
  },
  timeDomainReflectometryTdrContainer: {
    height: 281,
  },
  panamaDisease3InitialExt2: {
    top: 312,
  },
  gypsumBlock1: {
    top: 940,
    left: 31,
  },
  knowledgeForSoilMoisture: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default KnowledgeForSoilMoisture;
