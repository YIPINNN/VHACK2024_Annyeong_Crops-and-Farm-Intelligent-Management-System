import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Color } from "../GlobalStyles";

const LandingPage1 = () => {
  return <View style={styles.landingPage} />;
};

const styles = StyleSheet.create({
  landingPage: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default LandingPage1;
