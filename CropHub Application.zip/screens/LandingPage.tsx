import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const LandingPage = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.landingPage}>
      <View style={[styles.landingPageChild, styles.landingPosition]} />
      <View style={[styles.landingPageItem, styles.landingPosition]} />
      <Text style={styles.homePage}>Home Page</Text>
      <Text style={styles.yourField}>Your Field</Text>
      <Text style={[styles.wheat, styles.wheatTypo]}>Wheat</Text>
      <Pressable
        style={styles.landingPageInner}
        onPress={() => navigation.navigate("Weather")}
      />
      <View
        style={[styles.gameIconsthreeLeaves, styles.carbonaddFilledIconLayout]}
      />
      <Image
        style={[
          styles.iconamoonprofileCircleFill,
          styles.iconamoonprofileCircleFillPosition,
        ]}
        contentFit="cover"
        source={require("../assets/iconamoonprofilecirclefill.png")}
      />
      <Image
        style={[styles.vectorIcon, styles.iconLayout1]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Pressable
        style={[
          styles.fluentpeopleCommunityAdd20,
          styles.iconamoonprofileCircleFillPosition,
        ]}
        onPress={() => navigation.navigate("Community")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/fluentpeoplecommunityadd20filled.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.rectanglePressable, styles.landingPageChild1ShadowBox]}
        onPress={() => navigation.navigate("Irrigation")}
      />
      <Pressable
        style={[styles.landingPageChild1, styles.landingPageChild1ShadowBox]}
        onPress={() => navigation.navigate("Soil")}
      />
      <Pressable
        style={[styles.landingPageChild2, styles.landingChildShadowBox1]}
        onPress={() => navigation.navigate("PestMonitoringResult")}
      />
      <Pressable
        style={[styles.landingPageChild3, styles.landingChildShadowBox1]}
        onPress={() => navigation.navigate("CropHealth3")}
      />
      <Pressable
        style={[styles.landingPageChild4, styles.landingChildShadowBox]}
        onPress={() => navigation.navigate("FertilizerCalculator")}
      />
      <Image
        style={styles.image27Icon}
        contentFit="cover"
        source={require("../assets/image-27.png")}
      />
      <Text style={styles.bukitMertajam24Container}>
        <Text style={styles.bukitMertajam24}>{`Bukit Mertajam, 24 March
`}</Text>
        <Text style={styles.partlyCloudy}>Partly cloudy . 24 / 32</Text>
      </Text>
      <Image
        style={[styles.celsiusDegreesSymbolOfTemp, styles.celsiusLayout]}
        contentFit="cover"
        source={require("../assets/celsius-degrees-symbol-of-temperature.png")}
      />
      <Image
        style={[styles.celsiusDegreesSymbolOfTemp1, styles.celsiusLayout]}
        contentFit="cover"
        source={require("../assets/celsius-degrees-symbol-of-temperature.png")}
      />
      <Text style={[styles.yourCrops, styles.profileTypo]}>Your Crops</Text>
      <Text style={[styles.community, styles.profileTypo]}>Community</Text>
      <Text style={[styles.profile, styles.profileTypo]}>Profile</Text>
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={[styles.pestMonitoring, styles.healthCameraLayout]}>{`PEST 
MONITORING`}</Text>
      <Text
        style={[styles.fertilizerCalculator, styles.cultivationTipsTypo]}
      >{`FERTILIZER
CALCULATOR`}</Text>
      <Text style={[styles.healthCamera, styles.soilTypo]}>{`HEALTH 
CAMERA`}</Text>
      <Text style={[styles.soil, styles.soilTypo]}>SOIL</Text>
      <Image
        style={[styles.gameIconsfield, styles.gameLayout]}
        contentFit="cover"
        source={require("../assets/gameiconsfield.png")}
      />
      <Text style={[styles.capsicum, styles.wheatTypo]}>Capsicum</Text>
      <Image
        style={[styles.gameIconsfield1, styles.gameLayout]}
        contentFit="cover"
        source={require("../assets/gameiconsfield1.png")}
      />
      <Text style={[styles.maize, styles.wheatTypo]}>Maize</Text>
      <Image
        style={[styles.gameIconsfield2, styles.gameLayout]}
        contentFit="cover"
        source={require("../assets/gameiconsfield2.png")}
      />
      <Image
        style={[styles.carbonaddFilledIcon, styles.carbonaddFilledIconLayout]}
        contentFit="cover"
        source={require("../assets/carbonaddfilled.png")}
      />
      <Image
        style={styles.irrigationIcon}
        contentFit="cover"
        source={require("../assets/irrigation-icon.png")}
      />
      <Image
        style={styles.image7Icon}
        contentFit="cover"
        source={require("../assets/image-7.png")}
      />
      <Image
        style={[styles.beetleIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/beetle.png")}
      />
      <Image
        style={[styles.fieldIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/field.png")}
      />
      <Image
        style={[styles.npkIcon, styles.npkIconPosition]}
        contentFit="cover"
        source={require("../assets/npk.png")}
      />
      <Pressable
        style={[styles.eparrowUpBold, styles.eparrowPosition5]}
        onPress={() => navigation.navigate("Irrigation")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.eparrowUpBold1, styles.eparrowPosition5]}
        onPress={() => navigation.navigate("Soil")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.eparrowUpBold2, styles.eparrowPosition2]}
        onPress={() => navigation.navigate("PestMonitoringResult")}
      >
        <Image
          style={[styles.icon3, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.eparrowUpBold3, styles.eparrowPosition1]}
        onPress={() => navigation.navigate("CropHealth3")}
      >
        <Image
          style={[styles.icon3, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.eparrowUpBold4, styles.eparrowPosition]}
        onPress={() => navigation.navigate("FertilizerCalculator")}
      >
        <Image
          style={[styles.icon3, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.landingPageChild5, styles.landingChildShadowBox]}
        onPress={() => navigation.navigate("CultivationTips")}
      />
      <Text
        style={[styles.cultivationTips, styles.cultivationTipsTypo]}
      >{`CULTIVATION
TIPS`}</Text>
      <Image
        style={[styles.npkIcon1, styles.npkIconPosition]}
        contentFit="cover"
        source={require("../assets/npk.png")}
      />
      <Pressable
        style={[styles.eparrowUpBold5, styles.eparrowPosition]}
        onPress={() => navigation.navigate("CultivationTips")}
      >
        <Image
          style={[styles.icon3, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/eparrowupbold.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  landingPosition: {
    width: 320,
    backgroundColor: Color.forest3,
    left: 0,
    position: "absolute",
  },
  wheatTypo: {
    top: 107,
    fontSize: FontSize.size_3xs,
    height: 14,
    width: 70,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    left: "50%",
    position: "absolute",
  },
  carbonaddFilledIconLayout: {
    height: 25,
    width: 25,
    position: "absolute",
    overflow: "hidden",
  },
  iconamoonprofileCircleFillPosition: {
    top: 527,
    height: 25,
    width: 25,
    position: "absolute",
  },
  iconLayout1: {
    maxHeight: "100%",
    maxWidth: "100%",
  },
  landingPageChild1ShadowBox: {
    height: 85,
    width: 132,
    borderColor: Color.forest2,
    backgroundColor: Color.colorDarkseagreen_200,
    borderRadius: Border.br_mini,
    top: 206,
    borderWidth: 1.5,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  landingChildShadowBox1: {
    top: 310,
    height: 85,
    width: 132,
    borderColor: Color.forest2,
    backgroundColor: Color.colorDarkseagreen_200,
    borderRadius: Border.br_mini,
    borderWidth: 1.5,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  landingChildShadowBox: {
    top: 414,
    height: 85,
    width: 132,
    borderColor: Color.forest2,
    backgroundColor: Color.colorDarkseagreen_200,
    borderRadius: Border.br_mini,
    borderWidth: 1.5,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  celsiusLayout: {
    height: 10,
    width: 10,
    top: 163,
    position: "absolute",
  },
  profileTypo: {
    top: 552,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  healthCameraLayout: {
    height: 29,
    width: 155,
    top: 350,
  },
  cultivationTipsTypo: {
    top: 456,
    height: 29,
    width: 155,
    color: Color.colorDarkgreen,
    textAlign: "left",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  soilTypo: {
    marginLeft: 16,
    color: Color.colorDarkgreen,
    textAlign: "left",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  gameLayout: {
    width: 36,
    top: 74,
    height: 36,
    position: "absolute",
    overflow: "hidden",
  },
  iconPosition: {
    top: 315,
    height: 35,
    width: 35,
    position: "absolute",
  },
  npkIconPosition: {
    top: 419,
    height: 35,
    width: 35,
    position: "absolute",
  },
  eparrowPosition5: {
    top: 250,
    height: 25,
    width: 25,
    position: "absolute",
  },
  eparrowPosition2: {
    bottom: "33.27%",
    top: "62.32%",
    width: "7.81%",
    height: "4.4%",
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  eparrowPosition1: {
    right: "8.75%",
    left: "83.44%",
  },
  eparrowPosition: {
    bottom: "14.61%",
    top: "80.99%",
    width: "7.81%",
    height: "4.4%",
    position: "absolute",
  },
  landingPageChild: {
    top: 14,
    height: 39,
  },
  landingPageItem: {
    top: 518,
    height: 50,
  },
  homePage: {
    marginLeft: -116,
    top: 26,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    left: "50%",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  yourField: {
    marginLeft: -143,
    top: 57,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    height: 14,
    width: 70,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  wheat: {
    marginLeft: -151,
    color: "#ceaf51",
    fontSize: FontSize.size_3xs,
  },
  landingPageInner: {
    top: 132,
    borderRadius: 30,
    backgroundColor: Color.colorGainsboro_200,
    borderColor: Color.colorGold,
    width: 249,
    height: 60,
    borderWidth: 1.5,
    borderStyle: "solid",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 36,
    position: "absolute",
  },
  gameIconsthreeLeaves: {
    top: 531,
    left: 20,
    opacity: 0.5,
  },
  iconamoonprofileCircleFill: {
    left: 244,
    overflow: "hidden",
  },
  vectorIcon: {
    top: "92.61%",
    right: "76.56%",
    bottom: "2.99%",
    left: "15.63%",
    width: "7.81%",
    height: "4.4%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  fluentpeopleCommunityAdd20: {
    left: 147,
  },
  rectanglePressable: {
    left: 23,
  },
  landingPageChild1: {
    left: 165,
  },
  landingPageChild2: {
    left: 23,
  },
  landingPageChild3: {
    left: 165,
  },
  landingPageChild4: {
    left: 23,
  },
  image27Icon: {
    top: 140,
    left: 228,
    width: 40,
    height: 40,
    position: "absolute",
  },
  bukitMertajam24: {
    fontSize: FontSize.size_xs,
  },
  partlyCloudy: {
    fontSize: FontSize.size_3xs,
  },
  bukitMertajam24Container: {
    top: 145,
    left: 51,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  celsiusDegreesSymbolOfTemp: {
    left: 134,
  },
  celsiusDegreesSymbolOfTemp1: {
    left: 169,
  },
  yourCrops: {
    left: 36,
    top: 552,
  },
  community: {
    left: 133,
  },
  profile: {
    left: 241,
  },
  irrigationSystem: {
    top: 246,
    width: 79,
    height: 36,
    color: Color.colorDarkgreen,
    marginLeft: -129,
    textAlign: "left",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  pestMonitoring: {
    color: Color.colorDarkgreen,
    width: 155,
    top: 350,
    marginLeft: -129,
    textAlign: "left",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  fertilizerCalculator: {
    marginLeft: -129,
    top: 456,
  },
  healthCamera: {
    height: 29,
    width: 155,
    top: 350,
  },
  soil: {
    top: 248,
    width: 75,
    height: 13,
  },
  gameIconsfield: {
    left: 26,
  },
  capsicum: {
    marginLeft: -98,
    color: Color.colorFirebrick,
    fontSize: FontSize.size_3xs,
  },
  gameIconsfield1: {
    left: 79,
  },
  maize: {
    marginLeft: -46,
    color: Color.forest2,
    fontSize: FontSize.size_3xs,
  },
  gameIconsfield2: {
    left: 131,
  },
  carbonaddFilledIcon: {
    top: 80,
    left: 272,
  },
  irrigationIcon: {
    top: 209,
    width: 35,
    left: 31,
    height: 36,
    position: "absolute",
  },
  image7Icon: {
    top: 210,
    height: 35,
    left: 176,
    width: 35,
    position: "absolute",
  },
  beetleIcon: {
    left: 31,
  },
  fieldIcon: {
    left: 176,
    top: 315,
  },
  npkIcon: {
    left: 31,
  },
  eparrowUpBold: {
    left: 124,
  },
  eparrowUpBold1: {
    left: 266,
  },
  icon3: {
    maxHeight: "100%",
    maxWidth: "100%",
  },
  eparrowUpBold2: {
    right: "53.44%",
    left: "38.75%",
  },
  eparrowUpBold3: {
    bottom: "33.27%",
    top: "62.32%",
    width: "7.81%",
    height: "4.4%",
    position: "absolute",
  },
  eparrowUpBold4: {
    right: "53.44%",
    left: "38.75%",
  },
  landingPageChild5: {
    left: 166,
  },
  cultivationTips: {
    marginLeft: 14,
  },
  npkIcon1: {
    left: 174,
  },
  eparrowUpBold5: {
    right: "8.75%",
    left: "83.44%",
  },
  landingPage: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
    width: "100%",
  },
});

export default LandingPage;
