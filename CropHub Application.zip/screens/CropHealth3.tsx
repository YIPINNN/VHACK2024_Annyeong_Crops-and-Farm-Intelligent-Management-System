import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CropHealth3 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.cropHealth, styles.iconLayout]}>
      <View style={[styles.cropHealthChild, styles.childBg]} />
      <Text style={styles.healYourCrop}>Heal your crop</Text>
      <View style={styles.cropHealthItem} />
      <View style={[styles.cropHealthInner, styles.rectangleViewShadowBox]} />
      <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      <Text style={[styles.takeAPicture, styles.treatmentTypo]}>
        Take A Picture
      </Text>
      <Text style={[styles.diagosisHistory, styles.viewAllPosition]}>
        Diagosis History
      </Text>
      <Text style={[styles.dateNameOfContainer, styles.dateContainerLayout]}>
        <Text style={styles.date}>{`Date
`}</Text>
        <Text style={styles.nameOfDisease}>Name of Disease</Text>
      </Text>
      <Text style={[styles.dateNameOfContainer1, styles.dateContainerLayout]}>
        <Text style={styles.date}>{`Date
`}</Text>
        <Text style={styles.nameOfDisease}>Name of Disease</Text>
      </Text>
      <Text style={[styles.viewAll, styles.viewAllPosition]}>View All</Text>
      <Text style={[styles.seeDiagnosis, styles.treatmentTypo]}>
        See Diagnosis
      </Text>
      <Text style={[styles.treatment, styles.treatmentTypo]}>Treatment</Text>
      <Pressable
        style={[styles.button, styles.buttonLayout]}
        onPress={() => navigation.navigate("CropHealth4")}
      >
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.takeAPicture1}>Take a picture</Text>
      </Pressable>
      <Image
        style={styles.fieldIcon}
        contentFit="cover"
        source={require("../assets/field1.png")}
      />
      <Image
        style={styles.photoEditingIcon}
        contentFit="cover"
        source={require("../assets/photo-editing.png")}
      />
      <Image
        style={[styles.arrowDownSignToNavigate, styles.arrowLayout1]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate.png")}
      />
      <Image
        style={[styles.arrowDownSignToNavigate1, styles.arrowLayout]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <Image
        style={[styles.arrowDownSignToNavigate2, styles.arrowLayout]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate1.png")}
      />
      <Image
        style={[styles.arrowDownSignToNavigate3, styles.arrowLayout1]}
        contentFit="cover"
        source={require("../assets/arrow-down-sign-to-navigate.png")}
      />
      <Image
        style={[styles.diagnosticIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/diagnostic.png")}
      />
      <Image
        style={[styles.medicineIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/medicine.png")}
      />
      <Image
        style={[styles.pictureIcon, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture1.png")}
      />
      <Image
        style={[styles.pictureIcon1, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture1.png")}
      />
      <Pressable
        style={[styles.tablerhomeFilled, styles.arrowLayout1]}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: "100%",
  },
  childBg: {
    backgroundColor: Color.forest2,
    left: 0,
  },
  rectangleViewShadowBox: {
    height: 61,
    width: 271,
    left: 29,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  treatmentTypo: {
    height: 12,
    color: Color.colorBlack,
    top: 291,
    width: 82,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  viewAllPosition: {
    top: 412,
    height: 12,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  dateContainerLayout: {
    height: 41,
    width: 157,
    left: 96,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 162,
    position: "absolute",
  },
  arrowLayout1: {
    height: 25,
    position: "absolute",
  },
  arrowLayout: {
    height: 18,
    width: 17,
    position: "absolute",
  },
  iconPosition: {
    width: 55,
    top: 230,
    position: "absolute",
  },
  pictureIconLayout: {
    width: 54,
    left: 36,
    height: 41,
    position: "absolute",
  },
  cropHealthChild: {
    top: 14,
    width: 320,
    height: 39,
    position: "absolute",
  },
  healYourCrop: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cropHealthItem: {
    top: 211,
    width: 267,
    height: 110,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 26,
    position: "absolute",
  },
  cropHealthInner: {
    top: 430,
  },
  rectangleView: {
    top: 504,
  },
  takeAPicture: {
    left: 29,
    color: Color.colorBlack,
    top: 291,
  },
  diagosisHistory: {
    width: 82,
    top: 412,
    fontSize: FontSize.size_3xs,
    left: 26,
  },
  date: {
    fontSize: FontSize.size_5xs,
  },
  nameOfDisease: {
    fontSize: FontSize.size_3xs,
  },
  dateNameOfContainer: {
    top: 440,
  },
  dateNameOfContainer1: {
    top: 514,
  },
  viewAll: {
    left: 259,
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "center",
    width: 41,
    fontSize: FontSize.size_5xs,
  },
  seeDiagnosis: {
    left: 119,
  },
  treatment: {
    left: 209,
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest2,
    left: 0,
  },
  takeAPicture1: {
    top: 6,
    left: 48,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  button: {
    top: 344,
    left: 79,
  },
  fieldIcon: {
    top: 66,
    left: 104,
    width: 112,
    height: 111,
    position: "absolute",
  },
  photoEditingIcon: {
    left: 43,
    width: 53,
    height: 54,
    top: 230,
    position: "absolute",
  },
  arrowDownSignToNavigate: {
    left: 106,
    width: 22,
    top: 244,
    height: 25,
  },
  arrowDownSignToNavigate1: {
    top: 452,
    left: 276,
  },
  arrowDownSignToNavigate2: {
    top: 522,
    left: 280,
  },
  arrowDownSignToNavigate3: {
    left: 196,
    width: 22,
    top: 244,
    height: 25,
  },
  diagnosticIcon: {
    left: 134,
    height: 54,
  },
  medicineIcon: {
    left: 225,
    height: 55,
  },
  pictureIcon: {
    top: 440,
  },
  pictureIcon1: {
    top: 514,
  },
  icon: {
    height: "100%",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
  },
  cropHealth: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
  },
});

export default CropHealth3;
