import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CropHealth4 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.cropHealth2, styles.iconLayout]}>
      <View style={[styles.cropHealth2Child, styles.cropHealth2ChildLayout]} />
      <View style={[styles.cropHealth2Item, styles.cropShadowBox]} />
      <View style={styles.leftArrow} />
      <Pressable
        style={[styles.makiarrow, styles.makiarrowLayout]}
        onPress={() => navigation.navigate("CropHealth3")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/makiarrow.png")}
        />
      </Pressable>
      <View style={styles.simpleLineIconsframe}>
        <Image
          style={[styles.vectorIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/vector2.png")}
        />
        <Text style={styles.fitTheCrop}>
          Fit the crop damage within the frame
        </Text>
      </View>
      <Image
        style={[styles.riflashlightFillIcon, styles.makiarrowLayout]}
        contentFit="cover"
        source={require("../assets/riflashlightfill.png")}
      />
      <Pressable
        style={styles.icroundCircle}
        onPress={() => navigation.navigate("CropHealth5")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/icroundcircle.png")}
        />
      </Pressable>
      <Image
        style={[styles.claritypictureSolidIcon, styles.cropHealth2ChildLayout]}
        contentFit="cover"
        source={require("../assets/claritypicturesolid.png")}
      />
      <Image
        style={styles.materialSymbolshelpIcon}
        contentFit="cover"
        source={require("../assets/materialsymbolshelp.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  cropHealth2ChildLayout: {
    height: 36,
    position: "absolute",
  },
  cropShadowBox: {
    width: 320,
    backgroundColor: Color.colorBlack,
    borderRadius: Border.br_8xs,
    left: 0,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  makiarrowLayout: {
    width: 24,
    position: "absolute",
  },
  cropHealth2Child: {
    top: 0,
    width: 320,
    backgroundColor: Color.colorBlack,
    borderRadius: Border.br_8xs,
    left: 0,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  cropHealth2Item: {
    top: 476,
    height: 92,
    position: "absolute",
  },
  leftArrow: {
    top: 61,
    left: 63,
    width: 178,
    height: 112,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  makiarrow: {
    left: 14,
    top: 7,
    height: 21,
  },
  vectorIcon: {
    height: "78.12%",
    top: "10.94%",
    right: "0%",
    bottom: "10.94%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  fitTheCrop: {
    height: "36.97%",
    width: "45.88%",
    top: "33.03%",
    left: "27.24%",
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.sanchezRegular,
    color: Color.colorWhite,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    position: "absolute",
  },
  simpleLineIconsframe: {
    top: 88,
    left: 20,
    width: 279,
    height: 330,
    position: "absolute",
    overflow: "hidden",
  },
  riflashlightFillIcon: {
    top: 6,
    left: 287,
    height: 24,
    overflow: "hidden",
  },
  icroundCircle: {
    left: 125,
    top: 487,
    width: 69,
    height: 70,
    position: "absolute",
  },
  claritypictureSolidIcon: {
    top: 504,
    left: 38,
    width: 43,
    overflow: "hidden",
  },
  materialSymbolshelpIcon: {
    top: 498,
    left: 241,
    width: 42,
    height: 42,
    position: "absolute",
    overflow: "hidden",
  },
  cropHealth2: {
    backgroundColor: "rgba(0, 0, 0, 0.54)",
    flex: 1,
    height: 568,
    overflow: "hidden",
  },
});

export default CropHealth4;
