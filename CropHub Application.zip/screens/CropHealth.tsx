import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CropHealth = () => {
  return (
    <View style={styles.cropHealth3}>
      <View style={[styles.cropHealth3Child, styles.childBg]} />
      <Text style={styles.results}>Results</Text>
      <View style={[styles.cropHealth3Item, styles.cropShadowBox]} />
      <View style={[styles.button, styles.buttonLayout]}>
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.seeDiagnosis}>See Diagnosis</Text>
      </View>
      <Text style={[styles.nameOfDiseaseContainer, styles.nameContainerLayout]}>
        <Text style={styles.nameOfDisease}>{`Name of Disease
`}</Text>
        <Text style={styles.symptomsListOfSymptomsList}>{`Symptoms
List of symptoms
List of symptoms
List of symptoms
List of symptoms`}</Text>
      </Text>
      <Image
        style={[styles.pictureIcon, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture2.png")}
      />
      <View style={[styles.cropHealth3Inner, styles.cropShadowBox]} />
      <View style={[styles.button1, styles.buttonLayout]}>
        <View style={[styles.buttonChild, styles.buttonLayout]} />
        <Text style={styles.seeDiagnosis}>See Diagnosis</Text>
      </View>
      <Text
        style={[styles.nameOfDiseaseContainer1, styles.nameContainerLayout]}
      >
        <Text style={styles.nameOfDisease}>{`Name of Disease
`}</Text>
        <Text style={styles.symptomsListOfSymptomsList}>{`Symptoms
List of symptoms
List of symptoms
List of symptoms
List of symptoms`}</Text>
      </Text>
      <Image
        style={[styles.pictureIcon1, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture2.png")}
      />
      <Image
        style={styles.makiarrowIcon}
        contentFit="cover"
        source={require("../assets/makiarrow1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  childBg: {
    backgroundColor: Color.forest2,
    left: 0,
  },
  cropShadowBox: {
    height: 300,
    width: 274,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 23,
    position: "absolute",
  },
  buttonLayout: {
    height: 27,
    width: 180,
    position: "absolute",
  },
  nameContainerLayout: {
    height: 127,
    width: 235,
    color: Color.colorBlack,
    left: 36,
    textAlign: "left",
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  pictureIconLayout: {
    height: 143,
    left: 46,
    width: 228,
    position: "absolute",
  },
  cropHealth3Child: {
    top: 14,
    width: 320,
    height: 39,
    position: "absolute",
  },
  results: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    textAlign: "center",
    height: 19,
    width: 228,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  cropHealth3Item: {
    top: 79,
  },
  buttonChild: {
    top: 0,
    borderRadius: Border.br_xs,
    backgroundColor: Color.forest2,
    left: 0,
  },
  seeDiagnosis: {
    top: 5,
    left: 48,
    fontSize: FontSize.size_smi,
    width: 97,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  button: {
    top: 346,
    left: 64,
    width: 180,
  },
  nameOfDisease: {
    fontSize: FontSize.size_lg,
  },
  symptomsListOfSymptomsList: {
    fontSize: FontSize.size_xs,
  },
  nameOfDiseaseContainer: {
    top: 89,
  },
  pictureIcon: {
    top: 196,
  },
  cropHealth3Inner: {
    top: 405,
  },
  button1: {
    top: 672,
    left: 64,
    width: 180,
  },
  nameOfDiseaseContainer1: {
    top: 415,
  },
  pictureIcon1: {
    top: 522,
  },
  makiarrowIcon: {
    top: 23,
    left: 12,
    width: 24,
    height: 21,
    overflow: "hidden",
    position: "absolute",
  },
  cropHealth3: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
  },
});

export default CropHealth;
