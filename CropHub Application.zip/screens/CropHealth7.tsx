import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CropHealth7 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.cropHealth8}>
      <View style={styles.cropHealth8Child} />
      <Text style={styles.treament}>Treament</Text>
      <Pressable
        style={styles.makiarrow}
        onPress={() => navigation.navigate("CropHealth6")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/makiarrow1.png")}
        />
      </Pressable>
      <View style={[styles.cropHealth8Item, styles.cropShadowBox]} />
      <View style={[styles.cropHealth8Inner, styles.cropShadowBox]} />
      <View style={[styles.rectangleView, styles.cropShadowBox]} />
      <Text style={styles.panamaDisease}>Panama Disease</Text>
      <Pressable
        style={styles.arrowDownSignToNavigate}
        onPress={() => navigation.navigate("CropHealth6")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/arrow-down-sign-to-navigate1.png")}
        />
      </Pressable>
      <Image
        style={[styles.mdinumeric1CircleIcon, styles.circleIconLayout]}
        contentFit="cover"
        source={require("../assets/mdinumeric1circle.png")}
      />
      <Image
        style={[styles.mdinumeric2CircleIcon, styles.circleIconLayout]}
        contentFit="cover"
        source={require("../assets/mdinumeric2circle.png")}
      />
      <Text style={[styles.diagnosisResult, styles.diagnosisResultTypo]}>
        Diagnosis Result
      </Text>
      <Text style={[styles.recommendations, styles.diagnosisResultTypo]}>
        Recommendations
      </Text>
      <Text
        style={styles.weRecommendFollowing}
      >{`We recommend following organic control methods in the early stages of a disease or when the crop is close to harvesting. In more advanced stages of a disease, please follow chemical control measures.

Mixing or applying different products at the same time is not recommended.`}</Text>
      <Text style={[styles.organicControl, styles.controlTypo]}>
        Organic Control
      </Text>
      <Text style={[styles.theApplicationOf, styles.theApplicationOfTypo]}>
        The application of biocontrol agents such as the fungus Trichoderma
        viride or the bacteria Pseudomonas fluorescens in the soil are effective
        methods to decrease the incidence and severity of the disease.
      </Text>
      <Image
        style={[styles.mdiorganicIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/mdiorganic.png")}
      />
      <View style={[styles.cropHealth8Child1, styles.cropShadowBox]} />
      <Text style={[styles.chemicalControl, styles.controlTypo]}>
        Chemical Control
      </Text>
      <Text
        style={[styles.alwaysConsiderAn, styles.theApplicationOfTypo]}
      >{`Always consider an integrated approach with preventive measures together with biological treatments if available. Contrarily to other fungal diseases in banana fusarium wilt, once detected, cannot be controlled with fungicides. Dipping plantlets in specific fungicides (10g/10 litres of water) followed by drenching of the soil every second month starting 6 months after planting is recommended. `}</Text>
      <Image
        style={[styles.flaskIcon, styles.iconPosition]}
        contentFit="cover"
        source={require("../assets/flask.png")}
      />
      <Image
        style={styles.panamaDisease3InitialExt}
        contentFit="cover"
        source={require("../assets/panama-disease-3--initial-external-symptoms-of-panama-disease-include-yellowing-leaf-margins-on-older-leaves-daf-qld-3.png")}
      />
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  cropShadowBox: {
    width: 271,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.colorTan,
    borderRadius: Border.br_8xs,
    left: 24,
    position: "absolute",
  },
  circleIconLayout: {
    height: 30,
    width: 30,
    overflow: "hidden",
    position: "absolute",
  },
  diagnosisResultTypo: {
    height: 24,
    width: 232,
    fontSize: FontSize.size_lg,
    left: 57,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  controlTypo: {
    width: 220,
    fontSize: FontSize.size_mini,
    left: 54,
    textAlign: "left",
    color: Color.colorBlack,
    height: 21,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  theApplicationOfTypo: {
    width: 257,
    left: 32,
    textAlign: "justify",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  iconPosition: {
    left: 30,
    height: 24,
    width: 24,
    position: "absolute",
  },
  cropHealth8Child: {
    top: 14,
    left: 0,
    backgroundColor: Color.forest2,
    width: 320,
    height: 39,
    position: "absolute",
  },
  treament: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textTransform: "uppercase",
    color: Color.colorWhite,
    textAlign: "center",
    width: 228,
    height: 19,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  icon: {
    overflow: "hidden",
  },
  makiarrow: {
    left: 12,
    top: 23,
    height: 21,
    width: 24,
    position: "absolute",
  },
  cropHealth8Item: {
    top: 91,
    height: 61,
  },
  cropHealth8Inner: {
    top: 209,
    height: 106,
  },
  rectangleView: {
    top: 334,
    height: 103,
  },
  panamaDisease: {
    top: 108,
    left: 93,
    width: 157,
    height: 28,
    textAlign: "left",
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  arrowDownSignToNavigate: {
    left: 270,
    top: 113,
    width: 17,
    height: 18,
    position: "absolute",
  },
  mdinumeric1CircleIcon: {
    top: 61,
    left: 24,
    height: 30,
    width: 30,
  },
  mdinumeric2CircleIcon: {
    top: 173,
    left: 27,
  },
  diagnosisResult: {
    top: 65,
  },
  recommendations: {
    top: 177,
  },
  weRecommendFollowing: {
    top: 213,
    width: 259,
    height: 94,
    textAlign: "justify",
    left: 30,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  organicControl: {
    top: 341,
  },
  theApplicationOf: {
    top: 367,
    height: 70,
  },
  mdiorganicIcon: {
    top: 338,
    overflow: "hidden",
  },
  cropHealth8Child1: {
    top: 470,
    height: 162,
  },
  chemicalControl: {
    top: 479,
  },
  alwaysConsiderAn: {
    top: 507,
    height: 169,
  },
  flaskIcon: {
    top: 476,
  },
  panamaDisease3InitialExt: {
    top: 101,
    width: 55,
    height: 35,
    left: 32,
    position: "absolute",
  },
  tablerhomeFilled: {
    left: 287,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  cropHealth8: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default CropHealth7;
