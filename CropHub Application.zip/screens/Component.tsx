import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border } from "../GlobalStyles";

const Component = () => {
  return (
    <View style={styles.component71}>
      <Image
        style={[styles.property1ellipse5, styles.property1ellipseLayout]}
        contentFit="cover"
        source={require("../assets/property-1ellipse-5.png")}
      />
      <View style={[styles.property1ellipse7, styles.property1ellipseLayout]}>
        <Image
          style={styles.property1ellipseLayout}
          contentFit="cover"
          source={require("../assets/ellipse-7.png")}
        />
      </View>
      <Image
        style={[styles.property1ellipse6, styles.property1ellipseLayout]}
        contentFit="cover"
        source={require("../assets/property-1ellipse-6.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  property1ellipseLayout: {
    height: 30,
    width: 30,
  },
  property1ellipse5: {
    left: 20,
    top: 20,
    width: 30,
    position: "absolute",
  },
  property1ellipse7: {
    left: 171,
    flexDirection: "row",
    top: 20,
    width: 30,
    position: "absolute",
  },
  property1ellipse6: {
    top: 21,
    left: 95,
    position: "absolute",
    width: 30,
  },
  component71: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: "#9747ff",
    borderWidth: 1,
    flex: 1,
    width: "100%",
    height: 86,
    overflow: "hidden",
  },
});

export default Component;
