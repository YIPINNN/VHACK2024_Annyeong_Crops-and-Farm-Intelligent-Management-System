import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Border, FontSize, FontFamily, Color } from "../GlobalStyles";

const PestMonitoringResult = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.pestMonitoringResult}>
      <View style={styles.pestMonitoringResultChild} />
      <Text style={styles.pest}>PEST</Text>
      <View
        style={[styles.pestMonitoringResultItem, styles.image31IconLayout]}
      />
      <Text
        style={[styles.typeOfSpecies, styles.damageTypo]}
      >{`Type of species: Locust
Food: 
Sugarcane
Sorghum
Oats
Barley
Corn
Wheat`}</Text>
      <Text style={[styles.areaCodeA005, styles.damageTypo]}>{`Area code: A-005
Sensor code: S-112`}</Text>
      <Image
        style={[styles.image31Icon, styles.image31IconLayout]}
        contentFit="cover"
        source={require("../assets/image-31.png")}
      />
      <Image
        style={[styles.beetleIcon, styles.beetleIconPosition]}
        contentFit="cover"
        source={require("../assets/beetle1.png")}
      />
      <Image
        style={[styles.pictureIcon, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture.png")}
      />
      <Image
        style={[styles.pictureIcon1, styles.pictureIconLayout]}
        contentFit="cover"
        source={require("../assets/picture.png")}
      />
      <Text style={[styles.damageSymptomDefoliation, styles.damageTypo]}>
        Damage symptom: Defoliation
      </Text>
      <Text style={[styles.damageSymptomFeeding, styles.damageTypo]}>
        Damage symptom: Feeding on Stems and Bark
      </Text>
      <Pressable
        style={styles.pestMonitoringResultInner}
        onPress={() => navigation.navigate("ApplyForPesticide")}
      />
      <Text style={[styles.applyPesticide, styles.beetleIconPosition]}>
        Apply pesticide?
      </Text>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  image31IconLayout: {
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  damageTypo: {
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
  },
  beetleIconPosition: {
    left: 122,
    position: "absolute",
  },
  pictureIconLayout: {
    height: 143,
    borderRadius: Border.br_8xs,
    width: 228,
    position: "absolute",
  },
  pestMonitoringResultChild: {
    top: 14,
    left: 0,
    backgroundColor: Color.olive3,
    width: 320,
    height: 39,
    position: "absolute",
  },
  pest: {
    marginLeft: -114,
    top: 24,
    left: "50%",
    fontSize: FontSize.size_sm,
    textAlign: "center",
    height: 19,
    width: 228,
    color: Color.colorWhite,
    fontFamily: FontFamily.sanchezRegular,
    position: "absolute",
  },
  pestMonitoringResultItem: {
    top: 252,
    left: 31,
    backgroundColor: Color.colorDarkkhaki_100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 258,
    height: 194,
  },
  typeOfSpecies: {
    top: 459,
    width: 196,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: 48,
    position: "absolute",
  },
  areaCodeA005: {
    top: 210,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: 48,
    position: "absolute",
  },
  image31Icon: {
    top: 270,
    left: 53,
    width: 213,
    height: 160,
  },
  beetleIcon: {
    top: 88,
    width: 75,
    height: 75,
  },
  pictureIcon: {
    top: 591,
    left: 46,
  },
  pictureIcon1: {
    top: 778,
    left: 48,
    height: 143,
  },
  damageSymptomDefoliation: {
    top: 742,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: 48,
    position: "absolute",
  },
  damageSymptomFeeding: {
    top: 929,
    width: 224,
    height: 24,
    color: Color.colorBlack,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    left: 48,
    position: "absolute",
  },
  pestMonitoringResultInner: {
    top: 966,
    left: 79,
    borderRadius: Border.br_xs,
    backgroundColor: Color.olive4,
    width: 162,
    height: 27,
    position: "absolute",
  },
  applyPesticide: {
    top: 973,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.sanchezRegular,
    left: 122,
    color: Color.colorWhite,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  pestMonitoringResult: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    width: "100%",
  },
});

export default PestMonitoringResult;
