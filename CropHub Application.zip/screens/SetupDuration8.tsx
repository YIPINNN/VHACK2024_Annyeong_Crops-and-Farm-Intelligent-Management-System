import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const SetupDuration8 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.setupDuration}>
      <Image
        style={styles.setupDurationChild}
        contentFit="cover"
        source={require("../assets/ellipse-102.png")}
      />
      <View style={styles.setupDurationItem} />
      <Text style={[styles.irrigationSystem, styles.rectangleParentLayout]}>
        IRRIGATION SYSTEM
      </Text>
      <Text style={styles.sensor}>Sensor</Text>
      <Image
        style={[styles.setupDurationInner, styles.setupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-12.png")}
      />
      <Text style={[styles.text, styles.textTypo1]}>1</Text>
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-32.png")}
      />
      <Text style={[styles.text1, styles.textTypo1]}>3</Text>
      <Image
        style={[styles.setupDurationChild1, styles.ellipseIconPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <Text style={[styles.text2, styles.textTypo1]}>4</Text>
      <Image
        style={[styles.setupDurationChild2, styles.selectTimePosition]}
        contentFit="cover"
        source={require("../assets/ellipse-12.png")}
      />
      <Text style={[styles.text3, styles.textTypo1]}>2</Text>
      <View style={[styles.lineView, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild3, styles.setupChildLayout]} />
      <View style={[styles.setupDurationChild4, styles.setupChildLayout]} />
      <Text style={[styles.period, styles.timeTypo]}>Period</Text>
      <Text style={[styles.duration, styles.timeTypo]}>Duration</Text>
      <Text style={[styles.time, styles.timeTypo]}>Time</Text>
      <Text style={[styles.confirmed, styles.timeTypo]}>Confirmed</Text>
      <Image
        style={styles.image35Icon}
        contentFit="cover"
        source={require("../assets/image-351.png")}
      />
      <Text style={styles.wateringTime}>Watering Time</Text>
      <Text style={[styles.scheduleWateringTimes, styles.timeClr]}>
        Schedule watering times during the day(s).
      </Text>
      <View style={[styles.addWateringTimeParent, styles.rectangleViewLayout]}>
        <Text style={[styles.addWateringTime, styles.timeClr]}>
          Add watering time
        </Text>
        <Image
          style={styles.image37Icon}
          contentFit="cover"
          source={require("../assets/image-37.png")}
        />
      </View>
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <View style={styles.setupDurationChild5} />
      <View style={[styles.setupDurationChild6, styles.setupChildShadowBox]} />
      <View style={[styles.setupDurationChild7, styles.setupChildShadowBox]} />
      <Text style={[styles.text4, styles.text4Layout]}>:</Text>
      <Text style={[styles.selectTime, styles.selectTimePosition]}>
        Select Time
      </Text>
      <Text style={[styles.text5, styles.textTypo]}>13</Text>
      <Text style={[styles.text6, styles.textTypo]}>00</Text>
      <Pressable
        style={[styles.rectangleParent, styles.rectangleParentLayout]}
        onPress={() => navigation.navigate("SetupDuration7")}
      >
        <View style={styles.groupChild} />
        <Text style={[styles.done, styles.timeTypo]}>Done</Text>
      </Pressable>
      <Image
        style={[styles.image38Icon, styles.text4Layout]}
        contentFit="cover"
        source={require("../assets/image-39.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleParentLayout: {
    height: 19,
    position: "absolute",
  },
  setupLayout: {
    width: 28,
    top: 219,
    height: 28,
  },
  textTypo1: {
    width: 16,
    fontSize: FontSize.size_2xs,
    color: Color.colorBlack,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconPosition: {
    top: 220,
    height: 28,
    width: 28,
    position: "absolute",
  },
  selectTimePosition: {
    left: 109,
    position: "absolute",
  },
  setupChildLayout: {
    height: 1,
    width: 48,
    borderTopWidth: 1,
    top: 234,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    position: "absolute",
  },
  timeTypo: {
    height: 12,
    fontSize: FontSize.size_4xs,
    textAlign: "center",
    position: "absolute",
  },
  timeClr: {
    color: Color.colorBlack,
    textAlign: "center",
  },
  rectangleViewLayout: {
    height: 21,
    position: "absolute",
  },
  setupChildShadowBox: {
    height: 40,
    width: 45,
    backgroundColor: Color.colorGainsboro_100,
    top: 263,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  text4Layout: {
    width: 10,
    position: "absolute",
  },
  textTypo: {
    height: 22,
    width: 30,
    top: 275,
    fontSize: FontSize.size_sm,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  setupDurationChild: {
    top: 75,
    left: 101,
    height: 100,
    width: 100,
    position: "absolute",
  },
  setupDurationItem: {
    top: 14,
    width: 320,
    height: 39,
    backgroundColor: Color.forest3,
    left: 0,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontSize: FontSize.size_xs,
    width: 228,
    textAlign: "center",
    height: 19,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  sensor: {
    top: 59,
    left: 272,
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  setupDurationInner: {
    left: 34,
    height: 28,
    position: "absolute",
  },
  text: {
    left: 40,
    top: 226,
    width: 16,
    fontSize: FontSize.size_2xs,
  },
  ellipseIcon: {
    left: 184,
  },
  text1: {
    left: 190,
    top: 227,
  },
  setupDurationChild1: {
    left: 259,
  },
  text2: {
    left: 265,
    top: 227,
  },
  setupDurationChild2: {
    height: 28,
    width: 28,
    top: 219,
  },
  text3: {
    left: 115,
    top: 226,
    width: 16,
    fontSize: FontSize.size_2xs,
  },
  lineView: {
    left: 62,
  },
  setupDurationChild3: {
    left: 137,
  },
  setupDurationChild4: {
    left: 212,
  },
  period: {
    left: 28,
    width: 40,
    top: 254,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
  },
  duration: {
    left: 103,
    width: 40,
    top: 254,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
  },
  time: {
    left: 178,
    width: 40,
    top: 254,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
  },
  confirmed: {
    left: 250,
    width: 46,
    top: 254,
    fontSize: FontSize.size_4xs,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
  },
  image35Icon: {
    top: 91,
    left: 113,
    width: 75,
    height: 75,
    position: "absolute",
  },
  wateringTime: {
    top: 306,
    left: 98,
    width: 131,
    fontSize: FontSize.size_sm,
    color: Color.colorBlack,
    height: 19,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    position: "absolute",
  },
  scheduleWateringTimes: {
    top: 327,
    left: 58,
    width: 206,
    height: 14,
    fontFamily: FontFamily.istokWebRegular,
    color: Color.colorBlack,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  addWateringTime: {
    top: 1,
    left: 7,
    textDecoration: "underline",
    fontStyle: "italic",
    fontFamily: FontFamily.istokWebBoldItalic,
    width: 98,
    height: 20,
    fontSize: FontSize.size_3xs,
    color: Color.colorBlack,
    fontWeight: "700",
    position: "absolute",
  },
  image37Icon: {
    width: 15,
    top: 0,
    height: 15,
    left: 0,
    position: "absolute",
  },
  addWateringTimeParent: {
    top: 352,
    left: 107,
    width: 105,
  },
  rectangleView: {
    top: 349,
    left: 105,
    backgroundColor: Color.colorGainsboro_200,
    borderWidth: 0.5,
    width: 104,
    borderColor: Color.colorBlack,
    borderStyle: "solid",
    height: 21,
  },
  setupDurationChild5: {
    top: 213,
    left: 50,
    backgroundColor: Color.colorWhite,
    width: 220,
    height: 136,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  setupDurationChild6: {
    left: 97,
  },
  setupDurationChild7: {
    left: 176,
  },
  text4: {
    top: 269,
    left: 155,
    fontSize: FontSize.size_xl,
    color: Color.colorBlack,
    textAlign: "center",
    height: 28,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  selectTime: {
    top: 235,
    fontSize: FontSize.size_smi,
    height: 17,
    color: Color.colorBlack,
    textAlign: "center",
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
    width: 100,
  },
  text5: {
    left: 104,
  },
  text6: {
    left: 184,
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    top: 0,
    width: 40,
    height: 19,
    backgroundColor: Color.forest3,
    left: 0,
    position: "absolute",
  },
  done: {
    top: 3,
    left: 3,
    width: 32,
    textShadowColor: "rgba(0, 0, 0, 0.25)",
    textShadowOffset: {
      width: 0,
      height: 4,
    },
    textShadowRadius: 4,
    fontSize: FontSize.size_4xs,
    color: Color.colorWhite,
    fontFamily: FontFamily.istokWebBold,
    fontWeight: "700",
  },
  rectangleParent: {
    top: 320,
    left: 140,
    width: 40,
  },
  image38Icon: {
    left: 245,
    height: 10,
    top: 227,
  },
  setupDuration: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    width: "100%",
    height: 568,
    overflow: "hidden",
  },
});

export default SetupDuration8;
