import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Property1Frame from "../components/Property1Frame";
import { Border, FontFamily, Color, FontSize } from "../GlobalStyles";

const Irrigation = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.irrigation}>
      <Pressable
        style={[styles.irrigationChild, styles.irrigationShadowBox]}
        onPress={() => navigation.navigate("ConnectSensor")}
      />
      <View style={styles.irrigationItem} />
      <LinearGradient
        style={[styles.irrigationInner, styles.irrigationShadowBox]}
        locations={[0, 1]}
        colors={["#abd780", "#ddeecd"]}
      />
      <Image
        style={styles.image27Icon}
        contentFit="cover"
        source={require("../assets/image-271.png")}
      />
      <Image
        style={styles.irrigationIcon}
        contentFit="cover"
        source={require("../assets/irrigation-icon1.png")}
      />
      <View style={styles.rectangleView} />
      <Text style={styles.irrigationSystem}>IRRIGATION SYSTEM</Text>
      <Text style={styles.rememberToWater}>Remember to water your crops!</Text>
      <View style={styles.marchParent}>
        <Text style={styles.march}>March</Text>
        <Text style={[styles.monTueWed, styles.monTueWedTypo]}>
          {" "}
          Mon Tue Wed Thu Fri Sat Sun
        </Text>
      </View>
      <Property1Frame
        numberValue="3"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={26}
        property1Frame1Top={321}
        property1Frame1Left={238}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="2"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={26}
        property1Frame1Top={321}
        property1Frame1Left={207}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="1"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={26}
        property1Frame1Top={321}
        property1Frame1Left={176}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="24"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={238}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="29"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={176}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="8"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={176}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="18"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={52}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="25"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={52}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="23"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={207}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="31"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={238}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="26"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={83}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="30"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={207}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="21"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={145}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="28"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={145}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="19"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={83}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="27"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={460}
        property1Frame1Left={114}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="22"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={176}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="20"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={426}
        property1Frame1Left={114}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="11"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={52}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="17"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={238}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="16"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={207}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="15"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={176}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="14"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={145}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="13"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={114}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="12"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={25}
        property1Frame1Top={391}
        property1Frame1Left={83}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="4"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={52}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="10"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={238}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="9"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={207}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="7"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={145}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="6"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={114}
        textFontSize={10}
      />
      <Property1Frame
        numberValue="5"
        property1Frame1Position="absolute"
        property1Frame1Width={26}
        property1Frame1Height={24}
        property1Frame1Top={357}
        property1Frame1Left={83}
        textFontSize={10}
      />
      <Text style={[styles.selectTheDates, styles.monTueWedTypo]}>
        Select the dates to receive reminders:
      </Text>
      <Pressable
        style={styles.image28}
        onPress={() => navigation.navigate("ConnectSensor")}
      >
        <Image
          style={styles.iconLayout}
          contentFit="cover"
          source={require("../assets/image-28.png")}
        />
      </Pressable>
      <Pressable
        style={styles.sensor}
        onPress={() => navigation.navigate("ConnectSensor")}
      >
        <Text style={styles.sensor1}>Sensor</Text>
      </Pressable>
      <Pressable
        style={styles.tablerhomeFilled}
        onPress={() => navigation.navigate("LandingPage")}
      >
        <Image
          style={[styles.icon1, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/tablerhomefilled.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  irrigationShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  monTueWedTypo: {
    textAlign: "left",
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  irrigationChild: {
    top: 56,
    left: 254,
    width: 62,
    height: 20,
    backgroundColor: Color.forest3,
  },
  irrigationItem: {
    top: 198,
    backgroundColor: Color.colorGainsboro_200,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderWidth: 0.5,
    width: 162,
    height: 16,
    left: 78,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  irrigationInner: {
    top: 251,
    left: 41,
    width: 234,
    height: 245,
    backgroundColor: "transparent",
  },
  image27Icon: {
    top: 321,
    left: 96,
    width: 120,
    height: 124,
    position: "absolute",
  },
  irrigationIcon: {
    top: 81,
    left: 110,
    width: 96,
    height: 98,
    position: "absolute",
  },
  rectangleView: {
    top: 14,
    width: 320,
    height: 39,
    left: 0,
    backgroundColor: Color.forest3,
    position: "absolute",
  },
  irrigationSystem: {
    marginLeft: -116,
    top: 26,
    left: "50%",
    fontWeight: "700",
    fontFamily: FontFamily.istokWebBold,
    width: 228,
    height: 19,
    textAlign: "center",
    color: Color.colorWhite,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  rememberToWater: {
    top: 199,
    left: 47,
    width: 223,
    height: 17,
    color: Color.colorBlack,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    position: "absolute",
  },
  march: {
    top: 0,
    width: 58,
    height: 13,
    fontFamily: FontFamily.interRegular,
    color: Color.colorBlack,
    textAlign: "center",
    fontSize: FontSize.size_xs,
    left: 78,
    position: "absolute",
  },
  monTueWed: {
    top: 39,
    fontSize: FontSize.size_4xs,
    height: 15,
    width: 215,
    left: 0,
  },
  marchParent: {
    top: 260,
    left: 51,
    height: 54,
    width: 215,
    position: "absolute",
  },
  selectTheDates: {
    top: 236,
    left: 43,
    fontSize: FontSize.size_5xs,
    width: 175,
    height: 17,
  },
  image28: {
    left: 261,
    top: 60,
    width: 12,
    height: 12,
    position: "absolute",
  },
  sensor1: {
    width: 42,
    height: 15,
    fontFamily: FontFamily.istokWebRegular,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.colorWhite,
  },
  sensor: {
    left: 272,
    top: 59,
    position: "absolute",
  },
  icon1: {
    overflow: "hidden",
  },
  tablerhomeFilled: {
    left: 8,
    top: 21,
    width: 25,
    height: 25,
    position: "absolute",
  },
  irrigation: {
    backgroundColor: Color.warmWhite,
    flex: 1,
    height: 568,
    overflow: "hidden",
    width: "100%",
  },
});

export default Irrigation;
