/* fonts */
export const FontFamily = {
  istokWebBold: "IstokWeb-Bold",
  sanchezRegular: "Sanchez-Regular",
  istokWebRegular: "IstokWeb-Regular",
  sarabunExtraBold: "Sarabun-ExtraBold",
  sarabunSemiBold: "Sarabun-SemiBold",
  interRegular: "Inter-Regular",
  istokWebBoldItalic: "IstokWeb-BoldItalic",
  istokWebItalic: "IstokWeb-Italic",
};
/* font sizes */
export const FontSize = {
  size_xs: 12,
  size_3xs: 10,
  size_2xs: 11,
  size_lg: 18,
  size_smi: 13,
  size_sm: 14,
  size_mini: 15,
  size_4xs: 9,
  size_5xs: 8,
  size_xl: 20,
  size_6xs: 7,
  size_8xs: 5,
  size_9xs: 4,
  size_7xs: 6,
};
/* Colors */
export const Color = {
  warmWhite: "#fffaed",
  colorDarkgreen: "#135311",
  forest4: "#a3b18a",
  colorDarkseagreen_100: "rgba(163, 177, 138, 0.53)",
  colorDarkseagreen_200: "rgba(163, 177, 138, 0.2)",
  forest2: "#3a5a40",
  colorFirebrick: "#cf2121",
  colorWhite: "#fff",
  colorBlack: "#000",
  colorGainsboro_100: "#d9d9d9",
  colorGainsboro_200: "rgba(217, 217, 217, 0)",
  colorGold: "#ffd040",
  olive4: "#a2a569",
  colorDarkkhaki_100: "rgba(162, 165, 105, 0.53)",
  olive3: "#737b4c",
  forest3: "#588157",
  colorDarkolivegreen_100: "#3d441e",
  colorTan: "rgba(176, 170, 126, 0.53)",
  colorGray_100: "rgba(0, 0, 0, 0.7)",
  colorGray_200: "rgba(0, 0, 0, 0.5)",
  colorIndianred: "#ea5a5a",
  forest5: "#dad7cd",
  colorLightgray_100: "rgba(218, 215, 205, 0.53)",
  colorBeige_100: "#e1f2d1",
  colorPink: "#f9cdcd",
  colorWhitesmoke: "#ededed",
};
/* Paddings */
export const Padding = {
  p_3xs: 10,
};
/* border radiuses */
export const Border = {
  br_mini: 15,
  br_8xs: 5,
  br_xs: 12,
  br_10xs: 3,
  br_xl: 20,
};
